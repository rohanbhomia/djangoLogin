from typing import Optional, List, Dict
from pydantic import BaseModel,ValidationError,validator,Field, PositiveInt
from fastapi import FastAPI, Query
from pydantic.dataclasses import dataclass
from ..validator_package import validation
from ..validator_package.validations_errors import *



class CreateJob(BaseModel):
	category: str
	other_category : str
	role_type : str
	project_title : str
	primary_language :  str
	additional_language :  str
	project_description :  str
	character_name :  str
	age_start :  int
	age_end :  int
	playing_role :  str
	traits :  str
	role_description :  str
	skills :  str
	pay_rage :  str
	experience :  str
	location :  str
	apply_date : str
	id : Optional[int]

	@validator('category')
	def category_validation(cls, category):
		return validation.check_blank_validation(category,"Category can not be blank")
	
	@validator('other_category')
	def other_category_validation(cls, other_category):
		return validation.check_blank_validation(other_category,"Other category can not be blank")
	
	@validator('role_type')
	def role_type_validation(cls, role_type):
		return validation.check_blank_validation(role_type,"Role type can not be blank")
	
	@validator('project_title')
	def project_title_validation(cls, project_title):
		return validation.check_blank_validation(project_title,"Project title can not be blank")
	
	@validator('primary_language')
	def primary_language_validation(cls, primary_language):
		return validation.check_blank_validation(primary_language,"Primary language can not be blank")
	
	@validator('project_description')
	def project_description_validation(cls, project_description):
		return validation.check_blank_validation(project_description,"Project description can not be blank")
	
	@validator('character_name')
	def character_name_validation(cls, character_name):
		return validation.name_validation(character_name,"Character name can not be blank")
	
	
	
	@validator('age_start')
	def age_start_validation(cls, age_start):
		return validation.check_integer_format(age_start)
	
	@validator('age_end')
	def age_end_validation(cls, age_end):
		return validation.check_integer_format(age_end)
	
	@validator('playing_role')
	def playing_role_validation(cls, playing_role):
		return validation.check_blank_validation(playing_role,"Playing role can not be blank")
	
	@validator('traits')
	def traits_validation(cls, traits):
		return validation.check_blank_validation(traits,"Traits can not be blank")
	
	@validator('role_description')
	def role_description_validation(cls, role_description):
		return validation.check_blank_validation(role_description,"Role description can not be blank")
	
	@validator('skills')
	def skills_validation(cls, skills):
		return validation.check_blank_validation(skills,"Skills can not be blank")
	
	@validator('pay_rage')
	def pay_rage_validation(cls, pay_rage):
		return validation.check_blank_validation(pay_rage,"Pay rage can not be blank")
	
	@validator('experience')
	def experience_validation(cls, experience):
		return validation.check_blank_validation(experience,"Experience can not be blank")
	
	@validator('location')
	def location_validation(cls, location):
		return validation.check_blank_validation(location,"Location can not be blank")
	
	@validator('apply_date')
	def apply_date_validation(cls, apply_date):
		return validation.check_date_format(apply_date)


class CreateJobTwo(BaseModel):
	category: str
	profession : str
	project_title : str
	project_description :  str
	directed_by :  str
	duration_start :  str
	duration_end :  str
	shooting_days :  str
	pay_rage :  str
	experience :  str
	location :  str
	apply_date : str
	id : Optional[int]

	@validator('category')
	def category_validation(cls, category):
		return validation.check_blank_validation(category,"Category can not be blank")
	
	@validator('profession')
	def profession_validation(cls, profession):
		return validation.check_blank_validation(profession,"Profession can not be blank")
	
	@validator('project_title')
	def project_title_validation(cls, project_title):
		return validation.check_blank_validation(project_title,"Project title can not be blank")
	
	@validator('project_description')
	def project_description_validation(cls, project_description):
		return validation.check_blank_validation(project_description,"Project description can not be blank")
	
	@validator('directed_by')
	def directed_by_validation(cls, directed_by):
		return validation.check_blank_validation(directed_by,"Directed by can not be blank")
	
	@validator('duration_start')
	def duration_start_validation(cls, duration_start):
		return validation.check_date_format(duration_start)
	
	@validator('duration_end')
	def duration_end_validation(cls, duration_end):
		return validation.check_date_format(duration_end)
	
	@validator('shooting_days')
	def shooting_days_validation(cls, shooting_days):
		return validation.check_blank_validation(shooting_days,"Shooting days can not be blank")
	
	@validator('pay_rage')
	def pay_rage_validation(cls, pay_rage):
		return validation.check_blank_validation(pay_rage,"Pay rage can not be blank")
	
	@validator('experience')
	def experience_validation(cls, experience):
		return validation.check_blank_validation(experience,"Experience can not be blank")
	
	@validator('location')
	def location_validation(cls, location):
		return validation.check_blank_validation(location,"Location can not be blank")
	
	@validator('apply_date')
	def apply_date_validation(cls, apply_date):
		return validation.check_date_format(apply_date)


class CreateJobThree(BaseModel):
	category: str
	role_type : str
	job_description :  str
	skills :  str
	pay_rage :  str
	experience :  str
	employment_type :  str
	position_type :  str
	location :  str
	apply_date : str
	id : Optional[int]


	@validator('category')
	def category_validation(cls, category):
		return validation.check_blank_validation(category,"Category can not be blank")
	
	
	@validator('role_type')
	def role_type_validation(cls, role_type):
		return validation.check_blank_validation(role_type,"Role type can not be blank")
	
	
	@validator('job_description')
	def job_description_validation(cls, job_description):
		return validation.check_blank_validation(job_description,"Job description can not be blank")
	
	@validator('skills')
	def skills_validation(cls, skills):
		return validation.check_blank_validation(skills,"Skills can not be blank")
	
	
	@validator('pay_rage')
	def pay_rage_validation(cls, pay_rage):
		return validation.check_blank_validation(pay_rage,"Pay rage can not be blank")
	
	@validator('experience')
	def experience_validation(cls, experience):
		return validation.check_blank_validation(experience,"Experience can not be blank")
	
	@validator('employment_type')
	def employment_type_validation(cls, employment_type):
		return validation.check_blank_validation(employment_type,"Employment type can not be blank")
	
	@validator('position_type')
	def position_type_validation(cls, position_type):
		return validation.check_blank_validation(position_type,"Position type can not be blank")
	
	@validator('location')
	def location_validation(cls, location):
		return validation.check_blank_validation(location,"Location can not be blank")
	
	@validator('apply_date')
	def apply_date_validation(cls, apply_date):
		return validation.check_date_format(apply_date)
	

		

class SearchJobs(BaseModel):
	category: str
	role_type: Optional[str]
	