-- Adminer 4.8.1 MySQL 8.0.27 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `employer_job_posting`;
CREATE TABLE `employer_job_posting` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employer_id` bigint NOT NULL,
  `category` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `other_category` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `role_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `project_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `primary_language` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `additional_language` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `project_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `job_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `character_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `age_start` int DEFAULT NULL,
  `age_end` int DEFAULT NULL,
  `playing_role` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `traits` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `role_description` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `skills` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `pay_rage` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `experience` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `profession` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `directed_by` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `shooting_days` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `employment_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `position_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `apply_date` date DEFAULT NULL,
  `duration_start` date DEFAULT NULL,
  `duration_end` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

TRUNCATE `employer_job_posting`;
INSERT INTO `employer_job_posting` (`id`, `employer_id`, `category`, `other_category`, `role_type`, `project_title`, `primary_language`, `additional_language`, `project_description`, `job_description`, `character_name`, `age_start`, `age_end`, `playing_role`, `traits`, `role_description`, `skills`, `pay_rage`, `experience`, `location`, `profession`, `directed_by`, `shooting_days`, `employment_type`, `position_type`, `apply_date`, `duration_start`, `duration_end`, `is_active`, `created_on`, `updated_on`) VALUES
(32,	3,	'Film & OTT',	'Casting Call',	'Lead Role',	'Bahubali 3',	'Telugu',	'',	'asdasdasasdasdasdadasdadasdasdasdasdasda',	NULL,	'Aasdass',	30,	40,	'King, Warrior',	'tall,family pack',	'asdasdas',	'dancing,horse riding',	'low paid',	'freshers',	'mumbai',	NULL,	NULL,	NULL,	NULL,	NULL,	'2022-02-11',	NULL,	NULL,	1,	'2022-04-26 15:00:02',	'2022-04-26 15:00:02'),
(33,	3,	'Film & OTT',	'Casting Call',	'Supporting',	'Bahubali 3',	'Telugu',	'',	'asdasdasasdasdasdadasdadasdasdasdasdasda',	NULL,	'Aasdass',	30,	40,	'King, Warrior',	'tall,family pack',	'asdasdas',	'dancing,horse riding',	'low paid',	'freshers',	'mumbai',	NULL,	NULL,	NULL,	NULL,	NULL,	'2022-02-11',	NULL,	NULL,	1,	'2022-04-26 15:00:02',	'2022-04-26 15:00:02'),
(34,	3,	'TV',	'Casting Call',	'Supporting',	'Bahubali 3',	'Telugu',	'',	'asdasdasasdasdasdadasdadasdasdasdasdasda',	NULL,	'Aasdass',	30,	40,	'King, Warrior',	'tall,family pack',	'asdasdas',	'dancing,horse riding',	'low paid',	'freshers',	'mumbai',	NULL,	NULL,	NULL,	NULL,	NULL,	'2022-02-11',	NULL,	NULL,	1,	'2022-04-26 15:00:02',	'2022-04-26 15:00:02');

-- 2022-04-26 09:43:10
