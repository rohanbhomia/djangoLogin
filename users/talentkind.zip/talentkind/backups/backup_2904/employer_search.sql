-- Adminer 4.8.1 MySQL 8.0.27 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `employer_search`;
CREATE TABLE `employer_search` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employer_id` int NOT NULL,
  `search_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `search_value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

TRUNCATE `employer_search`;
INSERT INTO `employer_search` (`id`, `employer_id`, `search_name`, `search_value`, `created_on`) VALUES
(14,	3,	'test2ada',	'{\"industries.display_name\": {\"$in\": [\"Film & OTT\", \"TV Studio & Broadcast\"]}, \"industry_location.name\": {\"$in\": [\"Marathi\"]}}',	'2022-04-29 19:02:02'),
(15,	3,	'test2',	'{\"industries.display_name\": {\"$in\": [\"Film & OTT\", \"TV Studio & Broadcast\"]}, \"industry_location.name\": {\"$in\": [\"Marathi\"]}}',	'2022-04-29 19:00:42'),
(16,	3,	'new',	'{\"industries.display_name\": {\"$in\": [\"Film & OTT\", \"TV Studio & Broadcast\"]}, \"industry_location.name\": {\"$in\": [\"Marathi\"]}}',	'2022-04-29 19:09:48'),
(17,	3,	'new',	'{\"industries.display_name\": {\"$in\": [\"Film & OTT\", \"TV Studio & Broadcast\"]}, \"industry_location.name\": {\"$in\": [\"Marathis\"]}}',	'2022-04-29 19:10:56');

-- 2022-04-29 13:51:01
