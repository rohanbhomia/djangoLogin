from ..schemas.employer_search import *
from ..utils.app_exceptions import AppException
from ..services.main import AppService, AppCRUD
from ..models.employer_search import *
from ..models.talent_profile import *
from ..models.employer_profile import *
from ..utils.service_result import ServiceResult
from ..config.dependencies import os, mongodb, dateTime_at
import json
from sqlalchemy import or_, and_


mongodbConn = mongodb()


statusCodeSuccess = int(os.getenv('STATUS_200'))
statusMessageSuccess = os.getenv('MESSAGE_200')
statusCodeFailure = int(os.getenv('STATUS_409'))
statusMessageFailed = os.getenv('MESSAGE_409')


class EmployerSearch(AppService):

    def get_all_keywords(self, token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._get_all_keywords(token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)

    def quick_search(self, item: QuickSearch) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._quick_search(item)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)

    def quick_search_by_id(self, id, token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._quick_search_by_id(id, token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)

    def save_search(self, item: QuickSearch, token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._save_search(item, token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)

    def update_search(self, item: QuickSearch, token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._update_search(item, token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)

    def delete_search(self, item: DeleteSearch, token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._delete_search(item, token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)

    def get_all_search(self, token, id) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._get_all_search(token, id)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)


class SettingsCrud(AppCRUD):

    def input_schema(self, item):
        mydict = {}
        if item.industries is not None:
            mydict['industries.display_name'] = {"$in": item.industries}
        if item.industry_location is not None:
            mydict['industry_location.name'] = {"$in": item.industry_location}

        return mydict

    def _get_all_keywords(self, token) -> Employer_industry:
        employer_id = token.id
        category_name = []
        role = []
        location = []

        mydict = {}

        result = self.db.query(Employer_industry).filter(
            Employer_industry.employer_id == employer_id).all()

        for data in result:
            category_name.append(data.display_name)

        print("collection_names()----", mongodbConn.collection_names())
        print(mongodbConn['talents'])
        for document in mongodbConn['talents'].find():
            print(document)

        # mydict['display_name'] = {"$in": category_name}
        for document in mongodbConn['industries'].find({"display_name": {"$in": category_name}}):
            for innerdocument in document['categories']:
                for innerdocumentname in innerdocument['subcategories']:
                    if innerdocumentname['name'] not in role:
                        role.append(innerdocumentname['name'])

        # mydict['display_name'] = {"$in": category_name}
        for document in mongodbConn['form_options'].find({"type": {"$in": ["industry_locations"]}}):

            for innerdocument in document['values']:

                if innerdocument['name'] not in location:

                    location.append(innerdocument['name'])

        talent_search = {"status": statusCodeSuccess,
                         "message": statusMessageSuccess, 'response': {"category_name": category_name, "role": role, "location": location}}
        return talent_search

    def _quick_search(self, item: QuickSearch) -> Employer_search:

        result = []

        mydict = self.input_schema(item)
        print("myquery--", mydict)

        mydoc = mongodbConn['talents'].find(mydict)

        for data in mydoc:
            print("data----", data)
            new_dict = data
            del new_dict['_id']
            result.append(new_dict)

        talent_search = {"status": statusCodeSuccess,
                         "message": statusMessageSuccess, 'response': result}
        return talent_search

    def _save_search(self, item: QuickSearch, token) -> Employer_search:
        employer_id = token.id

        if item.search_name is None:
            employer_search = {"status": statusCodeFailure,
                               "message": "Name is required"}
            return employer_search
        else:
            mydict = self.input_schema(item)

            employer_search = Employer_search(
                employer_id=employer_id,
                search_name=item.search_name,
                search_value=json.dumps(mydict),
                created_on=dateTime_at
            )
            self.db.add(employer_search)
            self.db.commit()
            self.db.refresh(employer_search)

            employer_search = {"status": statusCodeSuccess,
                               "message": 'Created successfully'}
            return employer_search

    def _update_search(self, item: QuickSearch, token) -> Employer_search:
        employer_id = token.id

        if item.id is not None:

            mydict = self.input_schema(item)

            result = self.db.query(Employer_search).filter(
                and_(Employer_search.employer_id == employer_id, Employer_search.id == item.id)).first()

            if result is not None:
                result.search_name = item.search_name
                result.search_value = json.dumps(mydict)
                result.created_on = dateTime_at

                self.db.add(result)
                self.db.commit()
                self.db.refresh(result)

                employer_search = {"status": statusCodeSuccess,
                                   "message": 'Updated successfully'}
                return employer_search
            else:
                employer_search = {"status": statusCodeFailure,
                                   "message": "Id does not match."}
                return employer_search
        else:
            employer_search = {"status": statusCodeFailure,
                               "message": "Id is required."}
            return employer_search

    def _delete_search(self, item: DeleteSearch, token) -> Employer_search:
        employer_id = token.id

        result = self.db.query(Employer_search).filter(
            and_(Employer_search.employer_id == employer_id, Employer_search.id == item.id)).first()
        if result is not None:
            self.db.query(Employer_search).filter(
                and_(Employer_search.employer_id == employer_id, Employer_search.id == item.id)).delete()
            self.db.commit()
            employer_search = {"status": statusCodeSuccess,
                               "message": 'Deleted successfully'}
            return employer_search
        else:

            employer_search = {"status": statusCodeFailure,
                               "message": "Id does not match."}
            return employer_search

    def _quick_search_by_id(self, id, token) -> Employer_search:
        employer_id = token.id
        mydict = {}
        new_result = []

        if id is not None:

            result = self.db.query(Employer_search).filter(
                and_(Employer_search.employer_id == employer_id, Employer_search.id == id)).first()

            if result is not None:

                mydict = json.loads(result.search_value)

                print("myquery--", mydict)

                mydoc = mongodbConn['talents'].find(mydict)

                for data in mydoc:
                    new_dict = data
                    del new_dict['_id']
                    new_result.append(new_dict)

                employer_search = {"status": statusCodeSuccess,
                                   "message": statusMessageSuccess, 'response': new_result}
                return employer_search
            else:
                employer_search = {"status": statusCodeFailure,
                                   "message": "Id does not match."}
                return employer_search
        else:
            employer_search = {"status": statusCodeFailure,
                               "message": "Id is required."}
            return employer_search

    def _get_all_search(self, token, id) -> Employer_search:
        employer_id = token.id

        mylist = []
        if id is None:
            result = self.db.query(Employer_search).filter(
                Employer_search.employer_id == employer_id).all()
            if result is not None:
                for data in result:
                    mydict = {}
                    mydict['id'] = data.id
                    mydict['employer_id'] = data.employer_id
                    mydict['search_name'] = data.search_name
                    mydict['created_on'] = data.created_on
                    mydict['search_value'] = json.loads(data.search_value)
                    mylist.append(mydict)

                    print("mydict------", mydict)
                    print("mydict------", data.search_value)

                employer_search = {"status": statusCodeSuccess,
                                   "message": statusMessageSuccess, 'response': mylist}
                return employer_search

        else:
            result = self.db.query(Employer_search).filter(
                and_(Employer_search.employer_id == employer_id, Employer_search.id == id)).first()
            if result is not None:
                mydict = {}
                mydict['id'] = result.id
                mydict['employer_id'] = result.employer_id
                mydict['search_name'] = result.search_name
                mydict['created_on'] = result.created_on
                mydict['search_value'] = json.loads(result.search_value)
                mylist.append(mydict)

                employer_search = {"status": statusCodeSuccess,
                                   "message": statusMessageSuccess, 'response': mylist}
                return employer_search
            else:
                employer_search = {"status": statusCodeFailure,
                                   "message": "Id does not match."}
                return employer_search
