from typing import List, Optional
from pydantic import BaseModel, ValidationError, validator, Field, PositiveInt
from ..validator_package import validation


class QuickSearch(BaseModel):

    industries: List[str] = None
    industry_location: List[str] = None
    search_name: Optional[str] = None
    id: Optional[int] = None


class DeleteSearch(BaseModel):

    id: int

    @validator('id')
    def id_validation(cls, id):
        return validation.check_blank_validation(id, "Id can not be blank")
