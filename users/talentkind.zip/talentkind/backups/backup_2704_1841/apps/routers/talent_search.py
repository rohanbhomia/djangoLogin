from fastapi import APIRouter, Depends, BackgroundTasks, File, UploadFile
from ..schemas.talent_search import *
from ..schemas.talent_login import _Talent_registerBase
from ..services.talent_search import *
from ..services.talent_profile import get_talent_current_user
from ..utils.service_result import handle_result
from ..config.database import get_db
import json

router = APIRouter(
    prefix="/api/talent",
    tags=["talent_search"],
    responses={404: {"description": "Not found"}},
)


@router.post("/quick_search/")
async def quick_search(schema: QuickSearch, background_tasks: BackgroundTasks, db: get_db = Depends()):

    result = TalenSearch(db).quick_search(schema)
    return handle_result(result)

# {{url}}/api/talent/quick_search/?id=21


@router.get("/quick_search/")
async def quick_search(background_tasks: BackgroundTasks, db: get_db = Depends(), token=Depends(get_talent_current_user), id: Optional[int] = None):
    print("hello world")
    result = TalenSearch(db).quick_search_by_id(id, token)
    return handle_result(result)


@router.post("/save_search/")
async def save_search(schema: QuickSearch, background_tasks: BackgroundTasks, db: get_db = Depends(), token=Depends(get_talent_current_user)):

    result = TalenSearch(db).save_search(schema, token)
    return handle_result(result)


@router.get("/get_all_search/")
async def get_all_search(background_tasks: BackgroundTasks, db: get_db = Depends(), token=Depends(get_talent_current_user), id: Optional[int] = None):

    result = TalenSearch(db).get_all_search(token, id)
    return handle_result(result)


@router.post("/update_search/")
async def update_search(schema: QuickSearch, background_tasks: BackgroundTasks, db: get_db = Depends(), token=Depends(get_talent_current_user)):

    result = TalenSearch(db).update_search(schema, token)
    return handle_result(result)


@router.post("/delete_search/")
async def delete_search(schema: DeleteSearch, background_tasks: BackgroundTasks, db: get_db = Depends(), token=Depends(get_talent_current_user)):

    result = TalenSearch(db).delete_search(schema, token)
    return handle_result(result)
