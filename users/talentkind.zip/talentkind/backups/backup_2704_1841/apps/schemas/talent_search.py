from typing import Optional, List, Dict
from pydantic import BaseModel, ValidationError, validator, Field, PositiveInt
from fastapi import FastAPI, Query
from pydantic.dataclasses import dataclass
from ..validator_package import validation


class QuickSearch(BaseModel):

    job_type: str
    category_name: Optional[str]
    profession: Optional[str]
    location: Optional[str]
    experience: Optional[str]
    pay_range: Optional[str]
    essential_skills: Optional[str]
    search_name: Optional[str]
    id: Optional[int]

    @validator('job_type')
    def job_type_validation(cls, job_type):
        return validation.check_blank_validation(job_type, "Job type can not be blank")


class DeleteSearch(BaseModel):

    id: int

    @validator('id')
    def id_validation(cls, id):
        return validation.check_blank_validation(id, "Id can not be blank")
