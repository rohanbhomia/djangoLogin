from xmlrpc.client import boolean
from sqlalchemy import Column, Integer, String, Text, DateTime,Boolean
from ..config.database import Base

class Talent_settings(Base):
	__tablename__ = "talent_settings"
	id = Column(Integer, primary_key=True, index=True)
	talent_id = Column(Integer)
	profile_visibility =  Column(Text)
	created_on = Column(DateTime)
	updated_on = Column(DateTime)