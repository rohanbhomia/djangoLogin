from apps.schemas.talent_search import QuickSearch
from ..schemas.talent_search import *
from ..schemas.talent_login import _Talent_registerBase
from ..utils.app_exceptions import AppException
from ..services.main import AppService, AppCRUD
from ..models.talent_search import *
from ..models.talent_login import Talent_register
from ..utils.service_result import ServiceResult
from fastapi import BackgroundTasks
from ..lib_packages.send_mail import send_email
from ..config.dependencies import JWT_SECRET,dateTime_at,conf,MessageSchema,FastMail,os,mongodb
from time import sleep
import passlib.hash as _hash
import base64
import random
import jwt
import datetime
import json
from sqlalchemy import or_,and_

mongodbConn = mongodb()


statusCodeSuccess = int(os.getenv('STATUS_200'))
statusMessageSuccess = os.getenv('MESSAGE_200')
statusCodeFailure = int(os.getenv('STATUS_409'))
statusMessageFailed = os.getenv('MESSAGE_409')


class TalenSearch(AppService):
    def quick_search(self, item: QuickSearch) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._quick_search(item)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)
    
    def quick_search_by_id(self,id,token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._quick_search_by_id(id,token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)
    
    def save_search(self, item: QuickSearch,token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._save_search(item,token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)


class SettingsCrud(AppCRUD):
    def _quick_search(self, item: QuickSearch) -> Talent_search:
       
        mydict = {}
        result = []

        

        if item.job_type is not None and item.job_type!='':
            mydict['job_type'] = item.job_type
        if item.category_name is not None and item.category_name!='':
            mydict['category_name'] = item.category_name
        if item.profession is not None and item.profession!='':
            mydict['profession'] = item.profession
        if item.location is not None and item.location!='':
            mydict['location'] = item.location
        if item.experience is not None and item.experience!='':
            mydict['experience'] = item.experience
        if item.pay_range is not None and item.pay_range!='':
            mydict['pay_range'] = item.pay_range
        if item.essential_skills is not None and item.essential_skills!='':
            mydict['essential_skills'] = item.essential_skills


        

        print("myquery--",mydict)

        mydoc = mongodbConn['jobs'].find(mydict)
 
        for data in mydoc:
            new_dict = data
            del new_dict['_id']
            result.append(new_dict)
            
        talent_search = {"status" : statusCodeSuccess, "message" : statusMessageSuccess,'response':result}
        return talent_search
    
    def _quick_search_by_id(self,id,token) -> Talent_search:
        talent_id = token.id
        mydict = {}
        new_result = []

        if id is not None:

            result = self.db.query(Talent_search).filter(and_(Talent_search.talent_id==talent_id,Talent_search.id==id)).first()

            if result is not None:

                mydict = json.loads(result.search_value)


                

                print("myquery--",mydict)

                mydoc = mongodbConn['jobs'].find(mydict)
        
                for data in mydoc:
                    new_dict = data
                    del new_dict['_id']
                    new_result.append(new_dict)
                    
                talent_search = {"status" : statusCodeSuccess, "message" : statusMessageSuccess,'response':new_result}
                return talent_search
            else:
                talent_search = {"status" : statusCodeFailure, "message" : "Id does not match."}
                return talent_search
        else:
            talent_search = {"status" : statusCodeFailure, "message" : "Id is required."}
            return talent_search



    
    def _save_search(self, item: QuickSearch,token) -> Talent_search:
        talent_id = token.id
        mydict = {}
        
        if item.search_name is None:
            talent_search = {"status" : statusCodeFailure, "message" : "Name is required"}
            return talent_search  
        else:  
            if item.job_type is not None and item.job_type!='':
                mydict['job_type'] = item.job_type
            if item.category_name is not None and item.category_name!='':
                mydict['category_name'] = item.category_name
            if item.profession is not None and item.profession!='':
                mydict['profession'] = item.profession
            if item.location is not None and item.location!='':
                mydict['location'] = item.location
            if item.experience is not None and item.experience!='':
                mydict['experience'] = item.experience
            if item.pay_range is not None and item.pay_range!='':
                mydict['pay_range'] = item.pay_range
            if item.essential_skills is not None and item.essential_skills!='':
                mydict['essential_skills'] = item.essential_skills

        
            talent_search = Talent_search(
            talent_id= talent_id,
            search_name= item.search_name,
            search_value= json.dumps(mydict),
            created_on=dateTime_at
            )
            self.db.add(talent_search)        
            self.db.commit()
            self.db.refresh(talent_search)

                
            talent_search = {"status" : statusCodeSuccess, "message" : 'Created successfully' }
            return talent_search