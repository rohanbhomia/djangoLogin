-- Adminer 4.8.1 MySQL 8.0.27 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `talent_search`;
CREATE TABLE `talent_search` (
  `id` int NOT NULL AUTO_INCREMENT,
  `talent_id` int NOT NULL,
  `search_name` varchar(100) NOT NULL,
  `search_value` text NOT NULL,
  `created_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

TRUNCATE `talent_search`;
INSERT INTO `talent_search` (`id`, `talent_id`, `search_name`, `search_value`, `created_on`) VALUES
(4,	39,	'My filter 2',	'{\"location\": \"Mumbai\", \"essential_skills\": \"Dancing\"}',	'2022-04-27 15:05:58'),
(5,	39,	'My filter 2',	'{\"location\": \"Mumbai\", \"essential_skills\": \"Dancing\"}',	'2022-04-27 15:05:58'),
(6,	39,	'My filter 2',	'{\"location\": \"Mumbai\", \"job_type\": \"\", \"essential_skills\": \"Dancing\"}',	'2022-04-27 15:09:04'),
(7,	39,	'new filter',	'{\"job_type\": \"office_job\", \"category_name\": \"\", \"profession\": \"\", \"location\": \"Mumbai\", \"experience\": \"\", \"pay_range\": \"\"}',	'2022-04-27 15:14:25'),
(8,	39,	'new filter2',	'{\"job_type\": \"office_job\", \"location\": \"Mumbai\"}',	'2022-04-27 15:17:26'),
(9,	39,	'new filter2',	'{\"location\": \"Mumbai\"}',	'2022-04-27 15:17:26');

-- 2022-04-27 10:02:55
