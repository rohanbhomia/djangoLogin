
from typing import Optional, List, Dict
from pydantic import BaseModel,validator

class getStatesFileds(BaseModel):
	country_name: str

	@validator('country_name', pre=True, always=True,allow_reuse=True)
	def check_names_not_empty(cls, v):
		assert v != '', 'Empty string not allowed.'
		return v

class getCitiesFileds(getStatesFileds):
	state_name: str

	@validator('country_name','state_name', pre=True, always=True,allow_reuse=True)
	def check_names_not_empty(cls, v):
		assert v != '', 'Empty string not allowed.'
		return v

class TalentPersonalInfo(BaseModel):
	display_name : str
	gender : str
	date_of_birth : str
	nationality: str
	state: str
	city: str
	pincode: int
	have_passport: int
	have_travelled_abroad: int
	avatar_url: Optional[str] = None

	@validator('display_name','gender','date_of_birth','nationality','state','city','pincode', pre=True, always=True,allow_reuse=True)
	def check_names_not_empty(cls, v):
		assert v != '', 'Empty string not allowed.'
		return v

class _TalentUsername(BaseModel):
	email: str
	mobile_number: int

class TalentUsername(_TalentUsername):
	id: int

	class Config:
		orm_mode = True

class TalentIndustries(BaseModel):
	talent_industries_array : List=[]
	
	@validator('talent_industries_array', pre=True, always=True,allow_reuse=True)
	def check_names_not_empty(cls, v):
		assert v != '', 'Empty array not allowed.'
		return v

class TalentIndustriesPrimary(BaseModel):
	code : str
	display_name : str
	is_primary : int
	
	@validator('code','display_name','is_primary', pre=True, always=True,allow_reuse=True)
	def check_names_not_empty(cls, v):
		assert v != '', 'Empty array not allowed.'
		return v

class TalentEducationBase(BaseModel):
	id : Optional[str] = None
	
	class Config:
		orm_mode = True

	# @validator('id', pre=True, always=True,allow_reuse=True)
	# def check_names_not_empty(cls, v):
	# 	assert v != '', 'Id not found.'
	# 	return v

class TalentEducation(TalentEducationBase):
	education : str
	subject : Optional[str] = None
	university: str
	year_of_passing: int
	type: str
	
	@validator('education','university','year_of_passing','type', pre=True, always=True,allow_reuse=True)
	def check_names_not_empty(cls, v):
		assert v != '', 'Empty string not allowed.'
		return v

class TalentIndustryProfession(BaseModel):
	talent_profession_array : List=[]
	off_screen_val_other : Dict={}

	@validator('talent_profession_array', pre=True, always=True,allow_reuse=True)
	def check_names_not_empty(cls, v):
		assert v != '', 'Empty array not allowed.'
		return v

class OnScreenTalentTypeProfession(BaseModel):
	profession_code : str
	@validator('profession_code', pre=True, always=True,allow_reuse=True)
	def check_names_not_empty(cls, v):
		assert v != '', 'Empty string not allowed.'
		return v
	class Config:
		orm_mode = True

class OnScreenTalentType(OnScreenTalentTypeProfession):
	profession_name : str
	profession : List=[]
	@validator('profession_name','profession', pre=True, always=True,allow_reuse=True)
	def check_names_not_empty(cls, v):
		assert v != '', 'Empty string not allowed.'
		return v
		

class GetTalentLanguageFileds(BaseModel):
	mother_tongue_lang : Dict={}
	language_array : List=[]
	language_skills_other : Optional[str] = None
	primary_location : Dict={}
	location_array : List=[]
	industry_location_other : Optional[str] = None


	@validator('mother_tongue_lang','primary_location', pre=True, always=True,allow_reuse=True)
	def check_names_not_empty(cls, v):
		assert v != '', 'Empty array not allowed.'
		return v

class ProfileIntroFileds(BaseModel):
	additional_information : Optional[str] = None
	personal_website : Optional[str] = None
	personal_blog : Optional[str] = None
	instagram: Optional[str] = None
	behance: Optional[str] = None
	IMDB: Optional[str] = None

	# @validator('additional_information','personal_website','personal_blog','instagram','behance','IMDB', pre=True, always=True,allow_reuse=True)
	# def check_names_not_empty(cls, v):
	# 	assert v != '', 'Empty string not allowed.'
	# 	return v

	class Config:
		orm_mode = True

class WorkCreditsFileds(BaseModel):
	id : Optional[str] = None
	
	class Config:
		orm_mode = True

class NewWorkCreditsFileds(WorkCreditsFileds):
	production_type : str
	code : str
	start_year_month : str
	end_year_month : str
	production_name : str
	role : str
	production_house : str
	

	@validator('production_type','code','start_year_month','end_year_month','production_name','role','production_house', pre=True, always=True,allow_reuse=True)
	def check_names_not_empty(cls, v):
		assert v != '', 'Empty string not allowed.'
		return v
	class Config:
		orm_mode = True

class TalentPhysicalAppearance(BaseModel):
	ethnicity : str
	feet_height : str
	inch_height: str
	skin_tone: str
	weight: str
	eye_colour: str
	build: str
	hair_colour: str
	playing_age: str
	hair_length: str
	
	@validator('ethnicity','feet_height','inch_height','skin_tone','weight','eye_colour','build','hair_colour','playing_age','hair_length', pre=True, always=True,allow_reuse=True)
	def check_names_not_empty(cls, v):
		assert v != '', 'Empty string not allowed.'
		return v

# class validate(BaseModel):
# 	name: str
# 	email: str

class TalentSkillsetInterest(BaseModel):
	experienced_in : List=[]
	interested_in : List=[]
	singing_in : List=[]
	singing_in_other : Optional[str] = None
	dancing_in : List=[]
	dancing_in_other : Optional[str] = None
	musical_in : List=[]
	musical_in_other : Optional[str] = None
	skills_in : List=[]
	skills_in_other : Optional[str] = None
	on_screen_performance : Dict={}

class TalentAgentRepresentation(BaseModel):
	have_agent : Optional[int] = None
	agency_name: str
	agent_email: str
	telephone: int
	agent_website: str
	covering_industries: str
	agent_alert_message: Optional[int] = None
	agent_looking_profile: Optional[int] = None

class Slug(BaseModel):
	slug :  str




