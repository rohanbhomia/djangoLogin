from pydantic import BaseModel,validator
from typing import List

class MediaType(BaseModel):
	media_type: str
	
	class Config:
		orm_mode = True
		
class TalentImages(MediaType):
	portfolio: List=[]

class TalentAlbum(BaseModel):
	album_name: str
	media_type: str

class AddTalentAlbum(BaseModel):
	album_id: int
	media_type: str
	medias: List=[]

class TalentPortfolio(BaseModel):
	id: int
	media_type: str

	class Config:
		orm_mode = True

class TalentAlbumPortfolio(TalentPortfolio):
	album_id: int

class TalentPortfolioSave(BaseModel):
	id:int
	media_type:str
	name:str
	year:str
	other:str