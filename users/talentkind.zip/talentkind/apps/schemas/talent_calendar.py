from typing import Optional, List, Dict
from xmlrpc.client import DateTime
from pydantic import BaseModel,validator,Field, PositiveInt,ValidationError
from fastapi import FastAPI, Query
from pydantic.dataclasses import dataclass
from ..validator_package import validation

class EventSchemaBaseAppointment(BaseModel):
    salutation: str
    start: str
    end: str
    appointment_date: str
    event_type: str
    title: str
    description: Optional[str] = None
    
    @validator('event_type')
    def event_type_validation(cls, event_type):
        return validation.name_validation(event_type,'Event type is required ')

    @validator('salutation')
    def solution_validation(cls, salutation):
        return validation.name_validation(salutation,'Salutation is required')    

    @validator('title')
    def event_title_validation(cls, title):
        return validation.name_validation(title,'Event title is required')

class EventSchemaCreateAppointment(EventSchemaBaseAppointment):
    id: int
    class Config:
        orm_mode = True    
    
class EventSchemaBaseWorkEngagement(BaseModel):
    event_type: str
    title: str
    start_date: str
    end_date: str
    description: Optional[str] = None

    @validator('title')
    def event_title_validation(cls, title):
        return validation.name_validation(title,'Event title is required') 

    @validator('event_type')
    def event_type_validation(cls, event_type):
        return validation.name_validation(event_type,'Event type is required ')


    @validator('start_date')
    def start_date_validation(cls, start_date):
        return validation.check_date_format(start_date)

    @validator('end_date')
    def end_date_validation(cls, end_date):
        return validation.check_date_format(end_date)     

class EventSchemaCreateWorkEengagement(EventSchemaBaseWorkEngagement):
    id: int
    class Config:
        orm_mode = True 

    
    

class AllEventSchema(BaseModel):
    start:  Optional[str] = None
    end:  Optional[str] = None