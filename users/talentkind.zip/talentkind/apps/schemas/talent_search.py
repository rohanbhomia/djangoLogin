from typing import Optional, List, Dict
from pydantic import BaseModel, ValidationError, validator, Field, PositiveInt
from ..validator_package import validation


class QuickSearch(BaseModel):

    job_type: List[str] = None
    category_name: List[str] = None
    role: List[str] = None
    location: List[str] = None
    experience: List[str] = None
    pay_range: List[str] = None
    essential_skills: List[str] = None
    search_name: Optional[str]
    id: Optional[int]


class DeleteSearch(BaseModel):

    id: int

    @validator('id')
    def id_validation(cls, id):
        return validation.check_blank_validation(id, "Id can not be blank")
