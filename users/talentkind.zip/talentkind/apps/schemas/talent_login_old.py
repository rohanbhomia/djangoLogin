from typing import Optional, List, Dict
from pydantic import BaseModel,ValidationError,validator,Field, PositiveInt
from fastapi import FastAPI, Query
from pydantic.dataclasses import dataclass

# app = FastAPI()

class _Talent_registerBase(BaseModel):
    first_name: str 
    last_name : str
    mobile_number : int
    #email: str
    email: str = Query(..., max_length=50,  title='Valid email id',description='this is the value of snap', regex='[^@]+@[^@]+\.[^@]+',)


# @dataclass(config=TalentRegConfig) 
class TalentRegisterCreate(_Talent_registerBase):
    password: str
    class Config:
        orm_mode = True
        
       
    @validator('first_name')
    def first_name_not_empty(cls, first_name):
        if first_name == '':
            raise ValueError('First name is required')
        elif first_name.isalpha() is False:
            raise ValueError('Invalid first name')
        return first_name.title()

    @validator('last_name')
    def last_name_not_empty(cls, last_name):
        if last_name == '':
            raise ValueError('Last name is required')
        elif last_name.isalpha() is False:
            raise ValueError('Invalid last name')
        return last_name.title()
    
    @validator('mobile_number')
    def mobile_number_not_empty(cls, mobile_number):
        if len(str(mobile_number)) > 10 or len(str(mobile_number)) < 10:
            raise ValueError("Mobile Number should be 10 digit only")
        elif int(str(mobile_number)[:1]) < 6:
            raise ValueError("Please enter valid mobile number")
        return mobile_number

    @validator('email')
    def email_not_empty(cls, email):
        #print("email address", email)
        if email == '':
            raise ValueError('Email is required')
        return email
    

    
        
class _TalentUsername(BaseModel):
    email: str
    mobile_number: int

class TalentUsername(_TalentUsername):
    id: int

    class Config:
        orm_mode = True

class ResendOtp(BaseModel):
    enc_id : str
    
    
class VerifyOtpWithOtp(BaseModel):
    enc_id : str
    otp: int
    
class TalentLogin(BaseModel):
    username: str
    password: str
