from typing import Optional, List, Dict
from pydantic import BaseModel,ValidationError,validator,Field, PositiveInt
from fastapi import FastAPI, Query
from pydantic.dataclasses import dataclass
from ..validator_package import validation
from ..validator_package.validations_errors import *
#from ..validations_errors import *

class _Talent_registerBase(BaseModel):
    first_name: str 
    last_name : str
    mobile_number : int
    email: str
    #email: str = Query(..., max_length=50,  title='Valid email id',description='this is the value of snap', regex='[^@]+@[^@]+\.[^@]+',)

class TalentRegisterCreate(_Talent_registerBase):
    password: str
    #confirm_password: str
    class Config:
        orm_mode = True
    
    @validator('first_name')
    def first_name_validation(cls, first_name):
        return validation.name_validation(first_name,FIRST_NAME_ERROR)

    @validator('last_name')
    def last_name_validation(cls, last_name):
        return validation.name_validation(last_name,LAST_NAME_ERROR)
    
    @validator('mobile_number')
    def mobile_number_validation(cls, mobile_number):
        return validation.mobile_validation(mobile_number)

    @validator('email')
    def email_validation(cls, email):
        return validation.email_validation(email,EMAIL_ERROR)
    
    @validator('password')
    def password_validation(cls, password):
        return validation.check_blank_validation(password,PASSWORD_ERROR)

    # @validator('confirm_password')
    # def confirm_password_validation(cls, confirm_password):
    #     return validation.check_blank_validation(confirm_password,validations_errors.CONFIRM_PASSWORD_ERROR)

    # @validator('password','confirm_password')
    # def match_password_validation(cls, password, confirm_password):
    #     return validation.match_password(password,confirm_password)
    
class _TalentUsername(BaseModel):
    email: str
    mobile_number: int

class TalentUsername(_TalentUsername):
    id: int

    class Config:
        orm_mode = True

class ResendOtp(BaseModel):
    enc_id : str
    
    
class VerifyOtpWithOtp(BaseModel):
    enc_id : str
    otp: int
    
class TalentLogin(BaseModel):
    username: str
    password: str
