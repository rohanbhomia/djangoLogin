from fastapi import APIRouter, Depends, BackgroundTasks
from ..schemas.employer_search import *
from ..services.employer_login import *
from ..services.employer_search import *
from ..utils.service_result import handle_result
from ..config.database import get_db
from ..services.employer_profile import get_employer_current_user
from ..services.employer_job_posting import *

router = APIRouter(
    prefix="/api/employer",
    tags=["employer_search"],
    responses={404: {"description": "Not found."}},
)


@router.get("/get_all_keywords/")
async def get_all_keywords(background_tasks: BackgroundTasks, db: get_db = Depends(), token=Depends(get_employer_current_user), id: Optional[int] = None):
    print("empid---", token.id)
    result = EmployerSearch(db).get_all_keywords(token)
    return handle_result(result)


@router.post("/quick_search/")
async def quick_search(schema: QuickSearch, background_tasks: BackgroundTasks, db: get_db = Depends()):

    result = EmployerSearch(db).quick_search(schema)
    return handle_result(result)


@router.get("/quick_search/")
async def quick_search(background_tasks: BackgroundTasks, db: get_db = Depends(), token=Depends(get_employer_current_user), id: Optional[int] = None):
    print("hello world")
    result = EmployerSearch(db).quick_search_by_id(id, token)
    return handle_result(result)


@router.post("/save_search/")
async def save_search(schema: SaveSearch, background_tasks: BackgroundTasks, db: get_db = Depends(), token=Depends(get_employer_current_user)):

    result = EmployerSearch(db).save_search(schema, token)
    return handle_result(result)


@router.post("/update_search/")
async def update_search(schema: QuickSearch, background_tasks: BackgroundTasks, db: get_db = Depends(), token=Depends(get_employer_current_user)):

    result = EmployerSearch(db).update_search(schema, token)
    return handle_result(result)


@router.post("/delete_search/")
async def delete_search(schema: DeleteSearch, background_tasks: BackgroundTasks, db: get_db = Depends(), token=Depends(get_employer_current_user)):

    result = EmployerSearch(db).delete_search(schema, token)
    return handle_result(result)


@router.get("/get_all_search/")
async def get_all_search(background_tasks: BackgroundTasks, db: get_db = Depends(), token=Depends(get_employer_current_user), id: Optional[int] = None):

    result = EmployerSearch(db).get_all_search(token, id)
    return handle_result(result)
