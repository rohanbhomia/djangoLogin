from fastapi import APIRouter, Depends, BackgroundTasks, Header, FastAPI, UploadFile, File, Request
from ..schemas.talent_portfolio import *
from ..services.talent_portfolio import *
from ..services.talent_profile import get_talent_current_user
from ..utils.service_result import handle_result
from ..config.database import get_db
import shutil

#SWATI only for upload_portfolio
from fastapi import  File, UploadFile, Form
#SWATI


router =APIRouter(
    prefix="/api/talent",
    tags=["portfolio"],
    responses={404: {"description": "Not found"}},
)

import logging
logger = logging.getLogger("app:" + __name__)

# @router.post("/upload_temp_images/")
# async def upload_temp_images(TalentImages:TalentImages, background_tasks: BackgroundTasks, token = Depends(get_talent_current_user), db: get_db = Depends()):    
#     result = await upload_temp_images(TalentImages,background_tasks,token,db)
#     return handle_result(result)

#KAMLESH
# @router.post("/upload_portfolio/")
# async def upload_portfolio(talentImages:TalentImages, background_tasks: BackgroundTasks, token = Depends(get_talent_current_user), db: get_db = Depends()):
#     result = await temp_upoload_portfolio(talentImages,background_tasks,token,db)
#     return handle_result(result)
#KAMLESH

#SWATI
@router.post("/upload_portfolio/")
async def upload_portfolio(request: Request, files: List[UploadFile] =File(...), media_type: str = Form(...), background_tasks: BackgroundTasks = BackgroundTasks(), token = Depends(get_talent_current_user), db: get_db = Depends()):
        result = await temp_upoload_portfolio(request, files,media_type,background_tasks, token,db)
        return handle_result(result)
        #print("files====>>>>",[file.filename for file in files])  
        #return {"filesname":[file.filename for file in files]}
        # for img in files:
        #     # with open(f"{img.filename}", "wb") as buffer:
        #     #     shutil.copyfileobj(img.file, buffer)
        #     imageName = str(12)+'_'+str(random.randint(1000, 9999))+"_portfolio"
        #     fileName = str(FOLDER_NAME)+imageName
        #     with open(fileName, "wb") as buffer:
        #         shutil.copyfileobj(img.file, buffer)
        #     return imageName
        # return 'success'
#SWATI

@router.post("/update_talent_portfolio/")
async def update_talent_portfolio(talentPortfolioSave:TalentPortfolioSave, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = PortfolioService(db).updatePortfolio(talentPortfolioSave,token)
    return handle_result(result)

@router.post("/delete_talent_portfolio/")
async def delete_talent_portfolio(talentPortfolio:TalentPortfolio, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = PortfolioService(db).deletePortfolio(talentPortfolio,token)
    return handle_result(result)

@router.post("/create_talent_album/")
async def create_talent_album(albumSchema:TalentAlbum, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = PortfolioService(db).createAlbum(albumSchema,token)
    return handle_result(result)

@router.post("/delete_talent_albums/")
async def delete_talent_albums(talentPortfolio:TalentPortfolio, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = PortfolioService(db).deleteAlbum(talentPortfolio,token)
    return handle_result(result)
    
@router.post("/get_talent_albums/")
async def get_talent_albums(mediaTypeSchema:MediaType, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = PortfolioService(db).getTalentAlbums(mediaTypeSchema,token)
    return handle_result(result)

@router.post("/get_talent_portfolio/")
async def get_talent_portfolio(mediaTypeSchema:MediaType, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = PortfolioService(db).getPortfolio(mediaTypeSchema,token)
    return handle_result(result)

@router.post("/add_album_photos/")
async def add_album_photos(addalbumSchema:AddTalentAlbum, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = PortfolioService(db).addAlbumPhotos(addalbumSchema,token)
    return handle_result(result)

@router.post("/get_album_photos/")
async def get_album_photos(getalbumSchema:TalentPortfolio, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = PortfolioService(db).getAlbumPhotos(getalbumSchema,token)
    return handle_result(result)

@router.post("/get_single_portfolio/")
async def get_single_portfolio(talentPortfolio:TalentPortfolio, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = PortfolioService(db).getSinglePortfolio(talentPortfolio,token)
    return handle_result(result)

@router.post("/get_single_album_portfolio/")
async def get_single_album_portfolio(talentAlbumPortfolio:TalentAlbumPortfolio, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = PortfolioService(db).getSingleAlbumPortfolio(talentAlbumPortfolio,token)
    return handle_result(result)

@router.post("/upload_awards/")
async def upload_awards(request: Request, files: List[UploadFile] =File(...), name: str = Form(...), year: str = Form(...), other: str = Form(...), token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = await save_awards(request, files, name, year, other, token, db)
    return handle_result(result)

@router.get("/get_media_flags/")
async def get_media_flags(token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = PortfolioService(db).getMediaFlags(token)
    return handle_result(result)


















