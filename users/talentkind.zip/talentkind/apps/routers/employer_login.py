from fastapi import APIRouter, Depends, BackgroundTasks
from ..schemas.employer_login import *
from ..services.employer_login import *
from ..utils.service_result import handle_result
from ..config.database import get_db
from ..services.talent_profile import get_talent_current_user


router =APIRouter(
    prefix="/api/employer",
    tags=["employer_login"],
    responses={404: {"description": "Not found"}},
)

@router.post("/registration/")
async def registration(registerSchema:EmployerRegisterCreate, background_tasks: BackgroundTasks, db: get_db = Depends()):
    print("hello")
    result = await create_employer(registerSchema,db,background_tasks)
    return handle_result(result)
    #IF WE USED CLASSES WE NEED TO FOLLOW THIS PROCESS
    # result = RegistrationService(db).create_talent(talent)
    # return handle_result(result)

@router.post("/resendOtp/")
async def resendOtp(resendotp:ResendOtp, background_tasks: BackgroundTasks, db: get_db = Depends()):
    result = await resend_otp(resendotp,db,background_tasks)
    return handle_result(result)

@router.post("/verifyOtp/")
async def verifyOtp(verifyOtp:VerifyOtpWithOtp, db: get_db = Depends()):
    result = VerifyOtpService(db).verifyOtp(verifyOtp)
    return handle_result(result)

@router.post("/login/")
async def login(loginSchema: EmployerLogin, db: get_db = Depends()):
    result = LoginService(db).login(loginSchema)
    return handle_result(result)






    
