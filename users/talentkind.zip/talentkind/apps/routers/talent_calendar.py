from fastapi import APIRouter, Depends, BackgroundTasks
from ..schemas.talent_calendar import *
from ..services.talent_calendar import EventService
from ..services.talent_profile import get_talent_current_user
from ..utils.service_result import handle_result
from ..config.database import get_db

router =APIRouter(
    prefix="/api/talent",
    tags=["calendar"],
    responses={404: {"description": "Not found"}},
)

import logging
logger = logging.getLogger("app:" + __name__)

@router.post("/create_appointment/")
async def add_event(item: EventSchemaBaseAppointment, token = Depends(get_talent_current_user), db: get_db = Depends()):    
    result = EventService(db).create_event_appointment(item,token)    
    return handle_result(result)

@router.post("/update_appointment/")
async def update_event(item: EventSchemaCreateAppointment,token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = EventService(db).update_event_appointment(item,token)    
    return handle_result(result)

@router.post("/create_work_engagement/")
async def add_event(item: EventSchemaBaseWorkEngagement, token = Depends(get_talent_current_user), db: get_db = Depends()):   
    result = EventService(db).create_event_work_engagement(item,token)   
    return handle_result(result)

@router.post("/update_work_engagement/")
async def update_event(item: EventSchemaCreateWorkEengagement,token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = EventService(db).update_event_work_engagement(item,token)    
    return handle_result(result)

@router.get("/get_event/{event_id}")
async def find_event(event_id: int, db: get_db = Depends()):
    result = EventService(db).get_event(event_id)
    return handle_result(result)      

@router.post("/get_all_event/")
async def find_all_event(item:AllEventSchema,token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = EventService(db).get_all_event(item,token)   
    return handle_result(result)




















