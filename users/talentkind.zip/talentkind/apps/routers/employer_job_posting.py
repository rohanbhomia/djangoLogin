from fastapi import APIRouter, Depends, BackgroundTasks
from ..schemas.employer_job_posting import *
from ..services.employer_login import *
from ..utils.service_result import handle_result
from ..config.database import get_db
from ..services.employer_profile import get_employer_current_user
from ..services.employer_job_posting import *

router =APIRouter(
    prefix="/api/employer",
    tags=["employer_job_posting"],
    responses={404: {"description": "Not found."}},
)



@router.post("/create_job/")
async def create_job(schema:CreateJob,background_tasks: BackgroundTasks, db: get_db = Depends(),token = Depends(get_employer_current_user)):
    
    result = EmployerSettings(db).create_job(schema,token)
    return handle_result(result)

@router.post("/create_job_two/")
async def create_job(schema:CreateJobTwo,background_tasks: BackgroundTasks, db: get_db = Depends(),token = Depends(get_employer_current_user)):
    
    result = EmployerSettings(db).create_job_two(schema,token)
    return handle_result(result)

@router.post("/create_job_three/")
async def create_job(schema:CreateJobThree,background_tasks: BackgroundTasks, db: get_db = Depends(),token = Depends(get_employer_current_user)):
    
    result = EmployerSettings(db).create_job_three(schema,token)
    return handle_result(result)

@router.post("/update_job/")
async def update_job(schema:CreateJob,background_tasks: BackgroundTasks, db: get_db = Depends(),token = Depends(get_employer_current_user)):
    
    result = EmployerSettings(db).update_job(schema,token)
    return handle_result(result)

@router.post("/update_job_two/")
async def update_job(schema:CreateJobTwo,background_tasks: BackgroundTasks, db: get_db = Depends(),token = Depends(get_employer_current_user)):
    
    result = EmployerSettings(db).update_job_two(schema,token)
    return handle_result(result)

@router.post("/update_job_three/")
async def update_job(schema:CreateJobThree,background_tasks: BackgroundTasks, db: get_db = Depends(),token = Depends(get_employer_current_user)):
    
    result = EmployerSettings(db).update_job_three(schema,token)
    return handle_result(result)


@router.get("/get_all_job/")
async def get_all_jobs(db: get_db = Depends()):
      
    result = EmployerSettings(db).get_all_jobs()
    return handle_result(result)

@router.get("/get_job/")
async def get_jobs(id: Optional[int] = None,db: get_db = Depends(),token = Depends(get_employer_current_user)):
    print("qqqqq",id)
    result = EmployerSettings(db).get_jobs(id,token)
    return handle_result(result)

@router.post("/search_jobs/")
async def get_jobs(schema:SearchJobs,db: get_db = Depends(),token = Depends(get_employer_current_user)):
      
    result = EmployerSettings(db).search_jobs(schema,token)
    return handle_result(result)

