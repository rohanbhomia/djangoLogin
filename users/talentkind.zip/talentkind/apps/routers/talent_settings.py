from fastapi import APIRouter, Depends, BackgroundTasks,File, UploadFile 
from ..schemas.talent_settings import *
from ..schemas.talent_login import _Talent_registerBase
from ..services.talent_settings import *
from ..services.talent_profile import get_talent_current_user
from ..utils.service_result import handle_result
from ..config.database import get_db
import json

router =APIRouter(
	prefix="/api/talent",
	tags=["talent_agent_representation"],
	responses={404: {"description": "Not found dfsfdsmkjnbjmbnhafa"}},
)


@router.post("/talent_update_notification/")
async def talent_update_notification(item: TalentNotificationSchema, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = TalentSettings(db).add_notification(item,token)
    return handle_result(result)

@router.get("/talent_get_notification/")
async def talent_get_notification( token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = TalentSettings(db).get_notification(token)
    return handle_result(result)

@router.post("/talent_delete_account/")
async def talent_delete_account(item:DeleteAccountSchema,token = Depends (get_talent_current_user), db: get_db = Depends()):
    result = TalentSettings(db).delete_account(item,token)
    return handle_result(result)

@router.post("/talent_change_status/")
async def talent_change_status(item: ChangeStatusSchema,token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = TalentSettings(db).change_status(item, token)
    return handle_result(result)

@router.post("/talent_update_account/")
async def talent_update_account(item: _Talent_registerBase,token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = TalentSettings(db).update_account(item,token)
    return handle_result(result)

@router.get("/talent_get_account/")
async def talent_get_account(token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = TalentSettings(db).get_account(token)
    return handle_result(result)

@router.post("/talent_change_password/")
async def talent_change_password(item: ChangePassword,token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = TalentSettings(db).change_password(item,token)
    return handle_result(result)

@router.post("/talent_update_profile_visibility/")
async def talent_profile_visibility(item: TalentProfileVisibility,token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = TalentSettings(db).talent_profile_visibility(item,token)
    return handle_result(result)

@router.get("/talent_get_profile_visibility/")
async def talent_get_profile_visibility(token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = TalentSettings(db).get_talent_profile_visibility(token)
    return handle_result(result)