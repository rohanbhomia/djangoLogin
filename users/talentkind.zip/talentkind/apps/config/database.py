import mysql.connector
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

SQLALCHEMY_DATABASE_URL = "mysql+pymysql://root:1100@localhost/talent_kind_new"
#SQLALCHEMY_DATABASE_URL =  "mysql+pymysql://root:TKmysql45!1@localhost/talent_kind"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL,
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    db = None
    try:
        db = SessionLocal()
        yield db
    finally:
        db.close()


def create_tables():
    Base.metadata.create_all(bind=engine)


mydb = mysql.connector.connect(host="localhost", user="root",
                               password="1100", database="talent_kind_new", use_unicode=True)
mysqlConnection = mydb.cursor(buffered=True)

#import mysql.connector
#mydb = mysql.connector.connect(host="localhost",user="root",password="TKmysql45!1",database="talent_kind")
#mysqlConnection = mydb.cursor(buffered=True)
