#ENVIRONMENT
import os
from dotenv import load_dotenv
load_dotenv('.env')
from fastapi_mail import FastMail, MessageSchema, ConnectionConfig
conf = ConnectionConfig(
    MAIL_USERNAME = os.getenv('MAIL_USERNAME'),
    MAIL_PASSWORD = os.getenv('MAIL_PASSWORD'),
    MAIL_FROM  = os.getenv('MAIL_FROM'),
    MAIL_PORT = 587,
    MAIL_SERVER = os.getenv('MAIL_SERVER'),
    MAIL_TLS = True,
    MAIL_SSL = False
)

#TOKEN
import fastapi.security as _security
oauth2schema = _security.OAuth2PasswordBearer(tokenUrl="/api/token")
JWT_SECRET = "talentKindjwtsecret"      ###    myjwtsecret 

#DATE TIME
import datetime
# def currentDateTime():
#     currentDay = datetime.datetime.today()
#     dateTime_at = currentDay.strftime('%Y-%m-%d %H:%M:%S')
#     return dateTime_at

currentDay = datetime.datetime.today()
dateTime_at = currentDay.strftime('%Y-%m-%d %H:%M:%S')

###     CREATE LOGGER FOLDER AND UPLOADS FOLDER INITIALLY   
from pathlib import Path
from os import path
FOLDER_NAME = str(Path(__file__).resolve().parent.parent.parent) + os.getenv('FOLDER_NAME')
LOGGER_FOLDER_NAME = str(Path(__file__).resolve().parent.parent.parent) + os.getenv('LOGGER_FOLDER_NAME')

if not path.exists(FOLDER_NAME):
    new_path = os.path.join(str(Path(__file__).resolve().parent.parent.parent), os.getenv('DIRECTORY_NAME'))
    os.mkdir(new_path,775)

if not path.exists(LOGGER_FOLDER_NAME):
    logger_new_path = os.path.join(str(Path(__file__).resolve().parent.parent.parent), os.getenv('LOGGER_DIRECTORY_NAME'))
    os.mkdir(logger_new_path,775)

####    LOGGER
import logging
import logging.handlers
import sys

from pathlib import Path

loggerFileName = str(LOGGER_FOLDER_NAME)+'log_file.log'
rotatingHandler = logging.handlers.RotatingFileHandler(filename=loggerFileName, maxBytes=1000, backupCount=5)
rotatingHandler.setLevel(logging.ERROR)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
rotatingHandler.setFormatter(formatter)
logging.getLogger().addHandler(rotatingHandler)
###     CREATE LOGGER FOLDER AND UPLOADS FOLDER INITIALLY 

#FOR MONGO CONNECTIONS
import pymongo
from pymongo.errors import OperationFailure
import fastapi
def mongodb():
    logger = logging.getLogger("app:" + __name__)
    mongoConnStr = os.getenv('MONGO_CONN_STR')
    try:
        client = pymongo.MongoClient(mongoConnStr)
        try:
            client.server_info()
            try:
                mongodb = client.talentkind
                return mongodb
            except OperationFailure as e:
                logger.error(e)
                raise fastapi.HTTPException(
                    status_code=409, detail=e
                )
        except OperationFailure as e:
            logger.error(e)
            raise fastapi.HTTPException(
                status_code=409, detail=e
            )
    except Exception as e:
        logger.error("IP NOT Whitelisted, An existing connection was forcibly closed by the remote host")
        raise fastapi.HTTPException(
            status_code=409, detail="IP NOT Whitelisted, An existing connection was forcibly closed by the remote host"
        )