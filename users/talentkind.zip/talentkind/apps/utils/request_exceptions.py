from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.status import HTTP_422_UNPROCESSABLE_ENTITY
from pydantic import error_wrappers as ew
from ..validator_package import validation
import os


async def http_exception_handler(
    request: Request, exc: HTTPException
) -> JSONResponse:
    # print("http_exception_handler=====>", exc.detail)
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "status": exc.status_code,
            "message": exc.detail,
        },
    )
    #return JSONResponse({"status":exc.status_code,"message": exc.detail}, status_code=exc.status_code)

# async def request_validation_exception_handler(request: Request, exc: RequestValidationError):
#     message = ''
   
#     etype = ''
#     for x in exc.errors():
#         fields = [entry for entry in x['loc'] if entry != 'body']

#         #print("len of fields", len(fields))

#         etype = x['type']
#         if etype == "value_error.missing":
#             error_message = fields[0].title().replace("_", " ") + ' field is missing'
#             #message.update({fields[0]: error_message}) 
#             message =  error_message
#         elif len(fields) == 0:
#             message = 'invalid request'
#         elif len(fields) == 1:
#             message = x['msg']
#         else:
#             # for dict / list with errors inside it
#             field_root = fields[0]
#             del(fields[0])       
#     return JSONResponse(
#         status_code=int(os.getenv('STATUS_422')),
#         content={
#             "status": int(os.getenv('STATUS_422')),
#             "message": message,
#         },
#     )


async def request_validation_exception_handler(request: Request, exc: RequestValidationError):
    message = ''
    etype = ''
    print("request_validation_exception_handler=====>", exc.errors())
    for x in exc.errors():
        fields = [entry for entry in x['loc'] if entry != 'body']
        etype = x['type']
        emsg = x['msg']
        custome_message = validation.checkInvalid(etype, fields, emsg)
        if custome_message is not None:
            message = custome_message
        else:  
            field_root = fields[0]
            del(fields[0]) 

    return JSONResponse(
        status_code=int(os.getenv('STATUS_422')),
        content={
            "status": int(os.getenv('STATUS_422')),
            "message": message,
        },
    )
