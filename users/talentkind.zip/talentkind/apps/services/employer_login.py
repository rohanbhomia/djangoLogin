from ..schemas.employer_login import *
from ..utils.app_exceptions import AppException
from ..services.main import AppService, AppCRUD
from ..models.employer_login import *
from ..models.talent_login import Mail_bodies
from ..utils.service_result import ServiceResult
from fastapi import BackgroundTasks
from ..lib_packages.send_mail import send_email
from ..config.dependencies import JWT_SECRET,dateTime_at,conf,MessageSchema,FastMail,os
from ..validator_package.validations_errors import *
from time import sleep
import passlib.hash as _hash
import base64
import random
import jwt
import datetime
import fastapi

statusCodeSuccess = int(os.getenv('STATUS_200'))
statusMessageSuccess = os.getenv('MESSAGE_200')
statusCodeFailure = int(os.getenv('STATUS_409'))
statusMessageFailed = os.getenv('MESSAGE_409')


async def create_employer(registerSchema:EmployerRegisterCreate,db,background_tasks: BackgroundTasks):
    email = registerSchema.email
    mobile_number = registerSchema.mobile_number
    first_name = registerSchema.first_name
    last_name = registerSchema.last_name
    password = registerSchema.password
    confirm_password = registerSchema.confirm_password

    if password!=confirm_password:
        return ServiceResult(AppException.CreateValidation(MATCH_PASSWORD_ERROR))

    employer_register = db.query(Employer_register).filter((Employer_register.email == email) | (Employer_register.mobile_number == mobile_number)).first()
    if employer_register:
        return ServiceResult(AppException.CreateValidation(ALREADY_EXISTS))

    temp_employer_register=db.query(Temp_employer_register).filter((Temp_employer_register.email == email) | (Temp_employer_register.mobile_number == mobile_number)).first()
    print('hello2')
    if temp_employer_register:
        temp_employer_register.otp = 0
        temp_employer_register.password = _hash.bcrypt.hash(password)
        temp_employer_register.first_name = first_name
        temp_employer_register.last_name = last_name
        temp_employer_register.created_on = dateTime_at
        temp_employer_register.updated_on = dateTime_at
        db.add(temp_employer_register)
        db.commit()
        db.refresh(temp_employer_register)

        background_tasks.add_task(generateOtp, temp_employer_register.id, db)
        displayName = str(first_name)+' '+str(last_name)

        ##ID ECRYPTION
        enc_id = base64.b64encode(str(temp_employer_register.id).encode("ascii"))
        userResponse = {"display_name" : displayName, "email" : email,"enc_id":enc_id}
        internalResponse = {"user":userResponse}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response":internalResponse}
    else:
        print('hello')
        temp_obj = Temp_employer_register(
            email=email, password=_hash.bcrypt.hash(password),mobile_number=mobile_number, first_name=first_name,last_name=last_name,source='WEB',salt='',status_code='',otp=0,created_on = dateTime_at,updated_on=dateTime_at
        )
        db.add(temp_obj)
        db.commit()
        db.refresh(temp_obj)

        background_tasks.add_task(generateOtp, temp_obj.id, db)
        displayName = str(first_name)+' '+str(last_name)

        enc_id = base64.b64encode(str(temp_obj.id).encode("ascii"))
        userResponse = {"display_name" : displayName, "email" : email,"enc_id":enc_id}
        internalResponse = {"user":userResponse}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response":internalResponse}
   
    if not response:
        return ServiceResult(AppException.CreateValidation())
    return ServiceResult(response)

async def generateOtp(id : int,  db):
    otp = random.randint(10000, 99999)
    sleep(3)
    userDetails = db.query(Temp_employer_register).filter((Temp_employer_register.id == id)).first()
    email = userDetails.email
    email = list(email.split(" "))

    userDetails.otp = otp
    db.add(userDetails)
    db.commit()
    db.refresh(userDetails)
    
    employer_otp_log = Employer_otp_log(
        employer_id=id, code=otp
    )
    db.add(employer_otp_log)
    db.commit()
    db.refresh(employer_otp_log)
    
    mailBody = db.query(Mail_bodies).filter((Mail_bodies.type == 'employer_otp')).first()
    subject = mailBody.subject
    body = mailBody.body
    body = body.replace('{OTP}', str(otp))
    attachments = []
    cc = []
    bcc = []
    await send_email(subject, email, body, attachments, cc, bcc)

async def resend_otp(resendotp, db, background_tasks: BackgroundTasks):
    base64_bytes = bytes(resendotp.enc_id, encoding="raw_unicode_escape")
    id = base64.b64decode(base64_bytes).decode("ascii")
    resend_otp = db.query(Temp_employer_register).filter(Temp_employer_register.id == id).first()
    if resend_otp:
        background_tasks.add_task(generateOtp, id, db)
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
        return ServiceResult(response)
    else:
        return ServiceResult(AppException.GetValidation(RECORD_NOT_EXISTS)) 

def create_token(employer_register: Employer_register):
    register_obj = EmployerUsername.from_orm(employer_register)
    token = jwt.encode(register_obj.dict(), JWT_SECRET)
    return dict(access_token=token, token_type="bearer")

class VerifyOtpService(AppService):
    def verifyOtp(self, otpSchema: VerifyOtpWithOtp) -> ServiceResult:
        otp_data = VerifyCRUD(self.db).verify_otp(otpSchema)
        if not otp_data:
            return ServiceResult(AppException.CreateValidation(INVALID_OTP))
        return ServiceResult(otp_data)

class VerifyCRUD(AppCRUD):
    def verify_otp(self, otpSchema: VerifyOtpWithOtp):
        base64_bytes = bytes(otpSchema.enc_id, encoding="raw_unicode_escape")
        id = base64.b64decode(base64_bytes).decode("ascii")
        verify_otp=self.db.query(Temp_employer_register).filter(Temp_employer_register.id == id).filter(Temp_employer_register.otp == otpSchema.otp).first()
        if verify_otp:
            main_obj = self.db.query(Employer_register).filter((Employer_register.email == verify_otp.email) | (Employer_register.mobile_number == verify_otp.mobile_number)).first()
            if main_obj is None:
                    main_obj = Employer_register(
                        first_name=verify_otp.first_name,
                        last_name=verify_otp.last_name,
                        mobile_number=verify_otp.mobile_number,
                        email=verify_otp.email, 
                        password=verify_otp.password,
                        source=verify_otp.source,
                        salt=verify_otp.salt,
                        status_code=verify_otp.status_code,
                        s3_bucket = '',
                        created_on = dateTime_at,
                        updated_on = dateTime_at
                    )
                    self.db.add(main_obj)
                    self.db.commit()
                    self.db.refresh(main_obj)

                    s3_bucket = str(main_obj.first_name)+''+str(main_obj.last_name)+''+str(main_obj.id)
                    employer_register_data = self.db.query(Employer_register).filter((Employer_register.id == main_obj.id)).first()
                    employer_register_data.s3_bucket = s3_bucket
                    self.db.add(employer_register_data)
                    self.db.commit()
                    self.db.refresh(employer_register_data)

            token_response = create_token(main_obj)
            displayName = str(main_obj.first_name)+' '+str(main_obj.last_name)
            userResponse = {"display_name":displayName,"email":main_obj.email,"photo_url":"","country":"","state":"","city":"","zip_code":"","last_login":"","theme":""}
            internalResponse = {"access_token":token_response['access_token'],"user":userResponse}
            response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : internalResponse}
            return response
        return None

class LoginService(AppService):
    def login(self, loginSchema: EmployerLogin) -> ServiceResult:
        login_data = LoginCRUD(self.db).login(loginSchema)
        if not login_data:
            return ServiceResult(AppException.GetValidation(INVALID_USER_PASS))
        return ServiceResult(login_data)

class LoginCRUD(AppCRUD):
    def login(self, loginSchema: EmployerLogin):
        username = loginSchema.username
        password = loginSchema.password

        print(username,password)
        employer_login = self.db.query(Temp_employer_register).filter((Temp_employer_register.email == username) | (Temp_employer_register.mobile_number == username)).first()
        if employer_login:
            if not employer_login.verify_password(password):
                return None
            else:
                token_response = create_token(employer_login)
                displayName = str(employer_login.first_name)+' '+str(employer_login.last_name)
                userResponse = {"display_name": displayName, "email": employer_login.email, "photo_url":"", "country": "", "state": "", "city": "", "zip_code": "", "last_login": "", "theme": ""}
                internalResponse = {"access_token":token_response['access_token'],"user":userResponse}
                response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : internalResponse}
                return response
       

# IF WE DONT USED BACKGROUND TASK WE NEED TO USED THIS PROCESS
# class RegistrationService(AppService):
#     def create_talent(self, talent: TalentRegisterCreate) -> ServiceResult:
#         temp_talent = RegCRUD(self.db).create_talent(talent)
#         if not temp_talent:
#             return ServiceResult(AppException.CreateValidation())
#         return ServiceResult(temp_talent)

# class RegCRUD(AppCRUD):
#     def create_talent(self, talent: TalentRegisterCreate):
        
#         temp_talent = Temp_talent_register(first_name=talent.first_name, last_name=talent.last_name, email=talent.email, mobile_number=talent.mobile_number, password=_hash.bcrypt.hash(talent.password), source='WEB', salt='', status_code='',otp=0, created_on = dateTime_at,  updated_on = dateTime_at)
#         self.db.add(temp_talent)
#         self.db.commit()
#         self.db.refresh(temp_talent)
        
#         displayName = str(temp_talent.first_name)+' '+str(temp_talent.last_name)
#         enc_id = base64.b64encode(str(temp_talent.id).encode("ascii"))
#         userResponse = {"display_name" : displayName, "email" : talent.email,"enc_id":enc_id}
#         internalResponse = {"user":userResponse}
#         response = {"status" : 402, "message" : "success", "response":internalResponse}
#         return response
