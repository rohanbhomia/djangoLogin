from ..schemas.talent_login import *
from ..utils.app_exceptions import AppException
from ..services.main import AppService, AppCRUD
from ..models.talent_login import *
from ..utils.service_result import ServiceResult
from fastapi import BackgroundTasks
from ..lib_packages.send_mail import send_email
from ..config.dependencies import JWT_SECRET,dateTime_at,conf,MessageSchema,FastMail,os
from ..validator_package.validations_errors import *
from time import sleep
import passlib.hash as _hash
import base64
import random
import jwt
import datetime
import fastapi

statusCodeSuccess = int(os.getenv('STATUS_200'))
statusMessageSuccess = os.getenv('MESSAGE_200')
statusCodeFailure = int(os.getenv('STATUS_409'))
statusMessageFailed = os.getenv('MESSAGE_409')


async def create_talent(talent:TalentRegisterCreate,db,background_tasks: BackgroundTasks):
    email = talent.email
    mobile_number = talent.mobile_number
    first_name = talent.first_name
    last_name = talent.last_name
    password = talent.password
    #confirm_password = talent.confirm_password

    # if password!=confirm_password:
    #     return ServiceResult(AppException.CreateValidation(MATCH_PASSWORD_ERROR))

    talent_register = db.query(Talent_register).filter((Talent_register.email == email) | (Talent_register.mobile_number == mobile_number)).first()
    if talent_register:
        return ServiceResult(AppException.CreateValidation(ALREADY_EXISTS))

    temp_talent_register=db.query(Temp_talent_register).filter((Temp_talent_register.email == email) | (Temp_talent_register.mobile_number == mobile_number)).first()
    
    if temp_talent_register:
        temp_talent_register.otp = 0
        temp_talent_register.password = _hash.bcrypt.hash(password)
        temp_talent_register.first_name = first_name
        temp_talent_register.last_name = last_name
        temp_talent_register.created_on = dateTime_at
        temp_talent_register.updated_on = dateTime_at
        db.add(temp_talent_register)
        db.commit()
        db.refresh(temp_talent_register)

        background_tasks.add_task(generateOtp, temp_talent_register.id, db)
        displayName = str(first_name)+' '+str(last_name)

        ##ID ECRYPTION
        enc_id = base64.b64encode(str(temp_talent_register.id).encode("ascii"))
        userResponse = {"display_name" : displayName, "email" : email,"enc_id":enc_id}
        internalResponse = {"user":userResponse}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response":internalResponse}
    else:
        temp_obj = Temp_talent_register(
            email=email, password=_hash.bcrypt.hash(password),mobile_number=mobile_number, first_name=first_name,last_name=last_name,source='WEB',salt='',status_code='',otp=0,created_on = dateTime_at,updated_on=dateTime_at
        )
        db.add(temp_obj)
        db.commit()
        db.refresh(temp_obj)

        background_tasks.add_task(generateOtp, temp_obj.id, db)
        displayName = str(first_name)+' '+str(last_name)

        enc_id = base64.b64encode(str(temp_obj.id).encode("ascii"))
        userResponse = {"display_name" : displayName, "email" : email,"enc_id":enc_id}
        internalResponse = {"user":userResponse}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response":internalResponse}
   
    if not response:
        return ServiceResult(AppException.CreateValidation())
    return ServiceResult(response)

async def generateOtp(id : int,  db):
    otp = random.randint(10000, 99999)
    sleep(3)
    userDetails = db.query(Temp_talent_register).filter((Temp_talent_register.id == id)).first()
    email = userDetails.email
    email = list(email.split(" "))

    userDetails.otp = otp
    db.add(userDetails)
    db.commit()
    db.refresh(userDetails)
    
    talent_otp_log = Talent_otp_log(
        talent_id=id, code=otp
    )
    db.add(talent_otp_log)
    db.commit()
    db.refresh(talent_otp_log)
    
    mailBody = db.query(Mail_bodies).filter((Mail_bodies.type == 'talent_otp')).first()
    subject = mailBody.subject
    body = mailBody.body
    body = body.replace('{OTP}', str(otp))
    attachments = []
    cc = []
    bcc = []
    await send_email(subject, email, body, attachments, cc, bcc)

async def resend_otp(resendotp, db, background_tasks: BackgroundTasks):
    base64_bytes = bytes(resendotp.enc_id, encoding="raw_unicode_escape")
    id = base64.b64decode(base64_bytes).decode("ascii")
    resend_otp = db.query(Temp_talent_register).filter(Temp_talent_register.id == id).first()
    if resend_otp:
        background_tasks.add_task(generateOtp, id, db)
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
        return ServiceResult(response)
    else:
        return ServiceResult(AppException.GetValidation(RECORD_NOT_EXISTS)) 

def create_talent_token(talent_register: Talent_register):
    talent_register_obj = TalentUsername.from_orm(talent_register)
    token = jwt.encode(talent_register_obj.dict(), JWT_SECRET)
    return dict(access_token=token, token_type="bearer")

class VerifyOtpService(AppService):
    def verifyOtp(self, otpSchema: VerifyOtpWithOtp) -> ServiceResult:
        otp_data = VerifyCRUD(self.db).verify_otp(otpSchema)
        if not otp_data:
            return ServiceResult(AppException.CreateValidation(INVALID_OTP))
        return ServiceResult(otp_data)

class VerifyCRUD(AppCRUD):
    def verify_otp(self, otpSchema: VerifyOtpWithOtp):
        base64_bytes = bytes(otpSchema.enc_id, encoding="raw_unicode_escape")
        id = base64.b64decode(base64_bytes).decode("ascii")
        verify_otp=self.db.query(Temp_talent_register).filter(Temp_talent_register.id == id).filter(Temp_talent_register.otp == otpSchema.otp).first()
        if verify_otp:
            main_obj = self.db.query(Talent_register).filter((Talent_register.email == verify_otp.email) | (Talent_register.mobile_number == verify_otp.mobile_number)).first()
            if main_obj is None:
                    main_obj = Talent_register(
                        first_name=verify_otp.first_name,
                        last_name=verify_otp.last_name,
                        mobile_number=verify_otp.mobile_number,
                        email=verify_otp.email, 
                        password=verify_otp.password,
                        source=verify_otp.source,
                        salt=verify_otp.salt,
                        status_code=verify_otp.status_code,
                        s3_bucket = '',
                        created_on = dateTime_at,
                        updated_on = dateTime_at
                    )
                    self.db.add(main_obj)
                    self.db.commit()
                    self.db.refresh(main_obj)

                    s3_bucket = str(main_obj.first_name)+''+str(main_obj.last_name)+''+str(main_obj.id)
                    talent_register_data = self.db.query(Talent_register).filter((Talent_register.id == main_obj.id)).first()
                    talent_register_data.s3_bucket = s3_bucket
                    self.db.add(talent_register_data)
                    self.db.commit()
                    self.db.refresh(talent_register_data)

            token_response = create_talent_token(main_obj)
            displayName = str(main_obj.first_name)+' '+str(main_obj.last_name)
            userResponse = {"display_name":displayName,"email":main_obj.email,"photo_url":"","country":"","state":"","city":"","zip_code":"","last_login":"","theme":""}
            internalResponse = {"access_token":token_response['access_token'],"user":userResponse}
            response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : internalResponse}
            return response
        return None

class LoginService(AppService):
    def login(self, loginSchema: TalentLogin) -> ServiceResult:
        login_data = LoginCRUD(self.db).login(loginSchema)
        if not login_data:
            # return ServiceResult(AppException.CreateValidation())
            return ServiceResult(AppException.GetValidation(INVALID_USER_PASS))
        return ServiceResult(login_data)

class LoginCRUD(AppCRUD):
    def login(self, loginSchema: TalentLogin):
        username = loginSchema.username
        password = loginSchema.password
        talent_login = self.db.query(Talent_register).filter((Talent_register.email == username) | (Talent_register.mobile_number == username)).first()
        if talent_login:
            if not talent_login.verify_password(password):
                return False
                # raise fastapi.HTTPException(
                #     status_code=409, detail="Invalid Email or Password"
                # )
                # print('talent_login=========>>>>>>',talent_login)
                # return ServiceResult(AppException.GetValidation())
            else:
                token_response = create_talent_token(talent_login)
                displayName = str(talent_login.first_name)+' '+str(talent_login.last_name)
                userResponse = {"display_name": displayName, "email": talent_login.email, "photo_url":"", "country": "", "state": "", "city": "", "zip_code": "", "last_login": "", "theme": ""}
                internalResponse = {"access_token":token_response['access_token'],"user":userResponse}
                response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : internalResponse}
                return response
       

# IF WE DONT USED BACKGROUND TASK WE NEED TO USED THIS PROCESS
# class RegistrationService(AppService):
#     def create_talent(self, talent: TalentRegisterCreate) -> ServiceResult:
#         temp_talent = RegCRUD(self.db).create_talent(talent)
#         if not temp_talent:
#             return ServiceResult(AppException.CreateValidation())
#         return ServiceResult(temp_talent)

# class RegCRUD(AppCRUD):
#     def create_talent(self, talent: TalentRegisterCreate):
        
#         temp_talent = Temp_talent_register(first_name=talent.first_name, last_name=talent.last_name, email=talent.email, mobile_number=talent.mobile_number, password=_hash.bcrypt.hash(talent.password), source='WEB', salt='', status_code='',otp=0, created_on = dateTime_at,  updated_on = dateTime_at)
#         self.db.add(temp_talent)
#         self.db.commit()
#         self.db.refresh(temp_talent)
        
#         displayName = str(temp_talent.first_name)+' '+str(temp_talent.last_name)
#         enc_id = base64.b64encode(str(temp_talent.id).encode("ascii"))
#         userResponse = {"display_name" : displayName, "email" : talent.email,"enc_id":enc_id}
#         internalResponse = {"user":userResponse}
#         response = {"status" : 402, "message" : "success", "response":internalResponse}
#         return response
