from ..schemas.talent_settings import *
from ..schemas.employer_login import *
from ..models.employer_job_posting import *
from ..schemas.employer_job_posting import *
from ..utils.app_exceptions import AppException
from ..services.main import AppService, AppCRUD
from ..models.talent_settings import *
from ..utils.service_result import ServiceResult
from ..config.dependencies import JWT_SECRET, dateTime_at, os
from sqlalchemy import or_, and_
from elasticsearch import Elasticsearch

es = Elasticsearch("http://localhost:9200")


statusCodeSuccess = int(os.getenv('STATUS_200'))
statusMessageSuccess = os.getenv('MESSAGE_200')
statusCodeFailure = int(os.getenv('STATUS_409'))
statusMessageFailed = os.getenv('MESSAGE_409')


ELASTIC_INDEX_NAME = os.getenv('ELASTIC_INDEX_NAME')


class EmployerSettings(AppService):

    def create_job(self, item: CreateJob, token) -> ServiceResult:

        talent_result = SettingsCrud(self.db)._create_job(item, token)
        if not talent_result:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(talent_result)

    def create_job_two(self, item: CreateJobTwo, token) -> ServiceResult:

        talent_result = SettingsCrud(self.db)._create_job_two(item, token)
        if not talent_result:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(talent_result)

    def create_job_three(self, item: CreateJobThree, token) -> ServiceResult:

        talent_result = SettingsCrud(self.db)._create_job_three(item, token)
        if not talent_result:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(talent_result)

    def update_job(self, item: CreateJob, token) -> ServiceResult:

        talent_result = SettingsCrud(self.db)._update_job(item, token)
        if not talent_result:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(talent_result)

    def update_job_two(self, item: CreateJobTwo, token) -> ServiceResult:

        talent_result = SettingsCrud(self.db)._update_job_two(item, token)
        if not talent_result:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(talent_result)

    def update_job_three(self, item: CreateJobThree, token) -> ServiceResult:

        talent_result = SettingsCrud(self.db)._update_job_three(item, token)
        if not talent_result:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(talent_result)

    def get_all_jobs(self) -> ServiceResult:

        talent_result = SettingsCrud(self.db)._get_all_jobs()
        if not talent_result:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(talent_result)

    def get_jobs(self, id, token) -> ServiceResult:

        talent_result = SettingsCrud(self.db)._get_jobs(id, token)
        if not talent_result:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(talent_result)

    def search_jobs(self, item: SearchJobs, token) -> ServiceResult:

        talent_result = SettingsCrud(self.db)._search_jobs(item, token)
        if not talent_result:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(talent_result)


class SettingsCrud(AppCRUD):

    def _create_job(self, item: CreateJob, token) -> Employer_job_posting:
        employer_id = token.id
        print("111")
        employer_job_posting = Employer_job_posting(
            category=item.category,
            other_category=item.other_category,
            role_type=item.role_type,
            project_title=item.project_title,
            primary_language=item.primary_language,
            additional_language=item.additional_language,
            project_description=item.project_description,
            character_name=item.character_name,
            age_start=item.age_start,
            age_end=item.age_end,
            playing_role=item.playing_role,
            traits=item.traits,
            role_description=item.role_description,
            skills=item.skills,
            pay_rage=item.pay_rage,
            experience=item.experience,
            location=item.location,
            apply_date=item.apply_date,
            created_on=dateTime_at,
            updated_on=dateTime_at,
            employer_id=employer_id,)
        self.db.add(employer_job_posting)
        self.db.commit()
        self.db.refresh(employer_job_posting)
        response = {"status": statusCodeSuccess,
                    "message": 'Created successfully'}

        elastic_dict = dict(item)
        elastic_dict['employer_id'] = employer_id
        del elastic_dict['id']
        self.elastic_insert(employer_job_posting.id, elastic_dict)

        return response

    def _create_job_two(self, item: CreateJobTwo, token) -> Employer_job_posting:
        employer_id = token.id
        print("222", item)
        employer_job_posting = Employer_job_posting(
            category=item.category,
            profession=item.profession,
            project_title=item.project_title,
            project_description=item.project_description,
            directed_by=item.directed_by,
            duration_start=item.duration_start,
            duration_end=item.duration_end,
            shooting_days=item.shooting_days,
            pay_rage=item.pay_rage,
            experience=item.experience,
            location=item.location,
            apply_date=item.apply_date,
            created_on=dateTime_at,
            updated_on=dateTime_at,
            employer_id=employer_id)
        self.db.add(employer_job_posting)
        self.db.commit()
        self.db.refresh(employer_job_posting)
        response = {"status": statusCodeSuccess,
                    "message": 'Created successfully'}

        elastic_dict = dict(item)
        elastic_dict['employer_id'] = employer_id
        del elastic_dict['id']
        self.elastic_insert(employer_job_posting.id, elastic_dict)
        return response

    def _create_job_three(self, item: CreateJobThree, token) -> Employer_job_posting:
        employer_id = token.id
        print("222", item)
        employer_job_posting = Employer_job_posting(
            category=item.category,
            role_type=item.role_type,
            job_description=item.job_description,
            skills=item.skills,
            pay_rage=item.pay_rage,
            experience=item.experience,
            employment_type=item.employment_type,
            position_type=item.position_type,
            location=item.location,
            apply_date=item.apply_date,
            created_on=dateTime_at,
            updated_on=dateTime_at,
            employer_id=employer_id)
        self.db.add(employer_job_posting)
        self.db.commit()
        self.db.refresh(employer_job_posting)
        response = {"status": statusCodeSuccess,
                    "message": 'Created successfully'}

        elastic_dict = dict(item)
        elastic_dict['employer_id'] = employer_id
        del elastic_dict['id']
        self.elastic_insert(employer_job_posting.id, elastic_dict)
        return response

    def _update_job(self, item: CreateJob, token) -> Employer_job_posting:

        employer_id = token.id
        result = self.db.query(Employer_job_posting).filter(and_(
            Employer_job_posting.employer_id == employer_id, Employer_job_posting.id == item.id)).first()

        if result:
            result.category = item.category
            result.other_category = item.other_category
            result.role_type = item.role_type
            result.project_title = item.project_title
            result.primary_language = item.primary_language
            result.additional_language = item.additional_language
            result.project_description = item.project_description
            result.character_name = item.character_name
            result.age_start = item.age_start
            result.age_end = item.age_end
            result.playing_role = item.playing_role
            result.traits = item.traits
            result.role_description = item.role_description
            result.skills = item.skills
            result.pay_rage = item.pay_rage
            result.experience = item.experience
            result.location = item.location
            result.apply_date = item.apply_date
            result.created_on = dateTime_at
            result.updated_on = dateTime_at
            self.db.add(result)
            self.db.commit()
            self.db.refresh(result)

            response = {"status": statusCodeSuccess,
                        "message": 'Updated successfully'}

            elastic_dict = dict(item)
            elastic_dict['employer_id'] = employer_id
            del elastic_dict['id']
            self.elastic_insert(result.id, elastic_dict)
            return response
        else:
            return False

    def _update_job_two(self, item: CreateJobTwo, token) -> Employer_job_posting:

        employer_id = token.id
        result = self.db.query(Employer_job_posting).filter(and_(
            Employer_job_posting.employer_id == employer_id, Employer_job_posting.id == item.id)).first()

        if result:
            result.category = item.category
            result.profession = item.profession
            result.project_title = item.project_title
            result.project_description = item.project_description
            result.directed_by = item.directed_by
            result.duration_start = item.duration_start
            result.duration_end = item.duration_end
            result.shooting_days = item.shooting_days
            result.pay_rage = item.pay_rage
            result.experience = item.experience
            result.location = item.location
            result.apply_date = item.apply_date
            result.created_on = dateTime_at
            result.updated_on = dateTime_at
            self.db.add(result)
            self.db.commit()
            self.db.refresh(result)

            response = {"status": statusCodeSuccess,
                        "message": 'Updated successfully'}

            elastic_dict = dict(item)
            elastic_dict['employer_id'] = employer_id
            del elastic_dict['id']
            self.elastic_insert(result.id, elastic_dict)
            return response
        else:
            return False

    def _update_job_three(self, item: CreateJobThree, token) -> Employer_job_posting:

        employer_id = token.id
        result = self.db.query(Employer_job_posting).filter(and_(
            Employer_job_posting.employer_id == employer_id, Employer_job_posting.id == item.id)).first()

        if result:
            result.category = item.category
            result.role_type = item.role_type
            result.job_description = item.job_description
            result.skills = item.skills
            result.pay_rage = item.pay_rage
            result.experience = item.experience
            result.employment_type = item.employment_type
            result.position_type = item.position_type
            result.location = item.location
            result.apply_date = item.apply_date
            result.created_on = dateTime_at
            result.updated_on = dateTime_at
            self.db.add(result)
            self.db.commit()
            self.db.refresh(result)

            response = {"status": statusCodeSuccess,
                        "message": 'Updated successfully'}

            elastic_dict = dict(item)
            elastic_dict['employer_id'] = employer_id
            del elastic_dict['id']
            self.elastic_insert(result.id, elastic_dict)
            return response
        else:
            return False

    def _get_all_jobs(self) -> Employer_job_posting:

        result = self.db.query(Employer_job_posting).filter().all()

        if len(result) is not 0:
            response = {"status": statusCodeSuccess,
                        "message": statusMessageSuccess, "response": result}
            return response

    def _get_jobs(self, id, token) -> Employer_job_posting:
        employer_id = token.id
        print("id-----", id)
        if id is None:
            result = self.db.query(Employer_job_posting).filter(
                Employer_job_posting.employer_id == employer_id).all()

            response = {"status": statusCodeSuccess,
                        "message": statusMessageSuccess, "response": result}
            return response
        else:
            result = self.db.query(Employer_job_posting).filter(and_(
                Employer_job_posting.employer_id == employer_id, Employer_job_posting.id == id)).all()

            response = {"status": statusCodeSuccess,
                        "message": statusMessageSuccess, "response": result}
            return response

    def _search_jobs(self, item: SearchJobs, token) -> Employer_job_posting:
        employer_id = token.id
        must_list = []

        must_list.append({"match": {"employer_id": employer_id}})
        if item.category is not None:
            must_list.append({"match": {"category": item.category}})
        if item.role_type is not None:
            must_list.append({"match": {"role_type": item.role_type}})

        resp = es.search(index="employer_job_posting",
                         query={"bool": {"must": must_list}})

        result = []
        for data in resp['hits']['hits']:
            result.append(data['_source'])

        response = {"status": statusCodeSuccess,
                    "message": statusMessageSuccess, 'response': result}
        return response

    def elastic_insert(self, job_id, item):
        resp = es.index(index=ELASTIC_INDEX_NAME, id=job_id, document=item)
        print("resp-------", resp)
