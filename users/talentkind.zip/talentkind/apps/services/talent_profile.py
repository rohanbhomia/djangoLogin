from ..schemas.talent_profile import *
from ..schemas.talent_login import TalentUsername
from ..utils.app_exceptions import AppException
from ..services.main import AppService, AppCRUD
from ..models.talent_login import Talent_register
from ..models.talent_portfolio import Talent_portfolio
from ..models.talent_profile import *
from ..utils.service_result import ServiceResult
from fastapi import Depends,BackgroundTasks, Request
from ..config.dependencies import oauth2schema, JWT_SECRET, dateTime_at, mongodb, os, FOLDER_NAME
from ..config.database import get_db, mysqlConnection, mydb
from mimetypes import guess_extension, guess_type
from bson import json_util

import fastapi 
import jwt
import json
import datetime
import os
import base64
import random

from urllib.parse import urlparse   ### NEW ADDED BY KAMLESH
from sqlalchemy.sql import func   ### NEW ADDED BY KAMLESH

from ..media_packages import media_upload

########  MONGODB CONN
mongodbConn = mongodb()

statusCodeSuccess = int(os.getenv('STATUS_200'))
statusMessageSuccess = os.getenv('MESSAGE_200')
statusCodeFailure = int(os.getenv('STATUS_409'))
statusMessageFailed = os.getenv('MESSAGE_409')

#FOR QR CODE
import pyqrcode
import png
from pyqrcode import QRCode

async def get_talent_current_user(
    db: get_db = Depends(),
    token: str = fastapi.Depends(oauth2schema),
):
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        talent = db.query(Talent_register).get(payload["id"])
    except:
        raise fastapi.HTTPException(
            status_code=409, detail="Invalid Email or Password"
        )
    if talent:
        return TalentUsername.from_orm(talent)
    else:
        raise fastapi.HTTPException(
            status_code=409, detail="Invalid Email or Password"
        )

class PersonalInfoService(AppService):
    def PersonalInfo(self, token) -> ServiceResult:
        personal_info = PersonalInfoCRUD(self.db).personal_info(token)
        if not personal_info:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(personal_info)

class PersonalInfoCRUD(AppCRUD):
    def personal_info(self, token):
        talent_id = token.id
        talent_personal_info = self.db.query(Talent_personal_info).filter((Talent_personal_info.talent_id == talent_id)).first()
        user = {}
        if talent_personal_info:
            user["display_name"] = talent_personal_info.display_name
            user["gender"] = talent_personal_info.gender
            user["date_of_birth"] = talent_personal_info.date_of_birth
            user["nationality"] = talent_personal_info.nationality
            user["state"] = talent_personal_info.state
            user["city"] = talent_personal_info.city
            user["pincode"] = talent_personal_info.pincode
            user["have_passport"] = talent_personal_info.have_passport
            user["have_travelled_abroad"] = talent_personal_info.have_travelled_abroad
            user["avatar_url"] = talent_personal_info.avatar_url
        else:
            talent_register = self.db.query(Talent_register).filter((Talent_register.id == talent_id)).first()
            if talent_register:
                user["display_name"] = str(talent_register.first_name)+' '+str(talent_register.last_name)
                user["gender"] = ''
                user["date_of_birth"] = ''
                user["nationality"] = ''
                user["state"] = ''
                user["city"] = ''
                user["pincode"] = ''
                user["have_passport"] = 0
                user["have_travelled_abroad"] = 0
                user["avatar_url"] = ''
            else:
                return ServiceResult(AppException.CreateValidation())
        
        col = mongodbConn['Countries']
        countriesList = []
        coutries = list(col.find({},{"id" : 1,"name":1, "_id":0}).sort("name"))
        countriesList = json.loads(json_util.dumps(coutries))
     
        user_industries = []
        talentIndustry = self.db.query(Talent_industry).filter(Talent_industry.talent_id == talent_id).all()
        
        if talentIndustry:
            for industryRow in talentIndustry:
                industry = {"code": industryRow.industry_code, "is_primary": industryRow.is_primary}
                user_industries.append(industry)

        prof_comp_per = ProgressBar(self.db, talent_id, None).totalPercentage()

        country_name = "India"
        col = mongodbConn['Countries']
        statesList = []
        states = col.find({"name" : str(country_name)},["states.id","states.name"]).sort("name")
        for stateRow in states:
            statesList = json.loads(json_util.dumps(stateRow['states']))

        userResponse = {"user" : user, "user_industries": user_industries, "country" : countriesList, "states" : statesList, "profile_percen":prof_comp_per}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : userResponse}
        return response

class GetStateService(AppService):
    def GetState(stateFields: getStatesFileds) -> ServiceResult:
        state_data = StateCRUD.get_states(stateFields)
        if not state_data:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(state_data)

class StateCRUD(AppCRUD):
    def get_states(stateFields:getStatesFileds):
        country_name = stateFields.country_name
        col = mongodbConn['Countries']
        statesList = []
        states = col.find({"name" : str(country_name)},["states.id","states.name"]).sort("name")
        for stateRow in states:
            statesList = json.loads(json_util.dumps(stateRow['states']))
        userResponse = {"states" : statesList}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : userResponse}
        return response

class GetCityService(AppService):
    def GetCity(cityFields:getCitiesFileds) -> ServiceResult:
        city_data = CityCRUD.get_cities(cityFields)
        if not city_data:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(city_data)

class CityCRUD(AppCRUD):
    def get_cities(cityFields:getCitiesFileds):
        country_name = cityFields.country_name
        state_name = cityFields.state_name
        
        cities = list(mongodbConn.Countries.aggregate([
            { "$match" : { "name" : str(country_name),"states.name" : str(state_name) }},    ##just precondition can be skipped
            { "$unwind": "$states" },
            { "$unwind": "$states.cities" },
            { "$match" : { "name" : str(country_name), "states.name" : str(state_name) }},
            { "$group" : { "_id" : {"id" : "$_id"}, "cities" : {"$push" : "$states.cities"}}},
            { "$project": { "cities.name": 1 , "cities.id": 1, "_id" : 0}}  
        ]))

        cityList = []
        for cityRow in cities:      
            cityList = json.loads(json_util.dumps(cityRow))
        
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : cityList}
        return response

async def update_personal_info(TalentPersonalInfo:TalentPersonalInfo,background_tasks: BackgroundTasks, Request,token,db):
    talent_id = token.id
    talent_personal_info = db.query(Talent_personal_info).filter((Talent_personal_info.talent_id == talent_id)).first()

    avatar_url = ''
    if talent_personal_info:
        avatar_url = talent_personal_info.avatar_url
    if TalentPersonalInfo.avatar_url is not None:
        ####=========   UPLOAD S3 server
        encodeStr = TalentPersonalInfo.avatar_url

        talent_register = db.query(Talent_register).filter((Talent_register.id == talent_id)).first()
        user_bucket = talent_register.s3_bucket
        
        return_avatar_url = media_upload.upload_avatar(talent_id, encodeStr, user_bucket)
        if return_avatar_url:
            avatar_url = return_avatar_url
        else:
            return ServiceResult(AppException.CreateValidation('Invalid file format'))
    # if TalentPersonalInfo.avatar_url is not None:
    #     ####=========   UPLOAD S3 server
    #     encodeStr = TalentPersonalInfo.avatar_url
    #     extension = guess_extension(guess_type(encodeStr)[0])
    #     if extension =='.png' or extension =='.PNG' or extension =='.jpg' or extension =='.JPG' or extension =='.jpeg' or extension =='.JPEG':
    #         #### UPLOAD IMAGE IN BACKGROUND
    #         background_tasks.add_task(uploadInfoImage, talent_id, encodeStr, db)
    #         ####===============UPLOAD s3 server
    #         avatar_url = ''
    #         if talent_personal_info:
    #             avatar_url = talent_personal_info.avatar_url
    #     else:
    #         return ServiceResult(AppException.CreateValidation()) 
    # else:
    #     avatar_url = talent_personal_info.avatar_url

    if talent_personal_info:
        talent_personal_info.display_name = TalentPersonalInfo.display_name
        talent_personal_info.gender = TalentPersonalInfo.gender
        talent_personal_info.date_of_birth = TalentPersonalInfo.date_of_birth
        talent_personal_info.nationality = TalentPersonalInfo.nationality
        talent_personal_info.state = TalentPersonalInfo.state
        talent_personal_info.city = TalentPersonalInfo.city
        talent_personal_info.pincode = TalentPersonalInfo.pincode
        talent_personal_info.have_passport = TalentPersonalInfo.have_passport
        talent_personal_info.have_travelled_abroad = TalentPersonalInfo.have_travelled_abroad
        talent_personal_info.avatar_url =  avatar_url
        talent_personal_info.updated_on = dateTime_at
    else:
        #date_of_slug = datetime.datetime.strptime(TalentPersonalInfo.date_of_birth, "%Y-%m-%d").strftime('%d%m')
        #slug=''.join(e for e in TalentPersonalInfo.display_name if e.isalnum())+''+str(date_of_slug)+''+str(talent_id)
        
        talent_personal_info = Talent_personal_info(
            talent_id=talent_id,
            display_name=TalentPersonalInfo.display_name,
            #slug=slug,
            gender=TalentPersonalInfo.gender,
            date_of_birth=TalentPersonalInfo.date_of_birth,
            nationality=TalentPersonalInfo.nationality,
            state= TalentPersonalInfo.state,
            city=TalentPersonalInfo.city,
            pincode= TalentPersonalInfo.pincode,
            have_passport=TalentPersonalInfo.have_passport,
            have_travelled_abroad = TalentPersonalInfo.have_travelled_abroad,
            avatar_url =  avatar_url,
            created_on = dateTime_at
        )
    db.add(talent_personal_info)
    db.commit()
    db.refresh(talent_personal_info)
    await create_slug(db,TalentPersonalInfo.display_name,talent_id,'add')
    
    ProgressBar(db, talent_id, Request).saveLogPercentage()

    response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
    if not response:
        return ServiceResult(AppException.CreateValidation())
    return ServiceResult(response)

async def create_slug(db,display_name,talent_id,flag):
    #date_of_slug = datetime.datetime.strptime(TalentPersonalInfo.date_of_birth, "%Y-%m-%d").strftime('%d%m')
    #slug=''.join(e for e in TalentPersonalInfo.display_name if e.isalnum())+''+str(date_of_slug)+''+str(talent_id)
    slug=''.join(e for e in display_name if e.isalnum())
    check_slug = db.query(Talent_personal_info).filter(Talent_personal_info.slug == slug).filter(Talent_personal_info.talent_id != talent_id).first()
    if check_slug:
        if flag=='add':
            slug=slug+str(talent_id)
        else:
            message="Username already exists"
            return ServiceResult(AppException.CreateValidation(message))

    talent_personal_info = db.query(Talent_personal_info).filter(Talent_personal_info.talent_id == talent_id).first()
    if talent_personal_info:
        talent_personal_info.slug = slug
        db.add(talent_personal_info)
        db.commit()
        db.refresh(talent_personal_info)
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
        return ServiceResult(response)
    else:
        message="Record not exists"
        return ServiceResult(AppException.GetValidation(message))
        
# async def uploadInfoImage(id : int,encodeStr: str, db):
#     extension = guess_extension(guess_type(encodeStr)[0])
#     splitStr = encodeStr.split('base64,')

#     image_data = bytes(splitStr[1], encoding="raw_unicode_escape")
#     image_data = base64.decodebytes(image_data)

#     talent_personal_info = db.query(Talent_register).filter((Talent_register.id == id)).first()
#     user_bucket = talent_personal_info.s3_bucket

#     imageName = str(id)+'_'+str(random.randint(1000, 9999))+"_avatar.jpg"
#     fileName = str(FOLDER_NAME)+imageName
#     with open(fileName, "wb") as fh:
#         fh.write(image_data)
    
#     avatar_url = upload_on_server(resize_profile_image(imageName),user_bucket)
  
#     avatar = db.query(Talent_personal_info).filter(Talent_personal_info.talent_id == id).first()
#     avatar.avatar_url = avatar_url
#     db.add(avatar)
#     db.commit()
#     db.refresh(avatar)

class IndustriesService(AppService):
    def GetIndustries(self, token) -> ServiceResult:
        industries_data = IndustriesCRUD(self.db).get_industries(token)
        if not industries_data:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(industries_data)

    def GetPrimaryIndustry(self, token) -> ServiceResult:
        primary_industry_data = IndustriesCRUD(self.db).get_primary_industry(token)
        if not primary_industry_data:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(primary_industry_data)

   
    def SavePrimaryIndustry(self, PrimarySchema: TalentIndustriesPrimary, token) -> ServiceResult:
        primary_industry_data = IndustriesCRUD(self.db).save_primary_industry(PrimarySchema,token)
        if not primary_industry_data:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(primary_industry_data)

    def SaveTalentIndustries(self, talentIndustries:TalentIndustries, token) -> ServiceResult:
        talent_industries = IndustriesCRUD(self.db).save_talent_industries(talentIndustries,token)
        if not talent_industries:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(talent_industries)

class IndustriesCRUD(AppCRUD):
    def get_industries(self, token):
        talent_id = token.id
        user_industries = []
        talentIndustry = self.db.query(Talent_industry).filter(Talent_industry.talent_id == talent_id).filter(Talent_industry.is_primary == 0).all()
        if talentIndustry is not None:
            for industryRow in talentIndustry:
                industry = {"code": industryRow.industry_code, "is_primary": industryRow.is_primary, "display_name": industryRow.display_name}
                user_industries.append(industry)
        
        user_industries_primary = []
        talentIndustry = self.db.query(Talent_industry).filter(Talent_industry.talent_id == talent_id).filter(Talent_industry.is_primary == 1).all()
        if talentIndustry:
            industries = list(mongodbConn.industries.aggregate([
                { "$match" : { "code": {"$ne" : talentIndustry[0].industry_code}}},
                { "$sort" : { "display_order": 1}},
                { "$project": { "code": 1 , "display_name": 1, "_id":0}}
            ]))

            for industryRow in talentIndustry:
                industry = {"code": industryRow.industry_code, "is_primary": industryRow.is_primary, "display_name": industryRow.display_name}
                user_industries_primary.append(industry)
        else:
            industries = list(mongodbConn.industries.aggregate([
                { "$sort" : { "display_order": 1}},
                { "$project": { "code": 1 , "display_name": 1, "_id":0}}
            ]))

        prof_comp_per = ProgressBar(self.db, talent_id, None).totalPercentage()
        user_response = {"user_industries": user_industries,"user_industries_primary":user_industries_primary,"industries": industries,"profile_percen":prof_comp_per}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : user_response}
        return response

    def get_primary_industry(self, token):
        talent_id = token.id
        industries = list(mongodbConn.industries.aggregate([
            { "$sort" : { "display_order": 1}},
            { "$project": { "code": 1 , "display_name": 1, "_id":0}}
        ]))
        
        talentIndustry = self.db.query(Talent_industry).filter((Talent_industry.talent_id == talent_id)).filter((Talent_industry.is_primary == 1)).first()

        user_industries_primary = {}
        if talentIndustry is not None:
            user_industries_primary = {"code": talentIndustry.industry_code, "is_primary": talentIndustry.is_primary, "display_name": talentIndustry.display_name}

        prof_comp_per = ProgressBar(self.db, talent_id, None).totalPercentage()
        user_response = {"user_industries_primary":user_industries_primary,"industries": industries, "profile_percen":prof_comp_per}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : user_response}
        return response

    def save_primary_industry(self, PrimarySchema: TalentIndustriesPrimary, token):
        talent_id = token.id
        primCode = PrimarySchema.code
        talent_industry_obj = self.db.query(Talent_industry).filter((Talent_industry.talent_id == talent_id)).filter((Talent_industry.is_primary == 1)).first()
        if talent_industry_obj is None:
            talent_industry_obj = Talent_industry(
                talent_id=talent_id,
                industry_code=primCode,
                display_name=PrimarySchema.display_name, 
                is_primary=PrimarySchema.is_primary,
                created_on = dateTime_at,
                updated_on = dateTime_at
            )
        else:
            ##====DELETE OLD PRIMARY FROM TALENT_INDUSTRY_PROFESSION
            self.db.query(Talent_industry_profession).filter(Talent_industry_profession.industry_code == talent_industry_obj.industry_code).delete()
            self.db.commit()
            
            talent_industry_obj.industry_code = primCode,
            talent_industry_obj.is_primary = PrimarySchema.is_primary,
            talent_industry_obj.display_name = PrimarySchema.display_name,
            updated_on = dateTime_at
        self.db.add(talent_industry_obj)
        self.db.commit()
        self.db.refresh(talent_industry_obj)

        ##====DELETE NEW PRIMARY FROM TALENT_INDUSTRY IF EXIST IN SECONDARY
        self.db.query(Talent_industry).filter(Talent_industry.industry_code == primCode).filter(Talent_industry.is_primary == 0).delete()
        self.db.commit

        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
        return response

    def save_talent_industries(self, talentIndustries:TalentIndustries, token):
        talent_id = token.id
        
        industry_code = []
        for industriesRow in talentIndustries.talent_industries_array:
            industry_code.append(industriesRow['code'])
        tupleCode = tuple(industry_code)
        if len(tupleCode)==1:
            tupleCode = '("%s")'%tupleCode[0]
        else:
            tupleCode = tupleCode

        mysqlConnection.execute(f"DELETE talent_industry, talent_industry_profession FROM talent_industry LEFT JOIN talent_industry_profession ON talent_industry.id= talent_industry_profession.talent_industry_id where talent_industry.talent_id= '{talent_id}' and talent_industry.industry_code not in "+str(tupleCode)+"")
        mydb.commit()

        for industriesRow in talentIndustries.talent_industries_array:
            talent_industry_obj = self.db.query(Talent_industry).filter((Talent_industry.talent_id == talent_id)).filter((Talent_industry.industry_code == industriesRow['code'])).first()
            if talent_industry_obj is None:
                talent_industry_obj =Talent_industry(
                    talent_id=talent_id,industry_code=industriesRow['code'],
                    display_name=industriesRow['display_name'], 
                    is_primary=industriesRow['is_primary'],
                    created_on = dateTime_at,
                    updated_on = dateTime_at
                )
                self.db.add(talent_industry_obj)
                self.db.commit()
                self.db.refresh(talent_industry_obj)

        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
        return response
        
class TalentTypeService(AppService):

    def GetTalentType(self, token) -> ServiceResult:
        talent_type_data = TalentTypeCRUD(self.db).get_talent_type(token)
        if not talent_type_data:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(talent_type_data)

    def SaveTalentProfession(self, talentIndustriesProfession:TalentIndustryProfession, Request, token) -> ServiceResult:
        talent_profession_data = TalentTypeCRUD(self.db).save_talent_industry_profession(talentIndustriesProfession, Request,token)
        if not talent_profession_data:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(talent_profession_data)

    def GetOnscreenTalentType(self, onScreenTalentTypeProfession:OnScreenTalentTypeProfession, token) -> ServiceResult:
        onscreen_talent_data = TalentTypeCRUD(self.db).get_onscreen_talent_type(onScreenTalentTypeProfession,token)
        if not onscreen_talent_data:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(onscreen_talent_data)

    def SaveOnscreenTalentType(self, onScreenTalentType:OnScreenTalentType, token) -> ServiceResult:
        onscreen_talent_data = TalentTypeCRUD(self.db).save_onscreen_talent_type(onScreenTalentType,token)
        if not onscreen_talent_data:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(onscreen_talent_data)

def get_selected_onscreen_talent(talent_id: int):
    selected_onscreen_talent =[]
    mysqlConnection.execute(f"SELECT profession_code FROM talent_onscreen_talent where talent_id='{talent_id}' group by profession_code")
    talent_onscreen_talent = mysqlConnection.fetchall()
    mydb.commit()
    for catRow in talent_onscreen_talent:
        selected_onscreen_talent.append(catRow[0])
    return selected_onscreen_talent

class TalentTypeCRUD(AppCRUD):

    def get_talent_type(self, token):
        talent_id = token.id 
        mysqlConnection.execute(f"SELECT GROUP_CONCAT(industry_code) FROM talent_industry where talent_id = '{talent_id}'")
        mydb.commit()
        get_talent_industries = mysqlConnection.fetchone()[0]
        if get_talent_industries is not None:
            talent_industries=get_talent_industries.split( ',')
            talent_industries_list = list(mongodbConn.industries.aggregate([
              { "$match" : { "code" : {"$in": talent_industries }}}, 
              { "$project": { "code": 1, "display_name":1,"type":1, "_id" : 0}} 
            ]))

            industry_types = []
            if talent_industries_list:
                for IndustryTypeRow in talent_industries_list:
                    for i in IndustryTypeRow['type']:
                        if i not in industry_types:
                            industry_types.append(i)

            #OFFSCREEN TALENT 
            offscreen_talent_list=[]  
            if 'offscreen' in set(industry_types):
                offscreen_talent_list = list(mongodbConn.industries.aggregate([
                { "$match" : { "code" : {"$in": talent_industries }}}, 
                { "$match" : { "type" : {"$in": ['offscreen'] }}}, 
                { "$project": { "code": 1, "display_name":1, "categories": 1, "type":1, "_id" : 0}} 
                ]))

            #ONSCREEN TALENT    
            onscreen_profession_list=[]
            onscreen_talent_list=[]
            if 'onscreen' in set(industry_types):
                onscreen_profession_list = list(mongodbConn.onscreen_industries.aggregate([
                { "$project": { "code": 1, "display_name":1,  "_id" : 0}} 
                ]))

                onscreen_talent_list = list(mongodbConn.industries.aggregate([
                { "$match" : { "type" : {"$in": ['onscreen'] }}}, 
                { "$project": { "code": 1, "display_name":1, "_id" : 0}} 
                ]))

           #SELECTED talent_industry_profession

        ####    LOGIC FOR GET ONSCREEN TALENT TYPE SELECTED 
        selected_onscreen_talent = get_selected_onscreen_talent(talent_id)

        ####    LOGIC FOR GET ONSCREEN TALENT TYPE SELECTED 

        selected_talent =[]
        talent_industry_profession = self.db.query(Talent_industry_profession).filter(Talent_industry_profession.talent_id == talent_id).filter(Talent_industry_profession.is_other == 0).all()
        for ProfessionRow in talent_industry_profession:
            profession_data={"code":ProfessionRow.profession_code,"name":ProfessionRow.profession_name}
            selected_talent.append(profession_data)

        off_screen_val_other = {}
        checkExist = self.db.query(Talent_industry_profession).filter(Talent_industry_profession.talent_id == talent_id).filter(Talent_industry_profession.is_other == 1).first()
        if checkExist:
            on_save_add_more_val = {"profession_data":{"code":checkExist.industry_code,"display_name":checkExist.industry_name},"entered_profession_data":checkExist.profession_name,"entered_profession_code":checkExist.profession_code}
            positionArray = self.db.query(Talent_industry_profession_other).filter(Talent_industry_profession_other.talent_id == talent_id).filter(Talent_industry_profession_other.talent_industry_professionId == checkExist.id).all()
            position = []
            for positionRow in positionArray:
                position_data={"type":positionRow.position_type,"selectedId":"True"}
                position.append(position_data)

            experience_level_other = {"experience_level":{"type":checkExist.experience_level_type},"position":position}
            off_screen_val_other = {"on_save_add_more_val":on_save_add_more_val, "experience_level_other":experience_level_other}

        prof_comp_per = ProgressBar(self.db, talent_id, None).totalPercentage()
        talentResponse={"industry_types":industry_types,"onscreen_profession_list":onscreen_profession_list,"onscreen_talent_list":onscreen_talent_list,"offscreen_talent_list":offscreen_talent_list,"selected_talent":selected_talent,"selected_onscreen_talent":selected_onscreen_talent,"off_screen_val_other":off_screen_val_other,"profile_percen":prof_comp_per}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response":talentResponse}
        return response
   

    def save_talent_industry_profession(self, talentIndustriesProfession:TalentIndustryProfession, Request, token):
        talent_id = token.id
        self.db.query(Talent_industry_profession).filter(Talent_industry_profession.talent_id == talent_id).filter(Talent_industry_profession.is_other == 0).delete()
        self.db.commit()
        for professionRow in talentIndustriesProfession.talent_profession_array:
            talent_industry_profession_obj =  Talent_industry_profession(talent_id=talent_id,talent_industry_id=0,profession_code=professionRow['code'],profession_name=professionRow['name'],created_on = dateTime_at)
            self.db.add(talent_industry_profession_obj)
            self.db.commit()
            self.db.refresh(talent_industry_profession_obj)
        if talentIndustriesProfession.off_screen_val_other:
            if talentIndustriesProfession.off_screen_val_other['experience_level_other']:
            	if talentIndustriesProfession.off_screen_val_other['experience_level_other']['experience_level']:
    	            other_industry_code = talentIndustriesProfession.off_screen_val_other['on_save_add_more_val']['profession_data']['code']
    	            other_industry_name = talentIndustriesProfession.off_screen_val_other['on_save_add_more_val']['profession_data']['display_name']
    	            get_talent_industry = self.db.query(Talent_industry).filter(Talent_industry.talent_id == talent_id).filter(Talent_industry.industry_code == other_industry_code).first()
    	            other_profession_name = talentIndustriesProfession.off_screen_val_other['on_save_add_more_val']['entered_profession_data']
    	            experience_level_type = talentIndustriesProfession.off_screen_val_other['experience_level_other']['experience_level']['type']
    	            if other_profession_name != '' and len(other_profession_name) >= 2:
    	                other_profession_code = other_profession_name[:2]
    	                checkExist = self.db.query(Talent_industry_profession).filter(Talent_industry_profession.talent_id == talent_id).filter(Talent_industry_profession.is_other == 1).first()
    	                ##  .filter(Talent_industry_profession.profession_code == other_profession_code).filter(Talent_industry_profession.industry_code == other_industry_code)
    	                if checkExist:
    	                    checkExist.talent_industry_id = get_talent_industry.id,
    	                    checkExist.industry_name = other_industry_name,
    	                    checkExist.industry_code = other_industry_code,
    	                    checkExist.profession_code = other_profession_code,
    	                    checkExist.profession_name = other_profession_name,
    	                    checkExist.experience_level_type = experience_level_type,
    	                    checkExist.updated_on = dateTime_at
    	                else:
    	                    checkExist = Talent_industry_profession(
    	                        talent_id=talent_id,
    	                        talent_industry_id=get_talent_industry.id,
    	                        industry_name=other_industry_name,
    	                        industry_code=other_industry_code,
    	                        profession_code=other_profession_code,
    	                        profession_name=other_profession_name, 
    	                        experience_level_type=experience_level_type,
    	                        is_other=1,
    	                        created_on = dateTime_at
    	                    )
    	                self.db.add(checkExist)
    	                self.db.commit()
    	                self.db.refresh(checkExist)

    	                talent_industry_profession_other_id = str(checkExist.id)
    	                self.db.query(Talent_industry_profession_other).filter(Talent_industry_profession_other.talent_id == talent_id).filter(Talent_industry_profession_other.talent_industry_professionId == talent_industry_profession_other_id).delete()
    	                self.db.commit()
    	                for positionRow in talentIndustriesProfession.off_screen_val_other['experience_level_other']['position']:
    	                    addPositionRow = Talent_industry_profession_other(
    	                        talent_id=talent_id,
    	                        talent_industry_professionId = talent_industry_profession_other_id,
    	                        position_type=positionRow['type'],
    	                        created_on = dateTime_at
    	                    )
    	                    self.db.add(addPositionRow)
    	                    self.db.commit()
    	                    self.db.refresh(addPositionRow)
    	            else:
    	                context = "Invalid Other profession name"
    	                return ServiceResult(AppException.GetValidation(context))
        ProgressBar(self.db, talent_id, Request).saveLogPercentage()
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
        return response

    def get_onscreen_talent_type(self, onScreenTalentTypeProfession:OnScreenTalentTypeProfession, token):
        talent_id = token.id 
        onscreen_talent_list=[]
        onscreen_talent_list = list(mongodbConn.industries.aggregate([
            { "$match" : { "type" : {"$in": ['onscreen'] }}}, 
            { "$project": { "code": 1, "display_name":1, "_id" : 0}} 
        ]))

        onscreenTalent = self.db.query(Talent_onscreen_talent).filter(Talent_onscreen_talent.talent_id == talent_id).filter(Talent_onscreen_talent.profession_code == onScreenTalentTypeProfession.profession_code).first()
        selected_profession=[]
        
        onscreenTalentCat = self.db.query(Talent_onscreen_talent).filter(Talent_onscreen_talent.talent_id == talent_id).filter(Talent_onscreen_talent.profession_code == onScreenTalentTypeProfession.profession_code).all()
        for catRow in onscreenTalentCat:
            profession_data={"code":catRow.profession_category_code,"display_name":catRow.profession_category_name,"selectedId":True}
            selected_profession.append(profession_data)

        talentResponse={"onscreen_talent_list":onscreen_talent_list,"selected_profession":selected_profession}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess ,"response":talentResponse}
        return response

    def save_onscreen_talent_type(self, onScreenTalentType:OnScreenTalentType, token):
        talent_id = token.id
      
        self.db.query(Talent_onscreen_talent).filter(Talent_onscreen_talent.talent_id == talent_id).filter(Talent_onscreen_talent.profession_code == onScreenTalentType.profession_code).delete()
        self.db.commit()
        for talentProfessionRow in onScreenTalentType.profession: 
            onscreen_talent_obj =  Talent_onscreen_talent(talent_id=talent_id,profession_name=onScreenTalentType.profession_name,profession_code=onScreenTalentType.profession_code,profession_category_code=talentProfessionRow['code'],profession_category_name=talentProfessionRow['display_name'],created_on = dateTime_at)
            self.db.add(onscreen_talent_obj)
            self.db.commit()
            self.db.refresh(onscreen_talent_obj)

        ####    LOGIC FOR GET ONSCREEN TALENT TYPE SELECTED 
        selected_onscreen_talent = get_selected_onscreen_talent(talent_id)

        ####    LOGIC FOR GET ONSCREEN TALENT TYPE SELECTED 
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess,"selected_onscreen_talent":selected_onscreen_talent}
        return response

class LanguageLocationService(AppService):
    
    def GetLangIndusLoc(self, token) -> ServiceResult:
        lang_loc_data = LangLocCRUD(self.db).get_language_industries_location(token)
        if not lang_loc_data:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(lang_loc_data)

    def SaveLangIndusLoc(self, getTalentLanguageFileds:GetTalentLanguageFileds, Request, token) -> ServiceResult:
        lang_loc_data = LangLocCRUD(self.db).save_language_industries_location(getTalentLanguageFileds, Request,token)
        if not lang_loc_data:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(lang_loc_data)

class LangLocCRUD(AppCRUD):

    def get_language_industries_location(self, token):
        talent_id = token.id
        languages_list = list(mongodbConn.form_options.aggregate([
            { "$match" : { "type" : 'languages'}},  
            { "$project": { "languages":"$values", "_id" : 0}}  
        ]))
        languageList = []
        for languageRow in languages_list:
            languageList = languageRow['languages']

        location_list = list(mongodbConn.form_options.aggregate([
            { "$match" : { "type" : 'industry_locations'}},
            { "$project": { "locations":"$values", "_id" : 0}}  
        ]))
        locationList = []
        for locationRow in location_list:
            locationList = locationRow['locations']

        ### GET TALENT LANGUAGE SKILLS
      
        language_skills = self.db.query(Talent_language_skills).filter(Talent_language_skills.talent_id == talent_id).filter(Talent_language_skills.is_mother_tongue == 0).filter(Talent_language_skills.is_other == 0).all()

        language_skills_mother_tongue = self.db.query(Talent_language_skills).filter(Talent_language_skills.talent_id == talent_id).filter(Talent_language_skills.is_mother_tongue == 1).first()
        language_skills_mother_tongue_obj = {}
        if language_skills_mother_tongue:
            language_skills_mother_tongue_obj = language_skills_mother_tongue

        language_skills_other_obj = self.db.query(Talent_language_skills).filter(Talent_language_skills.talent_id == talent_id).filter(Talent_language_skills.is_other == 1).first()
        if language_skills_other_obj:
            language_skills_other = language_skills_other_obj.name
        else:
            language_skills_other = ""

        ### GET TALENT INDUSTRY LOCATION
        industry_location = self.db.query(Talent_industry_location).filter(Talent_industry_location.talent_id == talent_id).filter(Talent_industry_location.is_primary == 0).filter(Talent_industry_location.is_other == 0).all()
        industry_location_primary = self.db.query(Talent_industry_location).filter(Talent_industry_location.talent_id == talent_id).filter(Talent_industry_location.is_primary == 1).first()
        industry_location_primary_obj = {}
        if industry_location_primary:
            industry_location_primary_obj = industry_location_primary

        industry_location_other_obj = self.db.query(Talent_industry_location).filter(Talent_industry_location.talent_id == talent_id).filter(Talent_industry_location.is_other == 1).first()
        if industry_location_other_obj:
            industry_location_other = industry_location_other_obj.name
        else:
            industry_location_other = ""

        user_selected = {'language_skills':language_skills,'language_skills_mother_tongue':language_skills_mother_tongue_obj,"language_skills_other":language_skills_other,'industry_location':industry_location,'industry_location_primary':industry_location_primary_obj,"industry_location_other":industry_location_other}

        # prof_comp_per = ProgressBar(self.db, talent_id, None).totalPercentage()   ##, "profile_percen":prof_comp_per

        qry = self.db.query(func.sum(Talent_profile_completion_logs.percentage).label("tal_per")).filter(Talent_profile_completion_logs.talent_id == talent_id).first()

        prof_comp_per = 0
        if qry.tal_per is not None:
            prof_comp_per = qry.tal_per

        userResponse={"user_selected":user_selected,"languages_list":languageList,"locations_list":locationList, "profile_percen":prof_comp_per}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess,"response":userResponse}
        return response

    def save_language_industries_location(self, getTalentLanguageFileds:GetTalentLanguageFileds, Request, token):
       
        talent_id = token.id

        ####### SAVE LANGUAGE
        mysqlConnection.execute(f"DELETE FROM talent_language_skills where talent_id = '{talent_id}' and is_other = 0")
        mydb.commit()

        if getTalentLanguageFileds.mother_tongue_lang:
            is_write = False
            if getTalentLanguageFileds.mother_tongue_lang['is_write']:
                is_write = getTalentLanguageFileds.mother_tongue_lang['is_write']

            is_read = False
            if getTalentLanguageFileds.mother_tongue_lang['is_read']:
                is_read = getTalentLanguageFileds.mother_tongue_lang['is_read']

            check_language_mother = Talent_language_skills(talent_id=talent_id,name=getTalentLanguageFileds.mother_tongue_lang['name'],value=getTalentLanguageFileds.mother_tongue_lang['value'],speak=getTalentLanguageFileds.mother_tongue_lang['speak'],is_read=is_read,is_write=is_write, is_mother_tongue=1,created_at = dateTime_at)
            self.db.add(check_language_mother)
            self.db.commit()
            self.db.refresh(check_language_mother)

        for languageRow in getTalentLanguageFileds.language_array:
            is_write = False
            if languageRow['is_write']:
                is_write = languageRow['is_write']

            is_read = False
            if languageRow['is_read']:
                is_read = languageRow['is_read']

            check_language_mother = self.db.query(Talent_language_skills).filter(Talent_language_skills.talent_id == talent_id).filter(Talent_language_skills.value == languageRow['value']).filter(Talent_language_skills.is_mother_tongue == 1).first()
            if check_language_mother is None:
                check_talent_language = Talent_language_skills(talent_id=talent_id,name=languageRow['name'],value=languageRow['value'],speak=languageRow['speak'],is_read=is_read,is_write=is_write, is_mother_tongue=0,created_at = dateTime_at)
                self.db.add(check_talent_language)
                self.db.commit()
                self.db.refresh(check_talent_language)

        if getTalentLanguageFileds.language_skills_other is not None:
            language_skills_other = getTalentLanguageFileds.language_skills_other
            language_other_obj = self.db.query(Talent_language_skills).filter(Talent_language_skills.talent_id == talent_id).filter(Talent_language_skills.is_other == 1).first()
            if not language_other_obj:
                language_other_obj = Talent_language_skills(talent_id=talent_id, name=language_skills_other,value=language_skills_other,is_other=1,created_at = dateTime_at)
            else:
                language_other_obj.name = language_skills_other
                language_other_obj.value = language_skills_other
                language_other_obj.updated_on = dateTime_at

            self.db.add(language_other_obj)
            self.db.commit()

        ########  SAVE INDUSTRY LOCATION
        mysqlConnection.execute(f"DELETE FROM talent_industry_location where talent_id = '{talent_id}' and is_other = 0")
        mydb.commit()

        if getTalentLanguageFileds.primary_location:
            check_location_primary = Talent_industry_location(talent_id=talent_id,name=getTalentLanguageFileds.primary_location['name'],code=getTalentLanguageFileds.primary_location['code'],is_primary=1,created_at = dateTime_at)
            
            self.db.add(check_location_primary)
            self.db.commit()
            self.db.refresh(check_location_primary)

        for locationRow in getTalentLanguageFileds.location_array:
            check_location_primary = self.db.query(Talent_industry_location).filter(Talent_industry_location.talent_id == talent_id).filter(Talent_industry_location.code == locationRow['code']).filter(Talent_industry_location.is_primary == 1).first()
            if check_location_primary is None:
                check_talent_location = Talent_industry_location(talent_id=talent_id,name=locationRow['name'],code=locationRow['code'],is_primary=0,created_at = dateTime_at)
                
                self.db.add(check_talent_location)
                self.db.commit()
                self.db.refresh(check_talent_location)

        if getTalentLanguageFileds.industry_location_other is not None:
            industry_location_other = getTalentLanguageFileds.industry_location_other
            location_other_obj = self.db.query(Talent_industry_location).filter(Talent_industry_location.talent_id == talent_id).filter(Talent_industry_location.is_other == 1).first()
            if not location_other_obj:
                location_other_obj = Talent_industry_location(talent_id=talent_id, name=industry_location_other,code=industry_location_other,is_other=1,created_at = dateTime_at)
            else:
                location_other_obj.name = industry_location_other
                location_other_obj.code = industry_location_other
                location_other_obj.updated_on = dateTime_at

            self.db.add(location_other_obj)
            self.db.commit()

        ProgressBar(self.db, talent_id, Request).saveLogPercentage()
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
        return response

class ProfileIntroService(AppService):
    def getProfileIntro(self, token) -> ServiceResult:
        profile_intro = ProfileIntroCRUD(self.db).get_profile_intro(token)
        if not profile_intro:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(profile_intro)

    def saveProfileIntro(self, profileIntroFileds:ProfileIntroFileds, Request, token) -> ServiceResult:
        profile_intro = ProfileIntroCRUD(self.db).save_profile_intro(profileIntroFileds, Request, token)
        if not profile_intro:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(profile_intro)

class ProfileIntroCRUD(AppCRUD):
    def get_profile_intro(self, token):
        talent_id = token.id

        check_profile_intro = self.db.query(Talent_profile_intro).filter((Talent_profile_intro.talent_id == talent_id)).first()
        profile_intro = {}
        if check_profile_intro:
            profile_intro = ProfileIntroFileds.from_orm(check_profile_intro)
        
        prof_comp_per = ProgressBar(self.db, talent_id, None).totalPercentage()
        userResponse={"profile_intro":profile_intro, "profile_percen":prof_comp_per}
     
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess,"response":userResponse}
        return response

    def save_profile_intro(self, profileIntroFileds:ProfileIntroFileds, Request, token):
        talent_id = token.id

        check_profile_intro = self.db.query(Talent_profile_intro).filter((Talent_profile_intro.talent_id == talent_id)).first()
        if check_profile_intro:
            check_profile_intro.additional_information = profileIntroFileds.additional_information
            check_profile_intro.personal_website = profileIntroFileds.personal_website
            check_profile_intro.personal_blog = profileIntroFileds.personal_blog
            check_profile_intro.instagram = profileIntroFileds.instagram
            check_profile_intro.behance = profileIntroFileds.behance
            check_profile_intro.IMDB = profileIntroFileds.IMDB
            check_profile_intro.modified_at = dateTime_at
        else:
            check_profile_intro = Talent_profile_intro(talent_id=talent_id,additional_information=profileIntroFileds.additional_information,personal_website=profileIntroFileds.personal_website,personal_blog=profileIntroFileds.personal_blog,instagram=profileIntroFileds.instagram,behance=profileIntroFileds.behance,IMDB=profileIntroFileds.IMDB,created_at = dateTime_at)
        self.db.add(check_profile_intro)
        self.db.commit()
        self.db.refresh(check_profile_intro)
        
        ProgressBar(self.db, talent_id, Request).saveLogPercentage()

        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
        return response

class WorkCreditService(AppService):
    def getWorkCredit(self, token) -> ServiceResult:
        work_credit = WorkCreditCRUD(self.db).get_work_credit(token)
        if not work_credit:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(work_credit)

    def saveWorkCredit(self, workCreditsFileds: NewWorkCreditsFileds, Request, token) -> ServiceResult:
        work_credit = WorkCreditCRUD(self.db).save_work_credit(workCreditsFileds, Request, token)
        if not work_credit:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(work_credit)

    def deleteWorkCredit(self, workCreditsFileds: WorkCreditsFileds, token) -> ServiceResult:
        work_credit = WorkCreditCRUD(self.db).delete_work_credit(workCreditsFileds, token)
        if not work_credit:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(work_credit)

class WorkCreditCRUD(AppCRUD):
    def get_work_credit(self, token):
        talent_id = token.id

        mysqlConnection.execute(f"SELECT code FROM talent_work_credits where talent_id='{talent_id}' group by code")
        work_credit = mysqlConnection.fetchall()
        mydb.commit()
        work_credit_selected = []
        for row_work_credit in work_credit:
            getName = self.db.query(Talent_work_credits).filter(Talent_work_credits.talent_id == talent_id).filter(Talent_work_credits.code == row_work_credit[0]).first()
            type_dict = {}
            type_dict['name'] = getName.production_type
            type_dict['code'] = row_work_credit[0]
            type_dict['value'] = []
            
            work_credit_type = self.db.query(Talent_work_credits).filter(Talent_work_credits.talent_id == talent_id).filter(Talent_work_credits.code == row_work_credit[0]).order_by(Talent_work_credits.id.asc()).all()
            for credit_type_row in work_credit_type:
                type_dict_values = {}
                type_dict_values['id'] = base64.b64encode(str(credit_type_row.id).encode("ascii"))
                type_dict_values['start_year_month'] = credit_type_row.start_year_month
                type_dict_values['end_year_month'] = credit_type_row.end_year_month
                type_dict_values['production_type'] = credit_type_row.production_type
                type_dict_values['production_name'] = credit_type_row.production_name
                type_dict_values['role'] = credit_type_row.role
                type_dict_values['production_house'] = credit_type_row.production_house
                type_dict['value'].append(type_dict_values)
            work_credit_selected.append(type_dict)

        ########### FETCH ADDED WORK_CREDIT
        production_type_list = list(mongodbConn.form_options.aggregate([
            { "$match" : { "type" : 'work_credit'}},    
            { "$project": { "production_types":"$values", "_id" : 0}}   
        ]))

        productionList = []
        for productionRow in production_type_list:
            productionList = productionRow['production_types']

        prof_comp_per = ProgressBar(self.db, talent_id, None).totalPercentage()
        userResponse = {"work_credit_selected": work_credit_selected, "production_type_list": productionList, "profile_percen":prof_comp_per}
     
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess,"response": userResponse}
        return response

    def save_work_credit(self, workCreditsFileds: NewWorkCreditsFileds, Request, token):
        talent_id = token.id
        if workCreditsFileds.id is not None:
            base64_bytes = bytes(workCreditsFileds.id, encoding="raw_unicode_escape")
            id = base64.b64decode(base64_bytes).decode("ascii")
            work_credit = self.db.query(Talent_work_credits).filter((Talent_work_credits.id == id)).first()
            if work_credit:
                work_credit.start_year_month = workCreditsFileds.start_year_month
                work_credit.end_year_month = workCreditsFileds.end_year_month
                work_credit.production_type = workCreditsFileds.production_type
                work_credit.code = workCreditsFileds.code
                work_credit.production_name = workCreditsFileds.production_name
                work_credit.role = workCreditsFileds.role
                work_credit.production_house = workCreditsFileds.production_house
                work_credit.modified_at = dateTime_at
            else:
                return ServiceResult(AppException.CreateValidation())
        else:   
            work_credit = Talent_work_credits(talent_id=talent_id,start_year_month=workCreditsFileds.start_year_month,end_year_month=workCreditsFileds.end_year_month,production_type=workCreditsFileds.production_type,code=workCreditsFileds.code,production_name=workCreditsFileds.production_name,role=workCreditsFileds.role,production_house=workCreditsFileds.production_house,created_at = dateTime_at)
        self.db.add(work_credit)
        self.db.commit()

        ProgressBar(self.db, talent_id, Request).saveLogPercentage()

        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
        return response

    def delete_work_credit(self, workCreditsFileds: WorkCreditsFileds, token):
        if workCreditsFileds.id is not None:
            base64_bytes = bytes(workCreditsFileds.id, encoding="raw_unicode_escape")
            id = base64.b64decode(base64_bytes).decode("ascii")
            work_credit = self.db.query(Talent_work_credits).filter((Talent_work_credits.id == id)).first()
            if work_credit:
                self.db.query(Talent_work_credits).filter(Talent_work_credits.id == id).delete()
                self.db.commit()
            else:
                return ServiceResult(AppException.CreateValidation())
        else:
            return ServiceResult(AppException.CreateValidation())

        response = "Data deleted"
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response": response}
        return response

class EducationTrainingService(AppService):
    def getEducationTraining(self, token) -> ServiceResult:
        education_training = EducationTrainingCRUD(self.db).get_education_training(token)
        if not education_training:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(education_training)

    def saveEducationTraining(self, talentEducation:TalentEducation, Request, token) -> ServiceResult:
        education_training = EducationTrainingCRUD(self.db).save_education_training(talentEducation, Request, token)
        if not education_training:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(education_training)

    def deleteEducationTraing(self, talentEducation:TalentEducationBase, token) -> ServiceResult:
        education_training = EducationTrainingCRUD(self.db).delete_education_training(talentEducation, token)
        if not education_training:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(education_training)

class EducationTrainingCRUD(AppCRUD):
    def get_education_training(self, token):
        talent_id = token.id

        talentEducation = self.db.query(Talent_education).filter(Talent_education.talent_id == talent_id).all()
        education_arry=[]
        diploma_arry=[]
        certificate_arry=[]
        if talentEducation is not None:
            for educationRow in talentEducation:
                if educationRow.type=='education':
                    education_data = {"education": educationRow.education, "subject": educationRow.subject,"university": educationRow.university,"year_of_passing": educationRow.year_of_passing,"type": educationRow.type,"id": base64.b64encode(str(educationRow.id).encode("ascii"))}
                    education_arry.append(education_data.copy())
                
                if educationRow.type=='diploma':
                    diploma_data = {"education": educationRow.education, "subject": educationRow.subject,"university": educationRow.university,"year_of_passing": educationRow.year_of_passing,"type": educationRow.type,"id": base64.b64encode(str(educationRow.id).encode("ascii"))}
                    diploma_arry.append(diploma_data.copy())

                if educationRow.type=='certificate':
                    certificate_data = {"education": educationRow.education, "subject": educationRow.subject,"university": educationRow.university,"year_of_passing": educationRow.year_of_passing,"type": educationRow.type,"id": base64.b64encode(str(educationRow.id).encode("ascii"))}
                    certificate_arry.append(certificate_data.copy())
        
        prof_comp_per = ProgressBar(self.db, talent_id, None).totalPercentage() 

        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "education":education_arry,"diploma":diploma_arry,"certificate":certificate_arry, "profile_percen":prof_comp_per}
        return response

    def save_education_training(self, talentEducation: TalentEducation, Request, token):
        talent_id = token.id
        if talentEducation.id is not None:
            base64_bytes = bytes(talentEducation.id, encoding="raw_unicode_escape")
            id = base64.b64decode(base64_bytes).decode("ascii")
            talent_education_obj = self.db.query(Talent_education).filter(Talent_education.talent_id == talent_id).filter(Talent_education.id == id).first()
            if talent_education_obj:
                talent_education_obj.education = talentEducation.education
                talent_education_obj.subject = talentEducation.subject
                talent_education_obj.university = talentEducation.university
                talent_education_obj.year_of_passing = talentEducation.year_of_passing
                talent_education_obj.type = talentEducation.type
                talent_education_obj.updated_on = dateTime_at
            else:
                return ServiceResult(AppException.CreateValidation())
        else:
            talent_education_obj = Talent_education(talent_id=talent_id,education=talentEducation.education,subject=talentEducation.subject,university=talentEducation.university,year_of_passing=talentEducation.year_of_passing,type=talentEducation.type,created_on = dateTime_at,updated_on = dateTime_at)
        self.db.add(talent_education_obj)
        self.db.commit()
        self.db.refresh(talent_education_obj)

        ProgressBar(self.db, talent_id, Request).saveLogPercentage()

        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
        return response

    def delete_education_training(self, talentEducation:TalentEducationBase, token):
        talent_id = token.id

        base64_bytes = bytes(talentEducation.id, encoding="raw_unicode_escape")
        id = base64.b64decode(base64_bytes).decode("ascii")
        self.db.query(Talent_education).filter(Talent_education.talent_id == talent_id).filter(Talent_education.id == id).delete()
        self.db.commit()
        response = {"status" : statusCodeSuccess, "message" : "Data Deleted"}
        return response

class PhysicalAppearanceService(AppService):
    def getPhysicalAppearance(self, token) -> ServiceResult:
        skill_interest = PhysicalAppearanceCRUD(self.db).get_physical_appearance(token)
        if not skill_interest:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(skill_interest)

    def savePhysicalAppearance(self, physicalAppearances:TalentPhysicalAppearance, Request, token) -> ServiceResult:
        skill_interest = PhysicalAppearanceCRUD(self.db).save_physical_appearance(physicalAppearances, Request, token)
        if not skill_interest:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(skill_interest)

class PhysicalAppearanceCRUD(AppCRUD):
    def get_physical_appearance(self, token):
        talent_id = token.id

        get_physical_appearance = self.db.query(Talent_physical_appearance).filter(Talent_physical_appearance.talent_id == talent_id).first()
        physical_appearance_data = {}
        if get_physical_appearance:
            physical_appearance_data={"ethnicity":get_physical_appearance.ethnicity,"feet_height":get_physical_appearance.feet_height,"inch_height":get_physical_appearance.inch_height,"skin_tone":get_physical_appearance.skin_tone,"weight":get_physical_appearance.weight,"eye_colour":get_physical_appearance.eye_colour,"build":get_physical_appearance.build,"hair_colour":get_physical_appearance.hair_colour,"playing_age":get_physical_appearance.playing_age,"hair_length":get_physical_appearance.hair_length}
        
        #ETHNICITY_LIST
        ethnicity_list = list(mongodbConn.form_options.aggregate([
            { "$match" : { "type" : 'ethnicity'}},  
            { "$project": { "ethnicity":"$values", "_id" : 0}}  
        ]))

        ethnicityList = []
        for ethnicityRow in ethnicity_list:
            ethnicityList = ethnicityRow['ethnicity']

        #SKIN_COLOR_LIST
        skin_color_list = list(mongodbConn.form_options.aggregate([
            { "$match" : { "type" : 'skin_color'}}, 
            { "$project": { "skin_colors":"$values", "_id" : 0}}    
        ]))

        skinColorList = []
        for skinColorRow in skin_color_list:
            skinColorList = skinColorRow['skin_colors']
        
        #EYE_COLOR_LIST
        eye_color_list = list(mongodbConn.form_options.aggregate([
            { "$match" : { "type" : 'eye_color'}},  
            { "$project": { "eye_colors":"$values", "_id" : 0}} 
        ]))

        eyeColorList = []
        for eyeColorRow in eye_color_list:
            eyeColorList = eyeColorRow['eye_colors']

        #HAIR_LENGTH_LIST
        hair_length_list = list(mongodbConn.form_options.aggregate([
            { "$match" : { "type" : 'Hair_Length'}},    
            { "$project": { "hair_length":"$values", "_id" : 0}}    
        ]))

        hairLengthList = []
        for hairLengthRow in hair_length_list:
            hairLengthList = hairLengthRow['hair_length']

        #BUILD_LIST
        build_list = list(mongodbConn.form_options.aggregate([
            { "$match" : { "type" : 'build'}},  
            { "$project": { "build":"$values", "_id" : 0}}  
        ]))

        BuildList = []
        for BuildRow in build_list:
            BuildList = BuildRow['build']
        
        prof_comp_per = ProgressBar(self.db, talent_id, None).totalPercentage()
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess,"physical_appearance_data":physical_appearance_data,"ethnicity_list":ethnicityList,"skin_color_list":skinColorList,"eye_color_list":eyeColorList,"hair_length_list":hairLengthList,"build_list":BuildList,"profile_percen":prof_comp_per}
        return response

    def save_physical_appearance(self, physicalAppearances:TalentPhysicalAppearance, Request, token):
        talent_id = token.id

        physical_appearance_obj = self.db.query(Talent_physical_appearance).filter(Talent_physical_appearance.talent_id == talent_id).first()
        if physical_appearance_obj:
            physical_appearance_obj.ethnicity = physicalAppearances.ethnicity
            physical_appearance_obj.feet_height = physicalAppearances.feet_height
            physical_appearance_obj.inch_height = physicalAppearances.inch_height
            physical_appearance_obj.skin_tone = physicalAppearances.skin_tone
            physical_appearance_obj.weight = physicalAppearances.weight
            physical_appearance_obj.eye_colour = physicalAppearances.eye_colour
            physical_appearance_obj.build = physicalAppearances.build
            physical_appearance_obj.hair_colour = physicalAppearances.hair_colour
            physical_appearance_obj.playing_age = physicalAppearances.playing_age
            physical_appearance_obj.hair_length = physicalAppearances.hair_length
            physical_appearance_obj.updated_on = dateTime_at
        else:
            physical_appearance_obj = Talent_physical_appearance(talent_id=talent_id,ethnicity=physicalAppearances.ethnicity,feet_height=physicalAppearances.feet_height,inch_height=physicalAppearances.inch_height,skin_tone=physicalAppearances.skin_tone,weight=physicalAppearances.weight,eye_colour=physicalAppearances.eye_colour,build=physicalAppearances.build,hair_colour=physicalAppearances.hair_colour,playing_age=physicalAppearances.playing_age,hair_length=physicalAppearances.hair_length,created_on = dateTime_at)
        self.db.add(physical_appearance_obj)
        self.db.commit()

        ProgressBar(self.db, talent_id, Request).saveLogPercentage()

        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
        return response

class SkillIntService(AppService):
    def getSkillInterest(self, token) -> ServiceResult:
        skill_interest = SkillInterestCRUD(self.db).get_skill_interest(token)
        if not skill_interest:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(skill_interest)

    def saveSkillInterest(self, talentSkillsetInterest:TalentSkillsetInterest, Request, token) -> ServiceResult:
        skill_interest = SkillInterestCRUD(self.db).save_skill_interest(talentSkillsetInterest, Request, token)
        if not skill_interest:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(skill_interest)

class SkillInterestCRUD(AppCRUD):
    def get_skill_interest(self, token):
        talent_id = token.id

        ### FETCH SKILLSET INTEREST
        experienced_in = []
        skillset_interest_type = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'experienced_in').order_by(Talent_skillset_interests.id.asc()).all()
        for skillset_interest_type_row in skillset_interest_type:
            type_dict_values = {}
            type_dict_values['type'] = skillset_interest_type_row.type
            type_dict_values['value'] = skillset_interest_type_row.value
            type_dict_values['is_other'] = skillset_interest_type_row.is_other
            experienced_in.append(type_dict_values.copy())

        interested_in = []
        skillset_interest_type = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'interested_in').order_by(Talent_skillset_interests.id.asc()).all()
        for skillset_interest_type_row in skillset_interest_type:
            type_dict_values = {}
            type_dict_values['type'] = skillset_interest_type_row.type
            type_dict_values['value'] = skillset_interest_type_row.value
            type_dict_values['is_other'] = skillset_interest_type_row.is_other
            interested_in.append(type_dict_values.copy())

        singing_in = []
        skillset_interest_type = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'singing_in').order_by(Talent_skillset_interests.id.asc()).all()
        for skillset_interest_type_row in skillset_interest_type:
            type_dict_values = {}
            type_dict_values['type'] = skillset_interest_type_row.type
            type_dict_values['value'] = skillset_interest_type_row.value
            type_dict_values['is_other'] = skillset_interest_type_row.is_other
            singing_in.append(type_dict_values.copy())

        singing_other_obj = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'singing_in').filter(Talent_skillset_interests.is_other == 1).first()
        if singing_other_obj:
            singing_in_other = singing_other_obj.type
        else:
            singing_in_other = ""

        dancing_in = []
        skillset_interest_type = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'dancing_in').order_by(Talent_skillset_interests.id.asc()).all()
        for skillset_interest_type_row in skillset_interest_type:
            type_dict_values = {}
            type_dict_values['type'] = skillset_interest_type_row.type
            type_dict_values['value'] = skillset_interest_type_row.value
            type_dict_values['is_other'] = skillset_interest_type_row.is_other
            dancing_in.append(type_dict_values.copy())

        dancing_other_obj = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'dancing_in').filter(Talent_skillset_interests.is_other == 1).first()
        if dancing_other_obj:
            dancing_in_other = dancing_other_obj.type
        else:
            dancing_in_other = ""

        musical_in = []
        skillset_interest_type = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'musical_in').order_by(Talent_skillset_interests.id.asc()).all()
        for skillset_interest_type_row in skillset_interest_type:
            type_dict_values = {}
            type_dict_values['type'] = skillset_interest_type_row.type
            type_dict_values['value'] = skillset_interest_type_row.value
            type_dict_values['is_other'] = skillset_interest_type_row.is_other
            musical_in.append(type_dict_values.copy())

        musical_other_obj = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'musical_in').filter(Talent_skillset_interests.is_other == 1).first()
        if musical_other_obj:
            musical_in_other = musical_other_obj.type
        else:
            musical_in_other = ""

        skills_in = []
        skillset_interest_type = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'skills_in').order_by(Talent_skillset_interests.id.asc()).all()
        for skillset_interest_type_row in skillset_interest_type:
            type_dict_values = {}
            type_dict_values['type'] = skillset_interest_type_row.type
            type_dict_values['value'] = skillset_interest_type_row.value
            type_dict_values['is_other'] = skillset_interest_type_row.is_other
            skills_in.append(type_dict_values.copy())

        skills_other_obj = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'skills_in').filter(Talent_skillset_interests.is_other == 1).first()
        if skills_other_obj:
            skills_in_other = skills_other_obj.type
        else:
            skills_in_other = ""
        ###### FETCH SKILLSET INTEREST

        ###### FETCH SKILLSET INTEREST ONSCREEN
        skillset_interests_onscreen = self.db.query(Talent_skillset_interest_onscreen).filter((Talent_skillset_interest_onscreen.talent_id == talent_id)).first()
        skillset_interests_data = {}
        if skillset_interests_onscreen:
            skillset_interests_data={"intimate_scene":skillset_interests_onscreen.intimate_scenes,"nude_scene":skillset_interests_onscreen.nude_scenes,"kiss_scene":skillset_interests_onscreen.kiss_scenes}

        prof_comp_per = ProgressBar(self.db, talent_id, None).totalPercentage()
        userResponse = {"experienced_in":experienced_in,"interested_in":interested_in,"singing_in":singing_in,"singing_in_other":singing_in_other,"dancing_in":dancing_in,"dancing_in_other":dancing_in_other,"musical_in":musical_in,"musical_in_other":musical_in_other,"skills_in":skills_in,"skills_in_other":skills_in_other, "skillset_interests_onscreen" : skillset_interests_data,"profile_percen":prof_comp_per}

        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess,"response": userResponse}
        return response

    def save_skill_interest(self, talentSkillsetInterest:TalentSkillsetInterest, Request, token):
        talent_id = token.id

        for row_experience_id in talentSkillsetInterest.experienced_in:
            experience_obj = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'experienced_in').filter(Talent_skillset_interests.value == row_experience_id['value']).first()
            if not experience_obj:
                experience_obj = Talent_skillset_interests(talent_id=talent_id,skill_type='experienced_in',type=row_experience_id['type'],value=row_experience_id['value'],is_other=0,created_at = dateTime_at)
                self.db.add(experience_obj)
                self.db.commit()
        
        for row_interested_in in talentSkillsetInterest.interested_in:
            interested_obj = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'interested_in').filter(Talent_skillset_interests.value == row_interested_in['value']).first()
            if not interested_obj:
                interested_obj = Talent_skillset_interests(talent_id=talent_id,skill_type='interested_in',type=row_interested_in['type'],value=row_interested_in['value'],is_other=0,created_at = dateTime_at)
                self.db.add(interested_obj)
                self.db.commit()

        for row_singing_in in talentSkillsetInterest.singing_in:
            singing_obj = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'singing_in').filter(Talent_skillset_interests.value == row_singing_in['value']).first()
            if not singing_obj:
                singing_obj = Talent_skillset_interests(talent_id=talent_id,skill_type='singing_in',type=row_singing_in['type'],value=row_singing_in['value'],is_other=0,created_at = dateTime_at)
                self.db.add(singing_obj)
                self.db.commit()  

        if talentSkillsetInterest.singing_in_other is not None:
            singing_in_other = talentSkillsetInterest.singing_in_other
            singing_other_obj = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'singing_in').filter(Talent_skillset_interests.is_other == 1).first()
            if not singing_other_obj:
                singing_other_obj = Talent_skillset_interests(talent_id=talent_id,skill_type='singing_in',type=singing_in_other,value=singing_in_other,is_other=1,created_at = dateTime_at)
            else:
                singing_other_obj.type = singing_in_other
                singing_other_obj.value = singing_in_other
                singing_other_obj.updated_on = dateTime_at

            self.db.add(singing_other_obj)
            self.db.commit()

        for row_dancing_in in talentSkillsetInterest.dancing_in:
            dancing_obj = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'dancing_in').filter(Talent_skillset_interests.value == row_dancing_in['value']).first()
            if not dancing_obj:
                dancing_obj = Talent_skillset_interests(talent_id=talent_id,skill_type='dancing_in',type=row_dancing_in['type'],value=row_dancing_in['value'],is_other=0,created_at = dateTime_at)
                self.db.add(dancing_obj)
                self.db.commit()

        if talentSkillsetInterest.dancing_in_other is not None:
            dancing_in_other = talentSkillsetInterest.dancing_in_other
            dancing_other_obj = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'dancing_in').filter(Talent_skillset_interests.is_other == 1).first()
            if not dancing_other_obj:
                dancing_other_obj = Talent_skillset_interests(talent_id=talent_id,skill_type='dancing_in',type=dancing_in_other,value=dancing_in_other,is_other=1,created_at = dateTime_at)
            else:
                dancing_other_obj.type = dancing_in_other
                dancing_other_obj.value = dancing_in_other
                dancing_other_obj.updated_on = dateTime_at

            self.db.add(dancing_other_obj)
            self.db.commit()

        for row_musical_in in talentSkillsetInterest.musical_in:
            musical_obj = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'musical_in').filter(Talent_skillset_interests.value == row_musical_in['value']).first()
            if not musical_obj:
                musical_obj = Talent_skillset_interests(talent_id=talent_id,skill_type='musical_in',type=row_musical_in['type'],value=row_musical_in['value'],is_other=0,created_at = dateTime_at)
                self.db.add(musical_obj)
                self.db.commit()

        if talentSkillsetInterest.musical_in_other is not None:
            musical_in_other = talentSkillsetInterest.musical_in_other
            musical_other_obj = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'musical_in').filter(Talent_skillset_interests.is_other == 1).first()
            if not musical_other_obj:
                musical_other_obj = Talent_skillset_interests(talent_id=talent_id,skill_type='musical_in',type=musical_in_other,value=musical_in_other,is_other=1,created_at = dateTime_at)
            else:
                musical_other_obj.type = musical_in_other
                musical_other_obj.value = musical_in_other
                musical_other_obj.updated_on = dateTime_at

            self.db.add(musical_other_obj)
            self.db.commit()

        for row_skills_in in talentSkillsetInterest.skills_in:
            skills_obj = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'skills_in').filter(Talent_skillset_interests.value == row_skills_in['value']).first()
            if not skills_obj:
                skills_obj = Talent_skillset_interests(talent_id=talent_id,skill_type='skills_in',type=row_skills_in['type'],value=row_skills_in['value'],is_other=0,created_at = dateTime_at)
                self.db.add(skills_obj)
                self.db.commit()

        if talentSkillsetInterest.skills_in_other is not None:
            skills_in_other = talentSkillsetInterest.skills_in_other
            skills_other_obj = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'skills_in').filter(Talent_skillset_interests.is_other == 1).first()
            if not skills_other_obj:
                skills_other_obj = Talent_skillset_interests(talent_id=talent_id,skill_type='skills_in',type=skills_in_other,value=skills_in_other,is_other=1,created_at = dateTime_at)
            else:
                skills_other_obj.type = skills_in_other
                skills_other_obj.value = skills_in_other
                skills_other_obj.updated_on = dateTime_at

            self.db.add(skills_other_obj)
            self.db.commit()

        if talentSkillsetInterest.on_screen_performance:
            on_screen_obj = self.db.query(Talent_skillset_interest_onscreen).filter(Talent_skillset_interest_onscreen.talent_id == talent_id).first()
            if on_screen_obj:
                on_screen_obj.intimate_scenes = talentSkillsetInterest.on_screen_performance['intimate_scene']
                on_screen_obj.nude_scenes = talentSkillsetInterest.on_screen_performance['nude_scene']
                on_screen_obj.kiss_scenes = talentSkillsetInterest.on_screen_performance['kiss_scene']
                on_screen_obj.updated_at = dateTime_at
            else:
                on_screen_obj = Talent_skillset_interest_onscreen(talent_id=talent_id,intimate_scenes=talentSkillsetInterest.on_screen_performance['intimate_scene'],nude_scenes=talentSkillsetInterest.on_screen_performance['nude_scene'],kiss_scenes=talentSkillsetInterest.on_screen_performance['kiss_scene'],created_at = dateTime_at)
            self.db.add(on_screen_obj)
            self.db.commit()

        ProgressBar(self.db, talent_id, Request).saveLogPercentage()

        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
        return response
        
class AgentService(AppService):
    def saveAgentRepresentation(self, TalentAgentRepresentation:TalentAgentRepresentation, Request, token) -> ServiceResult:
        agent_representation = AgentRepresentationCRUD(self.db).save_agent_representation(TalentAgentRepresentation, Request,token)
        if not agent_representation:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(agent_representation)

    def getAgentRepresentation(self,token) -> ServiceResult:
        agent_representation = AgentRepresentationCRUD(self.db).get_agent_representation(token)
        if not agent_representation:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(agent_representation)

    def viewProfile(self, talent_id:str) -> ServiceResult:
        agent_representation = AgentRepresentationCRUD(self.db).view_profile(talent_id)
        if not agent_representation:
            return ServiceResult(AppException.GetValidation("Data not found"))
        return ServiceResult(agent_representation)

class AgentRepresentationCRUD(AppCRUD):
    def save_agent_representation(self, TalentAgentRepresentation:TalentAgentRepresentation, Request, token):
        talent_id = token.id
        agent_representation_obj = self.db.query(Talent_agent_representation).filter(Talent_agent_representation.talent_id == talent_id).first()
        if agent_representation_obj:
            agent_representation_obj.talent_id = talent_id
            agent_representation_obj.have_agent = TalentAgentRepresentation.have_agent
            agent_representation_obj.agency_name = TalentAgentRepresentation.agency_name
            agent_representation_obj.agent_email = TalentAgentRepresentation.agent_email
            agent_representation_obj.telephone = TalentAgentRepresentation.telephone
            agent_representation_obj.agent_website = TalentAgentRepresentation.agent_website
            agent_representation_obj.covering_industries = TalentAgentRepresentation.covering_industries
            agent_representation_obj.agent_alert_message = TalentAgentRepresentation.agent_alert_message
            agent_representation_obj.agent_looking_profile = TalentAgentRepresentation.agent_looking_profile
            agent_representation_obj.modified_at = dateTime_at
        else:
            agent_representation_obj = Talent_agent_representation(talent_id=talent_id,have_agent=TalentAgentRepresentation.have_agent,agency_name=TalentAgentRepresentation.agency_name,agent_email=TalentAgentRepresentation.agent_email,telephone=TalentAgentRepresentation.telephone,agent_website=TalentAgentRepresentation.agent_website,covering_industries=TalentAgentRepresentation.covering_industries,agent_alert_message=TalentAgentRepresentation.agent_alert_message,agent_looking_profile=TalentAgentRepresentation.agent_looking_profile,created_at = dateTime_at)

            talent_personal_info = self.db.query(Talent_personal_info).filter(Talent_personal_info.talent_id == talent_id).first()
            if talent_personal_info:
                talent_industry = self.db.query(Talent_industry).filter(Talent_industry.talent_id == talent_id).filter(Talent_industry.is_primary == 1).first()
                if talent_industry:
                    last_rec = self.db.query(Talent_personal_info).filter(Talent_personal_info.tk_id !='').order_by(Talent_personal_info.talent_id.desc()).first()
                    if last_rec is not None:
                        last_tk_id = ''.join(filter(lambda i: i.isdigit(), last_rec.tk_id))
                        new_tk_id=int(last_tk_id)+1
                        tk_id="TK"+str(talent_industry.industry_code)+str(new_tk_id)
                    else:
                        tk_id="TK"+str(talent_industry.industry_code)+str(10010001)
                else:
                    last_rec = self.db.query(Talent_personal_info).filter(Talent_personal_info.tk_id !='').order_by(Talent_personal_info.talent_id.desc()).first()
                    if last_rec is not None:
                        last_tk_id = ''.join(filter(lambda i: i.isdigit(), last_rec.tk_id))
                        new_tk_id=int(last_tk_id)+1
                        tk_id="TK"+str(new_tk_id)
                    else:
                        tk_id="TK"+str(10010001)

                url = Request.url
                parsed_url = urlparse(str(url))
                captured_value = str(parsed_url.path).split('/')
                api_name = captured_value[1]+'/'+captured_value[2]
                ip_address = parsed_url.scheme+"://"+parsed_url.netloc
                if talent_personal_info.qr_code is None:
                    enc_id = base64.b64encode(str(talent_id).encode("ascii"))
                    non_byte_str = enc_id.decode("utf-8")
                    
                    url = ip_address+'/'+api_name+'/view_profile/'+str(non_byte_str)
                    
                    qr_code = pyqrcode.create(url)
                    imageName = str(talent_id)+'_'+str(random.randint(1000, 9999))+'_qr_code.png'
                    qr_code.png(str(FOLDER_NAME)+imageName, scale=8) 

                    talent_register =  self.db.query(Talent_register).filter((Talent_register.id == talent_id)).first()
                    user_bucket = talent_register.s3_bucket
                    return_s3_url = media_upload.upload_portfolio(talent_id, imageName, user_bucket)
                    if return_s3_url:
                        talent_personal_info.qr_code = return_s3_url

                talent_personal_info.tk_id=tk_id
                talent_personal_info.url_link=ip_address
                self.db.add(talent_personal_info)
                self.db.commit()
                self.db.refresh(talent_personal_info)

        self.db.add(agent_representation_obj)
        self.db.commit()

        ###     UPDATE IN MONGODB
        talent_register =  self.db.query(Talent_register.id,Talent_register.first_name,Talent_register.last_name,Talent_register.email).filter((Talent_register.id == talent_id)).first()

        talent_personal_info = self.db.query(Talent_personal_info.display_name,Talent_personal_info.tk_id,Talent_personal_info.gender,Talent_personal_info.nationality,Talent_personal_info.state,Talent_personal_info.city,Talent_personal_info.qr_code,Talent_personal_info.avatar_url).filter(Talent_personal_info.talent_id == talent_id).first()

        location = {"country":talent_personal_info.nationality, "state":talent_personal_info.state, "city":talent_personal_info.city}

        industry_location = []
        talent_industry_location = self.db.query(Talent_industry_location.name,Talent_industry_location.code,Talent_industry_location.is_primary,Talent_industry_location.is_other).filter(Talent_industry_location.talent_id == talent_id).all()
        
        if talent_industry_location:
            for industryLocationRow in talent_industry_location:
                industry = {"code": industryLocationRow.code, "is_primary": industryLocationRow.is_primary,"name": industryLocationRow.name, "is_other": industryLocationRow.is_other}
                industry_location.append(industry)

        language_skills = []
        talent_language_skills = self.db.query(Talent_language_skills.name,Talent_language_skills.value,Talent_language_skills.speak,Talent_language_skills.is_read,Talent_language_skills.is_write,Talent_language_skills.is_mother_tongue,Talent_language_skills.is_other).filter(Talent_language_skills.talent_id == talent_id).all()
        
        if talent_language_skills:
            for LanguageRow in talent_language_skills:
                industry = {"name": LanguageRow.name, "value": LanguageRow.value, "is_mother_tongue": LanguageRow.is_mother_tongue,"speak": LanguageRow.speak,"is_read": LanguageRow.is_read,"is_write": LanguageRow.is_write, "is_other": LanguageRow.is_other}
                language_skills.append(industry)

        talentEducation = self.db.query(Talent_education).filter(Talent_education.talent_id == talent_id).all()
        education_arry=[]
        diploma_arry=[]
        certificate_arry=[]
        if talentEducation is not None:
            for educationRow in talentEducation:
                if educationRow.type=='education':
                    education_data = {"education": educationRow.education, "subject": educationRow.subject,"university": educationRow.university,"year_of_passing": educationRow.year_of_passing}
                    education_arry.append(education_data.copy())
                
                if educationRow.type=='diploma':
                    diploma_data = {"education": educationRow.education,"university": educationRow.university,"year_of_passing": educationRow.year_of_passing}
                    diploma_arry.append(diploma_data.copy())

                if educationRow.type=='certificate':
                    certificate_data = {"education": educationRow.education,"university": educationRow.university,"year_of_passing": educationRow.year_of_passing}
                    certificate_arry.append(certificate_data.copy())
        education = {"education_arry": education_arry, "diploma_arry": diploma_arry, "certificate_arry": certificate_arry}

        get_physical_appearance = self.db.query(Talent_physical_appearance).filter(Talent_physical_appearance.talent_id == talent_id).first()
        physical_appearance_data = {}
        if get_physical_appearance:
            physical_appearance_data={"ethnicity":get_physical_appearance.ethnicity,"feet_height":get_physical_appearance.feet_height,"inch_height":get_physical_appearance.inch_height,"skin_tone":get_physical_appearance.skin_tone,"weight":get_physical_appearance.weight,"eye_colour":get_physical_appearance.eye_colour,"build":get_physical_appearance.build,"hair_colour":get_physical_appearance.hair_colour,"playing_age":get_physical_appearance.playing_age,"hair_length":get_physical_appearance.hair_length}

        experienced_in = []
        skillset_interest_type = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'experienced_in').order_by(Talent_skillset_interests.id.asc()).all()
        for skillset_interest_type_row in skillset_interest_type:
            type_dict_values = {}
            type_dict_values['type'] = skillset_interest_type_row.type
            type_dict_values['value'] = skillset_interest_type_row.value
            type_dict_values['is_other'] = skillset_interest_type_row.is_other
            experienced_in.append(type_dict_values.copy())

        interested_in = []
        skillset_interest_type = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'interested_in').order_by(Talent_skillset_interests.id.asc()).all()
        for skillset_interest_type_row in skillset_interest_type:
            type_dict_values = {}
            type_dict_values['type'] = skillset_interest_type_row.type
            type_dict_values['value'] = skillset_interest_type_row.value
            type_dict_values['is_other'] = skillset_interest_type_row.is_other
            interested_in.append(type_dict_values.copy())

        singing_in = []
        skillset_interest_type = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'singing_in').order_by(Talent_skillset_interests.id.asc()).all()
        for skillset_interest_type_row in skillset_interest_type:
            type_dict_values = {}
            type_dict_values['type'] = skillset_interest_type_row.type
            type_dict_values['value'] = skillset_interest_type_row.value
            type_dict_values['is_other'] = skillset_interest_type_row.is_other
            singing_in.append(type_dict_values.copy())

        dancing_in = []
        skillset_interest_type = self.db.query(Talent_skillset_interests).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'dancing_in').order_by(Talent_skillset_interests.id.asc()).all()
        for skillset_interest_type_row in skillset_interest_type:
            type_dict_values = {}
            type_dict_values['type'] = skillset_interest_type_row.type
            type_dict_values['value'] = skillset_interest_type_row.value
            type_dict_values['is_other'] = skillset_interest_type_row.is_other
            dancing_in.append(type_dict_values.copy())

        musical_in = []
        skillset_interest_type = self.db.query(Talent_skillset_interests.type,Talent_skillset_interests.value,Talent_skillset_interests.is_other).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'musical_in').order_by(Talent_skillset_interests.id.asc()).all()
        for skillset_interest_type_row in skillset_interest_type:
            type_dict_values = {}
            type_dict_values['type'] = skillset_interest_type_row.type
            type_dict_values['value'] = skillset_interest_type_row.value
            type_dict_values['is_other'] = skillset_interest_type_row.is_other
            musical_in.append(type_dict_values.copy())

        skills_in = []
        skillset_interest_type = self.db.query(Talent_skillset_interests.type,Talent_skillset_interests.value,Talent_skillset_interests.is_other).filter(Talent_skillset_interests.talent_id == talent_id).filter(Talent_skillset_interests.skill_type == 'skills_in').order_by(Talent_skillset_interests.id.asc()).all()
        for skillset_interest_type_row in skillset_interest_type:
            type_dict_values = {}
            type_dict_values['type'] = skillset_interest_type_row.type
            type_dict_values['value'] = skillset_interest_type_row.value
            type_dict_values['is_other'] = skillset_interest_type_row.is_other
            skills_in.append(type_dict_values.copy())
        ###### FETCH SKILLSET INTEREST

        ###### FETCH SKILLSET INTEREST ONSCREEN
        skillset_interests_onscreen = self.db.query(Talent_skillset_interest_onscreen.intimate_scenes,Talent_skillset_interest_onscreen.nude_scenes,Talent_skillset_interest_onscreen.kiss_scenes).filter((Talent_skillset_interest_onscreen.talent_id == talent_id)).first()
        interests_onscreen = {}
        if skillset_interests_onscreen:
            interests_onscreen = skillset_interests_onscreen

        appearance_skillset = {"experienced_in":experienced_in,"interested_in":interested_in,"singing_in":singing_in,"dancing_in":dancing_in,"musical_in":musical_in,"skills_in":skills_in, "skillset_interests_onscreen" : interests_onscreen}

        mysqlConnection.execute(f"SELECT code FROM talent_work_credits where talent_id='{talent_id}' group by code")
        work_credit = mysqlConnection.fetchall()
        mydb.commit()
        work_credit_selected = []
        for row_work_credit in work_credit:
            getName = self.db.query(Talent_work_credits).filter(Talent_work_credits.talent_id == talent_id).filter(Talent_work_credits.code == row_work_credit[0]).first()
            type_dict = {}
            type_dict['name'] = getName.production_type
            type_dict['code'] = row_work_credit[0]
            type_dict['value'] = []
            
            work_credit_type = self.db.query(Talent_work_credits).filter(Talent_work_credits.talent_id == talent_id).filter(Talent_work_credits.code == row_work_credit[0]).order_by(Talent_work_credits.id.asc()).all()
            for credit_type_row in work_credit_type:
                type_dict_values = {}
                type_dict_values['start_year_month'] = credit_type_row.start_year_month
                type_dict_values['end_year_month'] = credit_type_row.end_year_month
                type_dict_values['production_type'] = credit_type_row.production_type
                type_dict_values['production_name'] = credit_type_row.production_name
                type_dict_values['role'] = credit_type_row.role
                type_dict_values['production_house'] = credit_type_row.production_house
                type_dict['value'].append(type_dict_values)
            work_credit_selected.append(type_dict)

        check_profile_intro = self.db.query(Talent_profile_intro.additional_information,Talent_profile_intro.instagram,Talent_profile_intro.behance,Talent_profile_intro.IMDB).filter((Talent_profile_intro.talent_id == talent_id)).first()
        profile_intro = {}
        if check_profile_intro:
            profile_intro = check_profile_intro

        agent_representation = {}
        agent_representation_obj = self.db.query(Talent_agent_representation.have_agent).filter(Talent_agent_representation.talent_id == talent_id).first()
        if agent_representation_obj:
            agent_representation = agent_representation_obj

        portfolio = {}
        portfolio_obj = self.db.query(Talent_portfolio.photos, Talent_portfolio.videos, Talent_portfolio.audios, Talent_portfolio.awards).filter(Talent_portfolio.talent_id == talent_id).first()
        if portfolio_obj:
            portfolio = portfolio_obj

        talent_profile = { "id": talent_register.id, "first_name": talent_register.first_name, "last_name": talent_register.last_name, "email":talent_register.email, "display_name": talent_personal_info.display_name, "gender": talent_personal_info.gender, "profile_photo":talent_personal_info.avatar_url, "qr_code": talent_personal_info.qr_code, "location": location, "industry_location": industry_location, "language_skills": language_skills, "education": education, "physical_appearance_data": physical_appearance_data, "appearance_skillset": appearance_skillset,"work_credit_selected": work_credit_selected, "profile_intro": profile_intro, "agent_representation":agent_representation,"portfolio": portfolio}

        mongodbConn.talents.insert_one(talent_profile)
        # print('talent_profile==========>>>>>',talent_profile)
        ###     UPDATE IN MONGODB

        ProgressBar(self.db, talent_id, Request).saveLogPercentage()

        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
        return response

    def get_agent_representation(self, token):
        talent_id = token.id
        prof_comp_per = ProgressBar(self.db, talent_id, None).totalPercentage()
        userResponse={}
        agent_representation_obj = self.db.query(Talent_agent_representation).filter(Talent_agent_representation.talent_id == talent_id).first()
        if agent_representation_obj:
            userResponse = {"have_agent":agent_representation_obj.have_agent,"agency_name":agent_representation_obj.agency_name,"agent_email":agent_representation_obj.agent_email,"telephone":agent_representation_obj.telephone,"agent_website":agent_representation_obj.agent_website,"covering_industries":agent_representation_obj.covering_industries,"agent_alert_message":agent_representation_obj.agent_alert_message,"agent_looking_profile":agent_representation_obj.agent_looking_profile,"profile_percen":prof_comp_per}
        else:
            userResponse={"profile_percen":prof_comp_per}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess,"response": userResponse}
        return response

    def view_profile(self, enc_id):         #####################   CONVERT BY CONDITION
        base64_bytes = bytes(enc_id, encoding="raw_unicode_escape")
        talent_id = base64.b64decode(base64_bytes).decode("ascii")
        print('============>>>>>>>>>>>>>>>>>>>>>>>>>',talent_id)
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
        return response

class TkIdServices(AppService):
    def getTkId(self,token) -> ServiceResult:
        agent_representation = TkIdCRUD(self.db).get_tk_id(token)
        if not agent_representation:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(agent_representation)

    def updateSlug(self, Slug: Slug, token) -> ServiceResult:
        check_slug = TkIdCRUD(self.db).check_slug(Slug,token)
        if check_slug:
            message="Slug already exists"
            return ServiceResult(AppException.CreateValidation(message))
        else:
            agent_representation = TkIdCRUD(self.db).update_slug(Slug,token)
            if not agent_representation:
                return ServiceResult(AppException.GetValidation("Record not exists"))
            return ServiceResult(agent_representation)

class TkIdCRUD(AppCRUD):
    def get_tk_id(self, token):
        talent_id = token.id
        prof_comp_per = ProgressBar(self.db, talent_id, None).totalPercentage()
        talent_personal_info = self.db.query(Talent_personal_info).filter(Talent_personal_info.talent_id == talent_id).first()
        if talent_personal_info:
            result = {"slug":talent_personal_info.slug,"display_name":talent_personal_info.display_name,"tk_id":talent_personal_info.tk_id,"url_link":talent_personal_info.url_link,"profile_percen":prof_comp_per}
        else:
            result = {"profile_percen":prof_comp_per}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response": result}
        return response

    def update_slug(self, Slug:Slug, token):
        talent_id = token.id
        talent_personal_info = self.db.query(Talent_personal_info).filter(Talent_personal_info.talent_id == talent_id).first()
        if talent_personal_info:
            slug=''.join(e for e in Slug.slug if e.isalnum())
            talent_personal_info.slug = slug
            self.db.add(talent_personal_info)
            self.db.commit()
            self.db.refresh(talent_personal_info)
            response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
            return response

    def check_slug(self, Slug:Slug, token):
        talent_id = token.id
        talent_personal_info = self.db.query(Talent_personal_info).filter(Talent_personal_info.talent_id == talent_id).first()
        if talent_personal_info:
            slug=''.join(e for e in Slug.slug if e.isalnum())
            check_slug = self.db.query(Talent_personal_info).filter(Talent_personal_info.slug == slug).filter(Talent_personal_info.talent_id != talent_id).first()
            if check_slug:
                return check_slug

class ProgressBar():
    def __init__(self, db, talent_id, Request):
        self.apiDefName = None
        if Request:
            self.apiDefName = Request.url
        self.talent_id = talent_id
        self.db = db

    def saveLogPercentage(self):
        if self.apiDefName is not None:
            url = str(self.apiDefName)
            parsed_url = urlparse(url)
            captured_value = str(parsed_url.path).split('/')
            save_def_name = captured_value[3]
            talent_id = self.talent_id
            checkDefInCompTabs = self.db.query(Profile_completion_tabs).filter(Profile_completion_tabs.save_def_name == save_def_name).first()
            print('checkDefInCompTabs============',checkDefInCompTabs)
            if checkDefInCompTabs:
                checkThisDefComplted = self.db.query(Talent_profile_completion_logs).filter(Talent_profile_completion_logs.talent_id == talent_id).filter(Talent_profile_completion_logs.save_def_name == save_def_name).filter(Talent_profile_completion_logs.is_completed == 1).first()
                if not checkThisDefComplted:
                    checkThisDefComplted = Talent_profile_completion_logs(talent_id=talent_id,title=save_def_name,save_def_name=checkDefInCompTabs.save_def_name,percentage=checkDefInCompTabs.completion_perc,is_completed=1,created_at = dateTime_at)
                    self.db.add(checkThisDefComplted)
                    self.db.commit()
                    self.db.refresh(checkThisDefComplted) 

        return (self.apiDefName)

    def totalPercentage(self):
        talent_id = self.talent_id
        
        qry = self.db.query(func.sum(Talent_profile_completion_logs.percentage).label("tal_per")).filter(Talent_profile_completion_logs.talent_id == talent_id).first()

        self.db.commit()
        total_percentage = 0
        if qry.tal_per is not None:
            total_percentage = qry.tal_per
        return total_percentage