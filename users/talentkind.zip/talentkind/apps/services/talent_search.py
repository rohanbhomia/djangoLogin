from apps.schemas.talent_search import QuickSearch
from ..schemas.talent_search import *
from ..utils.app_exceptions import AppException
from ..services.main import AppService, AppCRUD
from ..models.talent_search import *
from ..models.talent_profile import *
from ..utils.service_result import ServiceResult
from ..config.dependencies import JWT_SECRET, dateTime_at, os, mongodb
import json
from sqlalchemy import or_, and_

mongodbConn = mongodb()


statusCodeSuccess = int(os.getenv('STATUS_200'))
statusMessageSuccess = os.getenv('MESSAGE_200')
statusCodeFailure = int(os.getenv('STATUS_409'))
statusMessageFailed = os.getenv('MESSAGE_409')


class TalenSearch(AppService):
    def quick_search(self, item: QuickSearch, token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._quick_search(item, token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)

    def quick_search_by_id(self, id, token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._quick_search_by_id(id, token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)

    def save_search(self, item: QuickSearch, token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._save_search(item, token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)

    def get_all_search(self, token, id) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._get_all_search(token, id)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)

    def update_search(self, item: QuickSearch, token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._update_search(item, token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)

    def delete_search(self, item: DeleteSearch, token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._delete_search(item, token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)

    def get_all_keywords(self, token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._get_all_keywords(token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)


class SettingsCrud(AppCRUD):

    def input_schema(self, item):
        mydict = {}
        if item.job_type is not None and len(item.job_type) != 0:
            mydict['job_type'] = {"$in": item.job_type}
        if item.category_name is not None and len(item.category_name) != 0:
            mydict['category_name'] = {"$in": item.category_name}
        if item.role is not None and len(item.role) != 0:
            mydict['role'] = {"$in": item.role}
        if item.location is not None and len(item.location) != 0:
            mydict['location'] = {"$in": item.location}
        if item.experience is not None and len(item.experience) != 0:
            mydict['experience'] = {"$in": item.experience}
        if item.pay_range is not None and len(item.pay_range) != 0:
            mydict['pay_range'] = {"$in": item.pay_range}
        if item.essential_skills is not None and len(item.essential_skills) != 0:
            mydict['essential_skills'] = {"$in": item.essential_skills}

        return mydict

    def _quick_search(self, item: QuickSearch, token) -> Talent_search:
        talent_id = token.id
        result = []

        mydict = self.input_schema(item)

        self.db.query(Talent_search).filter(
            Talent_search.search_name == 'quicksearch').delete()
        self.db.commit()

        # print("myquery--", mydict)

        # mydoc = mongodbConn['jobs'].find(mydict)

        # for data in mydoc:
        #     new_dict = data
        #     del new_dict['_id']
        #     result.append(new_dict)

        talent_search = Talent_search(
            talent_id=talent_id,
            search_name="quicksearch",
            search_value=json.dumps(mydict),
            created_on=dateTime_at
        )
        self.db.add(talent_search)
        self.db.commit()
        self.db.refresh(talent_search)

        search_id = talent_search.id

        talent_search = {"status": statusCodeSuccess,
                         "message": statusMessageSuccess, 'response': {'id': search_id}}
        return talent_search

    def _quick_search_by_id(self, id, token) -> Talent_search:
        talent_id = token.id
        mydict = {}
        new_result = []

        if id is not None:

            result = self.db.query(Talent_search).filter(
                and_(Talent_search.talent_id == talent_id, Talent_search.id == id)).first()

            if result is not None:

                mydict = json.loads(result.search_value)

                print("myquery--", mydict)

                mydoc = mongodbConn['jobs'].find(mydict)

                for data in mydoc:
                    new_dict = data
                    del new_dict['_id']
                    new_result.append(new_dict)

                talent_search = {"status": statusCodeSuccess,
                                 "message": statusMessageSuccess, 'response': new_result}
                return talent_search
            else:
                talent_search = {"status": statusCodeFailure,
                                 "message": "Id does not match."}
                return talent_search
        else:
            talent_search = {"status": statusCodeFailure,
                             "message": "Id is required."}
            return talent_search

    def _save_search(self, item: QuickSearch, token) -> Talent_search:
        talent_id = token.id
        mydict = {}

        if item.search_name is None:
            talent_search = {"status": statusCodeFailure,
                             "message": "Name is required"}
            return talent_search
        else:
            mydict = self.input_schema(item)

            talent_search = Talent_search(
                talent_id=talent_id,
                search_name=item.search_name,
                search_value=json.dumps(mydict),
                created_on=dateTime_at
            )
            self.db.add(talent_search)
            self.db.commit()
            self.db.refresh(talent_search)

            talent_search = {"status": statusCodeSuccess,
                             "message": 'Created successfully'}
            return talent_search

    def _get_all_search(self, token, id) -> Talent_search:
        talent_id = token.id

        mylist = []
        if id is None:
            result = self.db.query(Talent_search).filter(
                Talent_search.talent_id == talent_id, Talent_search.search_name != 'quicksearch').all()
            if result is not None:
                for data in result:
                    mydict = {}
                    mydict['id'] = data.id
                    mydict['talent_id'] = data.talent_id
                    mydict['search_name'] = data.search_name
                    mydict['created_on'] = data.created_on
                    mydict['search_value'] = json.loads(data.search_value)
                    mylist.append(mydict)

                    print("mydict------", mydict)
                    print("mydict------", data.search_value)

                talent_search = {"status": statusCodeSuccess,
                                 "message": statusMessageSuccess, 'response': mylist}
                return talent_search

        else:
            result = self.db.query(Talent_search).filter(
                and_(Talent_search.talent_id == talent_id, Talent_search.id == id)).first()
            if result is not None:
                mydict = {}
                mydict['id'] = result.id
                mydict['talent_id'] = result.talent_id
                mydict['search_name'] = result.search_name
                mydict['created_on'] = result.created_on
                mydict['search_value'] = json.loads(result.search_value)
                mylist.append(mydict)

                talent_search = {"status": statusCodeSuccess,
                                 "message": statusMessageSuccess, 'response': mylist}
                return talent_search
            else:
                talent_search = {"status": statusCodeFailure,
                                 "message": "Id does not match."}
                return talent_search

    def _update_search(self, item: QuickSearch, token) -> Talent_search:
        talent_id = token.id

        mydict = {}

        if item.id is not None:

            mydict = self.input_schema(item)

            result = self.db.query(Talent_search).filter(
                and_(Talent_search.talent_id == talent_id, Talent_search.id == item.id)).first()

            if result is not None:
                result.search_name = item.search_name
                result.search_value = json.dumps(mydict)
                result.created_on = dateTime_at

                self.db.add(result)
                self.db.commit()
                self.db.refresh(result)

                talent_search = {"status": statusCodeSuccess,
                                 "message": 'Updated successfully'}
                return talent_search
            else:
                talent_search = {"status": statusCodeFailure,
                                 "message": "Id does not match."}
                return talent_search
        else:
            talent_search = {"status": statusCodeFailure,
                             "message": "Id is required."}
            return talent_search

    def _delete_search(self, item: DeleteSearch, token) -> Talent_search:
        talent_id = token.id

        result = self.db.query(Talent_search).filter(
            and_(Talent_search.talent_id == talent_id, Talent_search.id == item.id)).first()
        if result is not None:
            self.db.query(Talent_search).filter(
                and_(Talent_search.talent_id == talent_id, Talent_search.id == item.id)).delete()
            self.db.commit()
            talent_search = {"status": statusCodeSuccess,
                             "message": 'Deleted successfully'}
            return talent_search
        else:

            talent_search = {"status": statusCodeFailure,
                             "message": "Id does not match."}
            return talent_search

    def _get_all_keywords(self, token) -> Talent_search:
        talent_id = token.id

        category_name = [{'option': data.display_name} for data in self.db.query(Talent_industry).filter(
            Talent_industry.talent_id == talent_id).all()]

        role = [{'option': data.name} for data in self.db.query(Talent_industry_location).filter(
            Talent_industry_location.talent_id == talent_id).all()]

        location = [{'option': data.industry_name} for data in self.db.query(Talent_industry_profession).filter(
            Talent_industry_profession.talent_id == talent_id).all()]

        talent_search = {"status": statusCodeSuccess,
                         "message": statusMessageSuccess, 'response': {"category_name": category_name, "role": role, "location": location}}
        return talent_search
