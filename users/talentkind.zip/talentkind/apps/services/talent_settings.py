from ..schemas.talent_settings import *
from ..schemas.talent_login import _Talent_registerBase
from ..utils.app_exceptions import AppException
from ..services.main import AppService, AppCRUD
from ..models.talent_settings import *
from ..models.talent_login import Talent_register
from ..utils.service_result import ServiceResult
from ..config.dependencies import JWT_SECRET, dateTime_at, os
from time import sleep
import passlib.hash as _hash
import json


statusCodeSuccess = int(os.getenv('STATUS_200'))
statusMessageSuccess = os.getenv('MESSAGE_200')
statusCodeFailure = int(os.getenv('STATUS_409'))
statusMessageFailed = os.getenv('MESSAGE_409')


class TalentSettings(AppService):
    def delete_account(self, item: DeleteAccountSchema, token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._delete_account(item, token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)

    def change_status(self, item: ChangeStatusSchema, token) -> ServiceResult:
        settings_item = SettingsCrud(self.db)._change_status(item, token)
        if not settings_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(settings_item)

    def add_notification(self, item: TalentNotificationSchema, token) -> ServiceResult:
        notification_item = SettingsCrud(
            self.db)._create_notification(item, token)
        if not notification_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(notification_item)

    def get_notification(self, token) -> ServiceResult:
        notification_item = SettingsCrud(self.db)._get_notification(token)
        if not notification_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(notification_item)

    def update_account(self, item: _Talent_registerBase, token) -> ServiceResult:
        talent_result = SettingsCrud(self.db)._update_account(item, token)
        if not talent_result:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(talent_result)

    def change_password(self, item: ChangePassword, token) -> ServiceResult:
        talent_result = SettingsCrud(self.db)._change_password(item, token)
        if not talent_result:
            return ServiceResult(AppException.CreateValidation('Old password does not match'))
        return ServiceResult(talent_result)

    def talent_profile_visibility(self, item: TalentProfileVisibility, token) -> ServiceResult:
        talent_result = SettingsCrud(
            self.db)._talent_profile_visibility(item, token)
        if not talent_result:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(talent_result)

    def get_talent_profile_visibility(self, token) -> ServiceResult:
        talent_id = token.id
        profile_result = SettingsCrud(
            self.db)._get_talent_profile_visibility(talent_id)
        if not profile_result:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(profile_result)

    def get_account(self, token) -> ServiceResult:
        talent_id = token.id
        profile_result = SettingsCrud(self.db)._get_account(talent_id, token)
        if not profile_result:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(profile_result)


class SettingsCrud(AppCRUD):
    def _delete_account(self, item: DeleteAccountSchema, token) -> Talent_register:
        talent_id = token.id
        talent_settings = self.db.query(Talent_register).filter(
            Talent_register.id == talent_id).first()
        if not talent_settings:
            return False
        else:
            talent_settings.is_delete = item.is_delete
            self.db.add(talent_settings)
            self.db.commit()
            self.db.refresh(talent_settings)
            talent_settings = {"status": statusCodeSuccess,
                               "message": 'Updated successfully'}
            return talent_settings

    def _change_status(self, item: ChangeStatusSchema, token) -> ServiceResult:
        # logic for talent_id is it exist or not
        talent_id = token.id
        talent_settings = self.db.query(Talent_register).filter(
            (Talent_register.id == talent_id)).first()
        if not talent_settings:
            return False
        else:
            talent_settings.is_active = item.is_active
            self.db.add(talent_settings)
            self.db.commit()
            self.db.refresh(talent_settings)
            talent_settings = {"status": statusCodeSuccess,
                               "message": 'Updated successfully'}
            return talent_settings

    def _create_notification(self, item: TalentNotificationSchema, token) -> Talent_settings:
        token_id = token.id
        notification_info = self.db.query(Talent_settings).filter(
            (Talent_settings.talent_id == token_id)).first()
        notification = {}
        if notification_info:
            notification.update(item)
            notification_info.notifications = json.dumps(notification)
            notification_info.created_on = dateTime_at
            notification_info.updated_on = dateTime_at
            self.db.add(notification_info)
            self.db.commit()
            self.db.refresh(notification_info)
        else:
            notification.update(item)
            notification_info = Talent_settings(notifications=json.dumps(
                notification), talent_id=token_id, created_on=dateTime_at, updated_on=dateTime_at)
            self.db.add(notification_info)
            self.db.commit()
            self.db.refresh(notification_info)
        response = {"status": statusCodeSuccess,
                    "message": 'Updated successfully'}
        return response

    def _get_notification(self, token) -> Talent_settings:
        talent_id = token.id
        get_talent_notification = self.db.query(Talent_settings).filter(
            Talent_settings.talent_id == talent_id).first()
        if not get_talent_notification:
            notifications = {"notifications": ''}
        else:
            notifications = {"notifications": json.loads(
                get_talent_notification.notifications)}
        response = {"status": statusCodeSuccess,
                    "message": 'success', "response": notifications}
        return response

    def _update_account(self, item: _Talent_registerBase, token) -> Talent_register:
        # check talent id does exists or not
        talent_id = token.id
        # check duplication is not equal to
        talent_result = self.db.query(Talent_register).filter(Talent_register.id != talent_id).filter(
            (Talent_register.email == item.email) | (Talent_register.mobile_number == item.mobile_number)).first()
        if talent_result:
            return False
        else:
            talent_result = self.db.query(Talent_register).filter(
                Talent_register.id == talent_id).first()

            talent_result.first_name = item.first_name
            talent_result.last_name = item.last_name
            talent_result.email = item.email
            talent_result.mobile_number = item.mobile_number
            self.db.add(talent_result)
            self.db.commit()
            self.db.refresh(talent_result)

            response = {"status": statusCodeSuccess,
                        "message": 'Updated successfully'}

            return response

    def _change_password(self, item: ChangePassword, token) -> Talent_register:
       # check talent id does exists or not
        talent_id = token.id
        password = item.old_password
        new_password = item.new_password
        confirm_password = item.confirm_password
        # compare password with database password
        talent_login = self.db.query(Talent_register).filter(
            Talent_register.id == talent_id).first()
        if not talent_login.verify_password(password):
            return None
        else:
            if new_password == confirm_password:
                talent_login.password = _hash.bcrypt.hash(new_password)
                self.db.add(talent_login)
                self.db.commit()
                self.db.refresh(talent_login)
                response = {"status": statusCodeSuccess,
                            "message": "Password updated successfully"}
                return response
            else:
                # message for new and confirm password does not match
                response = {"status": statusCodeFailure,
                            "message": 'New password and confirm password does not match'}
                return response

    def _talent_profile_visibility(self, item: TalentProfileVisibility, token) -> Talent_settings:
        talent_id = token.id

        result = self.db.query(Talent_settings).filter(
            Talent_settings.talent_id == talent_id).first()
        if result:
            result.profile_visibility = json.dumps(dict(item))
            result.created_on = dateTime_at
            result.updated_on = dateTime_at
            self.db.add(result)
            self.db.commit()
            self.db.refresh(result)
        else:
            talent_setting = Talent_settings(
                profile_visibility=json.dumps(dict(item)),
                created_on=dateTime_at,
                updated_on=dateTime_at,
                talent_id=talent_id)
            self.db.add(talent_setting)
            self.db.commit()
            self.db.refresh(talent_setting)
        response = {"status": statusCodeSuccess,
                    "message": 'Updated successfully'}
        return response

    def _get_account(self, talent_id: int, token) -> Talent_register:
        talent_id = token.id
        talent_result = self.db.query(Talent_register).filter(
            Talent_register.id == talent_id).first()
        if not talent_result:
            return False
        else:
            userResponse = {"first_name": talent_result.first_name, "last_name": talent_result.last_name, "email": talent_result.email,
                            "mobile_number": talent_result.mobile_number, "is_active": talent_result.is_active, "is_delete": talent_result.is_delete}
            response = {"status": statusCodeSuccess,
                        "message": 'success', "user": userResponse}
            return response

    def _get_talent_profile_visibility(self, talent_id: int) -> Talent_settings:
        talent_result = self.db.query(Talent_settings).filter(
            Talent_settings.talent_id == talent_id).first()
        details = {"profile_visibility": json.loads(
            talent_result.profile_visibility)}
        response = {"status": statusCodeSuccess,
                    "message": 'success', "response": details}
        return response

        # if not talent_result:
        #     return False
        # else:
        #     if talent_result.profile_visibility is not None:
        #         details = {"profile_visibility": json.loads(talent_result.profile_visibility)}
        #         response = {"status" : statusCodeSuccess, "message" : 'success', "response": details }
        #         return response
        #     else:
        #         return False
