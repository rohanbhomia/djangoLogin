from ..schemas.talent_calendar import *
from ..utils.app_exceptions import AppException
from ..services.main import AppService, AppCRUD
from ..models.talent_calendar import *
from ..utils.service_result import ServiceResult
from fastapi import BackgroundTasks
from ..lib_packages.send_mail import send_email
from ..config.dependencies import JWT_SECRET,dateTime_at,conf,MessageSchema,FastMail,os
from time import sleep
from ..config.database import get_db, mysqlConnection, mydb
import base64
import random
# import jwt
import datetime
from ..models.talent_login import Talent_register


statusCodeSuccess = int(os.getenv('STATUS_200'))
statusMessageSuccess = os.getenv('MESSAGE_200')
statusCodeFailure = int(os.getenv('STATUS_409'))
statusMessageFailed = os.getenv('MESSAGE_409')


class EventService(AppService):
    def create_event_appointment(self, item: EventSchemaBaseAppointment, token) -> ServiceResult:       
        event_item = EventCRUD(self.db).create_appointment(item,token)        
        if not event_item:
            return ServiceResult(AppException.CheckRecordException())
        return ServiceResult(event_item)

    def update_event_appointment(self, item: EventSchemaCreateAppointment,token) -> ServiceResult:
        event_item = EventCRUD(self.db).update_appointment(item,token)
        if not event_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(event_item)

    def create_event_work_engagement(self, item: EventSchemaBaseWorkEngagement, token) -> ServiceResult:  
        event_item = EventCRUD(self.db).create_work_engagement(item,token)        
        if not event_item:
            return ServiceResult(AppException.CheckRecordException())
        return ServiceResult(event_item)
           
    def update_event_work_engagement(self, item: EventSchemaCreateWorkEengagement,token) -> ServiceResult:
        event_item = EventCRUD(self.db).update_work_engagement(item,token)
        if not event_item:
            return ServiceResult(AppException.CreateValidation())
        return ServiceResult(event_item)    

    def get_event(self, event_id: int) -> ServiceResult:
        event_item = EventCRUD(self.db).get_event(event_id)        
        if not event_item:
            return ServiceResult(AppException.GetValidation())        
        return ServiceResult(event_item)

    def get_all_event(self, item:AllEventSchema, token) -> ServiceResult:
        event_item = EventCRUD(self.db).get_all_event_item(item,token)
        if not event_item:
            return ServiceResult(AppException.GetValidation())        
        return ServiceResult(event_item)   

class EventCRUD(AppCRUD):
    def create_appointment(self, item: EventSchemaBaseAppointment,token) -> Talent_events:        
        talent_id = token.id

        result = self.db.query(Talent_register).filter((Talent_register.id == talent_id)).first()
        if result is None:
            return False
        else:
            start_datetime=str(item.appointment_date)+' '+str(item.start)
            end_datetime=str(item.appointment_date)+' '+str(item.end)

            print("start_datetime=====>", start_datetime)
            print("end_datetime=====>", end_datetime)

            event_item = Talent_events(title=item.title,backgroundColor='blue',event_type=item.event_type,salutation=item.salutation, description=item.description,appointment_date=item.appointment_date,start=start_datetime,end=end_datetime,talent_id=talent_id,created_on=dateTime_at,updated_on=dateTime_at)            
            self.db.add(event_item)
            self.db.commit()
            self.db.refresh(event_item)
          
            response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}           
            return response

    def update_appointment(self, item: EventSchemaCreateAppointment,token) -> Talent_events:
        talent_id =token.id      
        event_item = self.db.query(Talent_events).filter(Talent_events.talent_id == talent_id,Talent_events.id == item.id).first() 
        if event_item is None:
            return False
        else:  
            start_datetime=str(item.appointment_date)+' '+str(item.start)
            end_datetime=str(item.appointment_date)+' '+str(item.end)
            
            event_item.title = item.title
            event_item.salutation = item.salutation
            event_item.backgroundColor='blue'
            event_item.event_type = item.event_type
            event_item.description = item.description
            event_item.start = start_datetime
            event_item.end = end_datetime
            event_item.appointment_date = item.appointment_date        
            event_item.created_on = dateTime_at
            event_item.updated_on = dateTime_at       
            self.db.commit() 
            self.db.refresh(event_item)      
            response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}            
            return response        

    def create_work_engagement(self, item: EventSchemaBaseWorkEngagement,token) -> Talent_events:        
        talent_id = token.id
        result = self.db.query(Talent_register).filter((Talent_register.id == talent_id)).first()
        if result is None:
            return False
        else:
            start_datetime=str(item.start_date)+' '+str('00:00:00')
            end_datetime=str(item.end_date)+' '+str('23:59:00')
            event_item = Talent_events(title=item.title,event_type=item.event_type,description=item.description, start=start_datetime,end=end_datetime,talent_id=talent_id,created_on=dateTime_at,updated_on=dateTime_at,backgroundColor='pink')            
            self.db.add(event_item)
            self.db.commit()
            self.db.refresh(event_item)          
            response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}           
            return response  

    def update_work_engagement(self, item: EventSchemaCreateWorkEengagement,token) -> Talent_events:
        talent_id =token.id        
        event_item = self.db.query(Talent_events).filter(Talent_events.talent_id == talent_id,Talent_events.id == item.id).first() 
        if event_item is None:
            return False
        else:  
            start_datetime=str(item.start_date)+' '+str('00:00:00')

            end_datetime=str(item.end_date)+' '+str('23:59:00')
            event_item.title = item.title 
            event_item.backgroundColor='pink'           
            event_item.event_type = item.event_type
            event_item.description = item.description
            event_item.start = start_datetime
            event_item.end = end_datetime                  
            event_item.created_on = dateTime_at
            event_item.updated_on = dateTime_at       
            self.db.commit()     
            self.db.refresh(event_item)  
            response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}            
            return response                      

    def get_event(self, event_id: int) -> Talent_events:       
        event_item = self.db.query(Talent_events).filter(Talent_events.id == event_id).first()
        internalResponse = {"event":event_item}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : internalResponse }
        return response

    def get_all_event_item(self,item:AllEventSchema,token,) -> Talent_events:       
        talent_id =token.id
        
        event_item = self.db.query(Talent_events).filter(Talent_events.talent_id == talent_id).all()    

        internalResponse = {"events":event_item}
        response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : internalResponse }
        return response

    

    

  







        









