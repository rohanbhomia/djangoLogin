from ..schemas.talent_profile import *
from ..schemas.talent_login import TalentUsername
from ..schemas.employer_job_posting import CreateJob
from ..utils.app_exceptions import AppException
from ..services.main import AppService, AppCRUD
from ..models.talent_login import Talent_register
from ..models.employer_login import Employer_register
from ..models.talent_portfolio import Talent_portfolio
from ..models.talent_profile import *
from ..utils.service_result import ServiceResult
from fastapi import Depends,BackgroundTasks, Request
from ..config.dependencies import oauth2schema, JWT_SECRET, dateTime_at, mongodb, os, FOLDER_NAME
from ..config.database import get_db, mysqlConnection, mydb
from mimetypes import guess_extension, guess_type
from bson import json_util

import fastapi 
import jwt
import json
import datetime
import os
import base64
import random

from urllib.parse import urlparse   ### NEW ADDED BY KAMLESH
from sqlalchemy.sql import func   ### NEW ADDED BY KAMLESH

from ..media_packages import media_upload

########  MONGODB CONN
mongodbConn = mongodb()

statusCodeSuccess = int(os.getenv('STATUS_200'))
statusMessageSuccess = os.getenv('MESSAGE_200')
statusCodeFailure = int(os.getenv('STATUS_409'))
statusMessageFailed = os.getenv('MESSAGE_409')

#FOR QR CODE
import pyqrcode
import png
from pyqrcode import QRCode

async def get_employer_current_user(
    db: get_db = Depends(),
    token: str = fastapi.Depends(oauth2schema),
):
    
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        talent = db.query(Employer_register).get(payload["id"])
    except:
        raise fastapi.HTTPException(
            status_code=409, detail="Invalid Email or Password"
        )

    return talent
    # if talent:
    #     return EmployerCreate.from_orm(talent)
    # else:
    #     raise fastapi.HTTPException(
    #         status_code=409, detail="Invalid Email or Password"
    #     )