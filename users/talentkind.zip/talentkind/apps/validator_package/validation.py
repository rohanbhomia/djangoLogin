import re
from datetime import date, datetime, time
from ..validator_package import validations_errors

def email_validation(email,error_message="Invalid"):
	if email == '':
		raise ValueError(error_message)
	else:
		pattern = r"^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$"
		pat = re.compile(pattern)
		print("che ",re.fullmatch(pat, email))
		check = re.fullmatch(pat, email)
		if check is None:
			raise ValueError(validations_errors.INVALID_EMAIL_FORMAT)
	return email 

def name_validation(name,error_message="Invalid"):
	if name == '':
		raise ValueError(error_message)
	else:
		pattern=r"^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$"
		# above pattern is allowing Alphabets, Dots, Spaces
		pat = re.compile(pattern)
		print("che ",re.fullmatch(pat,name))
		check = re.fullmatch(pat,name)
		if check is None:
			raise ValueError(validations_errors.INVALID_NAME_FORMAT)
	return name.title()

# def match_password(password,confirm_password):
# 	if password!=confirm_password:
# 		raise ValueError(validations_errors.MATCH_PASSWORD_ERROR)
# 	return password

def check_integer_format(integerValue):
	if integerValue == '':
		raise ValueError('Field is required')
	elif str(integerValue).isdigit() is False:
		raise ValueError("Invalid value")
	return integerValue
	

def checkInvalid(etype, fieldsArray, emsg):
	print("field is len", len(fieldsArray))
	message=''
	if etype == "value_error.missing":
		error_message = fieldsArray[0].title().replace("_", " ") + ' field is missing'
		message= error_message
	elif etype == "type_error.integer":
		error_message = fieldsArray[0].title() + "  is not valid value"
		message= error_message
	elif len(fieldsArray) == 0:
		message='invalid request'
	elif len(fieldsArray) == 1:
		 message= emsg
	else:
		field_root = fieldsArray[0]
		del(fieldsArray[0])
		message= emsg
	return message

def mobile_validation(mobile):
	if len(str(mobile)) > 10 or len(str(mobile)) < 10:
		raise ValueError(validations_errors.MOBILE_LIMIT_ERROR)
	if int(str(mobile)[:1]) < 6:
		raise ValueError(validations_errors.MOBILE_VALID_ERROR)
	return mobile

def website_validation(website):
	if website == '':
		raise ValueError('Website name is required')
	else:
		pattern=r"^((https?|ftp|smtp):\/\/)?(www.)?[a-z0-9]+\.[a-z]+(\/[a-zA-Z0-9#]+\/?)*$"
		# above pattern is allowing Alphabets, Dots, Spaces
		pat = re.compile(pattern)
		print("che ",re.fullmatch(pat,website))
		check = re.fullmatch(pat,website)
		if check is None:
			raise ValueError('Please enter valid  website name')
	return 'https://'+website


def dob_validation(dob):
	today = date.today()
	cdate = today.strftime("%Y-%m-%d")
	
	if dob == '':
		raise ValueError('Date of birth is required')
	else:
		pattern=r"^(19|20)\d\d([- /.])(0[1-9]|1[012])\2(0[1-9]|[12][0-9]|3[01])$"
		pat = re.compile(pattern)
		print("che ",re.fullmatch(pat,dob))
		check = re.fullmatch(pat,dob)
		if check is None:
			raise ValueError('Please enter valid date of birth ex:YYYY-MM-DD')
		elif dob > cdate:
			raise ValueError("date of birth cannot be  future date")
	return dob
 

def check_date_format(date_text):
	if date_text == '':
		raise ValueError('Date is missing')
	else:
		pattern=r"([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))"
		# above pattern is allowing Alphabets, Dots, Spaces
		pat = re.compile(pattern)
		print("che ",re.fullmatch(pat,date_text))
		check = re.fullmatch(pat,date_text)
		if check is None:
			raise ValueError('Please enter valid date')
	return date_text

def check_blank_validation(field,message):
	if field == '':
		raise ValueError(message)
	return field

def required_validation(password,msg="Invalid"):
	if password == '':
		raise ValueError(msg)
	return password