from sqlalchemy import Boolean, Column, Integer, String, DateTime, Date, Time
from ..config.database import Base


class Talent_events(Base):
    __tablename__ = "talent_events"
    id = Column(Integer, primary_key=True, index=True)
    salutation = Column(String(100))
    event_type = Column(String(100))
    start = Column(DateTime)
    end = Column(DateTime)
    appointment_date = Column(Date)
    talent_id = Column(Integer)
    title = Column(String(100))
    backgroundColor = Column(String(100))
    description = Column(String(100))
    created_on = Column(DateTime)
    updated_on = Column(DateTime)
