from sqlalchemy import Column, Integer, String, Text, DateTime,Boolean
from ..config.database import Base
import passlib.hash as _hash

class Temp_employer_register(Base):
	__tablename__ = "temp_employer_register"

	id = Column(Integer, primary_key=True, index=True)
	first_name = Column(String(30))
	middle_name = Column(String(30))
	last_name = Column(String(30))
	mobile_number = Column(Integer, unique=True)
	email = Column(String(30), unique=True)
	password = Column(Text)
	source = Column(String(50))
	salt = Column(String(255))
	status_code = Column(String(20))
	otp = Column(Integer)
	created_on = Column(DateTime)
	updated_on = Column(DateTime)
	
	def verify_password(self, password: str):
		return _hash.bcrypt.verify(password, self.password)

class Employer_register(Base):
	__tablename__ = "employer_register"

	id = Column(Integer, primary_key=True, index=True)
	first_name = Column(String(30))
	middle_name = Column(String(30))
	last_name = Column(String(30))
	s3_bucket = Column(String(30))
	mobile_number = Column(Integer, unique=True)
	email = Column(String(30), unique=True)
	password = Column(Text)
	source = Column(String(50))
	salt = Column(String(255))
	status_code = Column(String(20))
	is_delete = Column(Boolean)
	is_active = Column(Boolean)
	created_on = Column(DateTime)
	updated_on = Column(DateTime)

	def verify_password(self, password: str):
		return _hash.bcrypt.verify(password, self.password)

class Employer_otp_log(Base):
	__tablename__ = "employer_otp_log"

	id = Column(Integer, primary_key=True, index=True)
	employer_id = Column(Integer)
	code = Column(Integer)
	used_on = Column(String(20))
	request = Column(Text)

# class Mail_bodies(Base):
# 	__tablename__ = "mail_bodies"

# 	id = Column(Integer, primary_key=True, index=True)
# 	type = Column(String(100))
# 	subject = Column(String(200))
# 	body = Column(Text)
# 	created_at = Column(DateTime)
# 	updated_at = Column(DateTime)



	