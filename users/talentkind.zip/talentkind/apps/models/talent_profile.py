from sqlalchemy import Column, Integer, String, Text, DateTime, Date
from ..config.database import Base

class Talent_personal_info(Base):
	__tablename__ = "talent_personal_info"
	talent_id = Column(Integer, primary_key=True)
	slug = Column(String(20))
	display_name = Column(String(50))
	tk_id = Column(String(100))
	url_link = Column(String(250))
	gender = Column(String(20))
	nationality = Column(String(30))
	state = Column(String(30))
	city = Column(String(30))
	pincode = Column(Integer)
	have_passport = Column(Integer)
	have_travelled_abroad = Column(Integer)
	qr_code = Column(String(255),nullable=True)
	avatar_url = Column(String(200))
	date_of_birth = Column(Date)
	created_on = Column(DateTime)
	updated_on = Column(DateTime)

class Talent_industry(Base):
	__tablename__ = "talent_industry"

	id = Column(Integer, primary_key=True)
	talent_id = Column(Integer, index=True)
	industry_code = Column(String(20))
	display_name = Column(String(100))
	is_primary = Column(Integer)
	created_on = Column(DateTime)
	updated_on = Column(DateTime)

class Talent_industry_profession(Base):
	__tablename__ = "talent_industry_profession"

	id = Column(Integer, primary_key=True)
	talent_id = Column(Integer, index=True)
	talent_industry_id = Column(Integer, index=True)
	industry_name = Column(String(20))
	industry_code = Column(String(20))
	department_name = Column(String(50))
	department_code = Column(String(20))
	profession_code = Column(String(200))
	profession_name = Column(String(200))
	experience_level_type = Column(String(100))
	is_other = Column(Integer,default=0)
	created_on = Column(DateTime)
	updated_on = Column(DateTime)

class Talent_industry_profession_other(Base):
	__tablename__ = "talent_industry_profession_other"

	id = Column(Integer, primary_key=True)
	talent_id = Column(Integer, index=True)
	talent_industry_professionId = Column(String(100))
	position_type = Column(String(100))
	created_on = Column(DateTime)
	updated_on = Column(DateTime)


class Talent_onscreen_talent(Base):
	__tablename__ = "talent_onscreen_talent"

	id = Column(Integer, primary_key=True)
	talent_id = Column(Integer, index=True)
	profession_name = Column(String(50))
	profession_code = Column(String(20))
	profession_category_code = Column(String(20))
	profession_category_name = Column(String(50))
	created_on = Column(DateTime)
	updated_on = Column(DateTime)

class Talent_language_skills(Base):
	__tablename__ = "talent_language_skills"

	id = Column(Integer, primary_key=True)
	talent_id = Column(Integer, index=True)
	name = Column(String(50))
	value = Column(String(20))
	speak = Column(String(20))
	is_read = Column(Integer,default=0)
	is_write = Column(Integer,default=0)
	is_mother_tongue = Column(Integer,default=0)
	is_other = Column(Integer,default=0)
	created_at = Column(DateTime)
	modified_at = Column(DateTime)

class Talent_industry_location(Base):
	__tablename__ = "talent_industry_location"

	id = Column(Integer, primary_key=True)
	talent_id = Column(Integer, index=True)
	name = Column(String(60))
	code = Column(String(20))
	is_primary = Column(Integer,default=0)
	is_other = Column(Integer,default=0)
	created_at = Column(DateTime)
	modified_at = Column(DateTime)

class Talent_profile_intro(Base):
	__tablename__ = "talent_profile_intro"

	id = Column(Integer, primary_key=True)
	talent_id = Column(Integer, index=True)
	additional_information = Column(Text)
	personal_website = Column(String(255))
	personal_blog = Column(String(255))
	instagram = Column(String(255))
	behance = Column(String(255))
	IMDB = Column(String(255))
	created_at = Column(DateTime)
	modified_at = Column(DateTime)

class Talent_work_credits(Base):
	__tablename__ = "talent_work_credits"

	id = Column(Integer, primary_key=True)
	talent_id = Column(Integer, index=True)
	start_year_month = Column(String(30))
	end_year_month = Column(String(30))
	production_type = Column(String(50))
	code = Column(String(50))
	production_name = Column(String(200))
	role = Column(String(200))
	production_house = Column(String(200))
	created_at = Column(DateTime)
	modified_at = Column(DateTime)

class Talent_agent_representation(Base):
	__tablename__ = "talent_agent_representation"

	id = Column(Integer, primary_key=True)
	talent_id = Column(Integer, index=True)
	have_agent = Column(Integer)
	agency_name = Column(String(200))
	agent_email = Column(String(50))
	telephone = Column(Integer)
	agent_website = Column(Text)
	covering_industries = Column(String(100))
	agent_alert_message = Column(Integer,default=0)
	agent_looking_profile = Column(Integer,default=0)
	created_at = Column(DateTime)
	modified_at = Column(DateTime) 

class Talent_education(Base):
	__tablename__ = "talent_education"

	id = Column(Integer, primary_key=True)
	talent_id = Column(Integer)
	education = Column(String(150))
	subject = Column(String(150))
	university = Column(String(200))
	year_of_passing = Column(Integer)
	type = Column(String(100))
	created_on = Column(DateTime)
	updated_on = Column(DateTime)

class Talent_physical_appearance(Base):
	__tablename__ = "talent_physical_appearance"

	id = Column(Integer, primary_key=True)
	talent_id = Column(Integer, index=True)
	ethnicity = Column(String(50))
	feet_height = Column(String(10))
	inch_height = Column(String(10))
	skin_tone = Column(String(20))
	weight = Column(String(10))
	eye_colour = Column(String(20))
	build = Column(String(20))
	hair_colour = Column(String(20))
	playing_age = Column(String(50))
	hair_length = Column(String(20))
	created_on = Column(DateTime)
	updated_on = Column(DateTime)

class Talent_skillset_interests(Base):
	__tablename__ = "talent_skillset_interests"

	id = Column(Integer, primary_key=True)
	talent_id = Column(Integer, index=True)
	skill_type = Column(String(100))
	type = Column(String(100))
	value = Column(String(200))
	is_other = Column(String(100))
	created_at = Column(DateTime)
	updated_at = Column(DateTime)

class Talent_skillset_interest_onscreen(Base):
	__tablename__ = "talent_skillset_interest_onscreen"

	id = Column(Integer, primary_key=True)
	talent_id = Column(Integer, index=True)
	intimate_scenes = Column(String(100))
	nude_scenes = Column(String(100))
	kiss_scenes = Column(String(100))
	created_at = Column(DateTime)
	updated_at = Column(DateTime)

class Profile_completion_tabs(Base):
	__tablename__ = "profile_completion_tabs"

	id = Column(Integer, primary_key=True)
	title = Column(String(100))
	save_def_name = Column(String(100))
	completion_perc = Column(Integer)
	created_at = Column(DateTime)

class Talent_profile_completion_logs(Base):
	__tablename__ = "talent_profile_completion_logs"

	id = Column(Integer, primary_key=True)
	talent_id = Column(Integer, index=True)
	title = Column(String(100))
	save_def_name = Column(String(100))
	percentage = Column(Integer)
	is_completed = Column(Integer,default=0)
	created_at = Column(DateTime)
	updated_at = Column(DateTime)