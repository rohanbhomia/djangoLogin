from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, Date
from ..config.database import Base


class Employer_search(Base):
    __tablename__ = "employer_search"
    id = Column(Integer, primary_key=True, index=True)
    employer_id = Column(Integer)
    search_name = Column(String(100))
    search_value = Column(Text)
    created_on = Column(DateTime)
