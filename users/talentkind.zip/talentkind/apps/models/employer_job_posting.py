from sqlalchemy import Column, Integer, String, Text, DateTime,Boolean,Date
from ..config.database import Base




class Employer_job_posting(Base):
	__tablename__ = "employer_job_posting"
	id = Column(Integer, primary_key=True, index=True)
	employer_id = Column(Integer)
	category =  Column(String(100))
	other_category =  Column(String(100))
	role_type =  Column(String(100))
	project_title =  Column(String(100))
	primary_language =  Column(String(100))
	additional_language =  Column(String(100))
	project_description =  Column(Text)
	job_description =  Column(Text)
	character_name =  Column(String(100))
	age_start =  Column(Integer)
	age_end =  Column(Integer)
	playing_role =  Column(String(100))
	traits =  Column(String(100))
	role_description =  Column(Text)
	skills =  Column(String(100))
	pay_rage =  Column(String(100))
	experience =  Column(String(100))
	location =  Column(String(100))
	profession =  Column(String(100))
	directed_by =  Column(String(100))
	shooting_days =  Column(String(100))
	employment_type =  Column(String(100))
	position_type =  Column(String(100))
	apply_date = Column(Date)
	duration_start = Column(Date)
	duration_end = Column(Date)
	created_on = Column(DateTime)
	updated_on = Column(DateTime)