from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean
from ..config.database import Base

class Talent_temp_portfolios(Base):
	__tablename__ = "talent_temp_portfolios"
	id = Column(Integer, primary_key=True, index=True)
	talent_id = Column(Integer)
	media_type = Column(String(100))
	local_file = Column(Text)
	name = Column(String(255))
	exception_message = Column(String(255))
	uploaded_on_server = Column(Integer)
	created_at = Column(DateTime)
	modified_at = Column(DateTime)

class Talent_portfolio(Base):
	__tablename__ = "talent_portfolio"
	id = Column(Integer, primary_key=True, index=True)
	talent_id = Column(Integer)
	photos = Column(Text)
	photo_albums = Column(Text)
	videos = Column(Text)
	videos_albums = Column(Text)
	audios = Column(Text)
	audios_albums = Column(Text)
	awards = Column(Text)
	awards_albums = Column(Text)
	created_at = Column(DateTime)
	modified_at = Column(DateTime)