from sqlalchemy import Column, Integer, String, Text, DateTime, Date
from ..config.database import Base

class Employer_industry(Base):
	__tablename__ = "employer_industry"

	id = Column(Integer, primary_key=True)
	employer_id = Column(Integer, index=True,default=0)
	industry_code = Column(String(20),nullable=True)
	display_name = Column(String(100),nullable=True)
	created_on = Column(DateTime,nullable=True)
	updated_on = Column(DateTime,nullable=True)

class Employer_personal_info(Base):
	__tablename__ = "employer_personal_info"

	employer_id = Column(Integer,primary_key=True,default=0)
	company_name = Column(String(100),nullable=True)
	company_registration_number = Column(String(100),nullable=True)
	first_name = Column(String(100),nullable=True)
	last_name = Column(String(100),nullable=True)
	phone = Column(Integer,default=0)
	company_phone = Column(Integer,default=0)
	email = Column(String(100),nullable=True)
	company_email = Column(String(100),nullable=True)
	address = Column(String(250),nullable=True)
	state = Column(String(100),nullable=True)
	location = Column(String(100),nullable=True)
	pincode = Column(Integer,default=0)
	website_url = Column(String(255),nullable=True)
	month = Column(String(20),nullable=True)
	year = Column(String(10),nullable=True)
	sizing_of_company = Column(String(100),nullable=True)
	scale_of_operations = Column(String(50),nullable=True)
	company_profile_write_up = Column(Text,nullable=True)
	avatar_url = Column(String(255),nullable=True)
	created_at = Column(DateTime,nullable=True)
	modified_at = Column(DateTime,nullable=True)

class Employer_types_employer(Base):
	__tablename__ = "employer_types_employer"

	id = Column(Integer, primary_key=True)
	employer_id = Column(Integer, index=True,default=0)
	employer_type = Column(String(255),nullable=True)
	created_at = Column(DateTime,nullable=True)
	modified_at = Column(DateTime,nullable=True)