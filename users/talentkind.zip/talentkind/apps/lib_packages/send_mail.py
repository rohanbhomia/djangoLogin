from ..config.dependencies import conf, MessageSchema, FastMail

async def send_email(subject, email, body, attachments='', cc='',bcc=''):
	message = MessageSchema(
		subject = subject,
		recipients = email,
		body = body,
		# subtype = 'html',
		attachments = attachments, 
		cc = cc, 
		bcc = bcc,
	)
	fm = FastMail(conf)

	await fm.send_message(message)