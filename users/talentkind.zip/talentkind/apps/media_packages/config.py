##======== 		CREATE UPLOADS DYNAMIC FOLDER
import os
from pathlib import Path
from os import path

DIRECTORY_NAME = "uploads"
FOLDER_NAME = "//uploads//"

FOLDER_NAME = str(Path(__file__).resolve().parent.parent.parent) + FOLDER_NAME

if not path.exists(FOLDER_NAME):
    new_path = os.path.join(str(Path(__file__).resolve().parent.parent.parent), DIRECTORY_NAME)
    os.mkdir(new_path,775)
##======== 		END CREATE UPLOADS DYNAMIC FOLDER

##========      S3 CRED
AWS_ACCESS_KEY_ID = 'AKIAXBBUER6BEIF754U6'
AWS_SECRET_ACCESS_KEY = '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'
END_POINT = 'ap-south-1'
S3_HOST = 's3.ap-south-1.amazonaws.com'
BUCKET_NAME = 'tk-talent-portfolio-'
##========      END S3 CRED

PROFILE_HEIGHT = 250
PROFILE_WIDTH = 250