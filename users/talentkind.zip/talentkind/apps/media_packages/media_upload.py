from .media_validations import validate_avatar
from .image_resize_functions import Resize
from .upload_cloud import upload_on_server
from .config import *
from mimetypes import guess_extension, guess_type
import base64
import random

def upload_avatar(id: int, encodeStr: str, user_bucket: str):
	extension = guess_extension(guess_type(encodeStr)[0])
	validationFlag = validate_avatar(extension)
	if validationFlag == True:
		splitStr = encodeStr.split('base64,')
		
		image_data = bytes(splitStr[1], encoding="raw_unicode_escape")
		image_data_bytes = base64.decodebytes(image_data)

		imageName = str(id)+'_'+str(random.randint(1000, 9999))+"_avatar"+str(extension)
		fileName = str(FOLDER_NAME)+imageName
		with open(fileName, "wb") as fh:
		    fh.write(image_data_bytes)

		resizedImage = Resize(imageName, extension).resize_profile_image()

		if not resizedImage:
			return None
		else:
			return upload_on_server(resizedImage, user_bucket, 'avatar')
	else:
		return None

def upload_portfolio(id: int, media: str, user_bucket: str):
	# extension = guess_extension(guess_type(encodeStr)[0])
	# validationFlag = validate_avatar(extension)
	# if validationFlag == True:
	return upload_on_server(media, user_bucket, 'portfolio')
	# else:
	# 	return None