from .config import *
import boto3

def upload_on_server(newImageName,user_bucket, folder):
	newFileName = str(FOLDER_NAME)+newImageName
	talent_bucket_name = user_bucket
	bucket_name = BUCKET_NAME+''+str(talent_bucket_name[0].lower())
	s3 = boto3.client('s3',aws_access_key_id=AWS_ACCESS_KEY_ID,aws_secret_access_key= AWS_SECRET_ACCESS_KEY)
	fileupload = talent_bucket_name+'/'+folder+'/'+str(newImageName)
	with open(newFileName, "rb") as f:
		s3.upload_fileobj(f, bucket_name,fileupload,ExtraArgs={'ACL':'public-read'}) 
		
	return str('https://')+str(bucket_name)+'.s3.ap-south-1.amazonaws.com/'+str(talent_bucket_name)+'/'+folder+'/'+str(newImageName)