from .config import *
from mimetypes import guess_extension, guess_type
import base64
import random
import shutil
from ..config.dependencies import os, FOLDER_NAME

def upload_media(talent_id: int, encodeStr: str):
	extension = guess_extension(guess_type(encodeStr)[0])
	
	splitStr = encodeStr.split('base64,')
	
	image_data = bytes(splitStr[1], encoding="raw_unicode_escape")
	image_data = base64.decodebytes(image_data)

	imageName = str(talent_id)+'_'+str(random.randint(1000, 9999))+"_portfolio"+str(extension)
	fileName = str(FOLDER_NAME)+imageName
	with open(fileName, "wb") as fh:
		fh.write(image_data)

	return imageName

def  upload_media_form_data(talent_id: int, filename: str, file: str):
	extTuple = os.path.splitext(filename)
	ext = extTuple[1]
	imageName = str(talent_id)+'_'+str(random.randint(1000, 9999))+"_portfolio"+str(ext)
	fileName = str(FOLDER_NAME)+imageName

	with open(fileName, "wb") as buffer:
		shutil.copyfileobj(file, buffer)

	return imageName