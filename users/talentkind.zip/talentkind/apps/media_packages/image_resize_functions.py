from PIL import Image
from .config import *
import random

class Resize():
	def __init__(self, imageName, extension):
		self.imageName = imageName
		self.extension = extension
		self.profile_width = PROFILE_WIDTH
		self.profile_height = PROFILE_HEIGHT
		
	def resize_profile_image(self):
		image = Image.open(str(FOLDER_NAME)+self.imageName)
		image.thumbnail((self.profile_width, self.profile_height))		###	ERROR 	'int' object is not iterable
		newImageName = str(random.randint(1000, 9999))+'_'+'image_thumbnail'+str(self.extension)
		image.save(str(FOLDER_NAME)+newImageName)
		return newImageName