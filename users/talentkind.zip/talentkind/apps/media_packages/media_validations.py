import fastapi

def validate_avatar(extension):
	if extension not in ['.png', '.jpg', '.jpeg', '.PNG', '.JPG', '.JPEG']:
		return None
	else:
		return True