from typing import Optional, List, Dict
from pydantic import BaseModel,ValidationError,validator,Field, PositiveInt
from fastapi import FastAPI, Query
from pydantic.dataclasses import dataclass
from ..validator_package import validation

class TalentNotificationSchema(BaseModel):
    recommended_notification: int
    notification_from_employers : int
    notifications_from_agents : int
    notification_from_networks : int
    notifications_from_talentkind : int
    talentkind_newsletter : int
    
    @validator('recommended_notification')
    def recommended_notification_validation(cls, recommended_notification):
        return validation.check_integer_format(recommended_notification)

    @validator('notification_from_employers')
    def notification_from_employers_validation(cls, notification_from_employers):
        return validation.check_integer_format(notification_from_employers)

    @validator('notifications_from_agents')
    def notifications_from_agents_validation(cls, notifications_from_agents):
        return validation.check_integer_format(notifications_from_agents)

    @validator('notification_from_networks')
    def notification_from_networks_validation(cls, notification_from_networks):
        return validation.check_integer_format(notification_from_networks)

    @validator('notifications_from_talentkind')
    def notifications_from_talentkind_validation(cls, notifications_from_talentkind):
        return validation.check_integer_format(notifications_from_talentkind)

    @validator('talentkind_newsletter')
    def talentkind_newsletter_validation(cls, talentkind_newsletter):
        return validation.check_integer_format(talentkind_newsletter)

class DeleteAccountSchema(BaseModel):
    is_delete: int

    @validator('is_delete')
    def check_delete_status(cls,is_delete):
        return validation.check_integer_format(is_delete)

class ChangeStatusSchema(BaseModel):
    is_active: int
  
    @validator('is_active')
    def status_validation(cls, is_active):
        return validation.check_integer_format(is_active)

class ChangePassword(BaseModel):
    old_password: str
    new_password: str
    confirm_password: str

    @validator('old_password')
    def old_password_validation(cls, old_password):
        return validation.required_validation(old_password,"Old password is required")
    
    @validator('new_password')
    def new_password_validation(cls, new_password):
        return validation.required_validation(new_password,"New password is required")

    @validator('confirm_password')
    def confirm_password_validation(cls, confirm_password):
        return validation.required_validation(confirm_password,"Confirm password is required")

class TalentProfileVisibility(BaseModel):

    profile: str
    photos : str
    videos : str
    audios : str
    awards : str

    @validator('profile')
    def profile_validation(cls, profile):
        return validation.check_blank_validation(profile,"Profile field is missing")
    
    @validator('photos')
    def photos_validation(cls, photos):
        return validation.check_blank_validation(photos,"Photos field is missing")
    
    @validator('videos')
    def videos_validation(cls, videos):
        return validation.check_blank_validation(videos,"Videos field is missing")
    
    @validator('audios')
    def audios_validation(cls, audios):
        return validation.check_blank_validation(audios,"Audios field is missing")
    
    @validator('awards')
    def awards_validation(cls, awards):
        return validation.check_blank_validation(awards,"Awards field is missing")
    
        
       

