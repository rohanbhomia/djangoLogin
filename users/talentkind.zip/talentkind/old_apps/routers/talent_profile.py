from fastapi import APIRouter, Depends, BackgroundTasks, Request
from ..schemas.talent_profile import *
from ..services.talent_profile import *
from ..utils.service_result import handle_result
from ..config.database import get_db

router =APIRouter(
    prefix="/api/talent",
    tags=["talent_profile"],
    responses={404: {"description": "Not found"}},
)

@router.get("/personal_information/")
async def personal_information(token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = PersonalInfoService(db).PersonalInfo(token)
    return handle_result(result)
    
@router.post("/get_states/")
async def get_states(stateFields:getStatesFileds):
    result = GetStateService.GetState(stateFields)
    return handle_result(result)

@router.post("/get_cities/")
async def get_cities(cityFields:getCitiesFileds):
    result = GetCityService.GetCity(cityFields)
    return handle_result(result)

@router.post("/update_personal_information/")
async def update_personal_information(TalentPersonalInfo:TalentPersonalInfo, background_tasks: BackgroundTasks, request: Request, token = Depends(get_talent_current_user), db: get_db = Depends()):    
    result = await update_personal_info(TalentPersonalInfo,background_tasks, request,token,db)
    return handle_result(result)

@router.post("/get_cities/")
async def get_cities(cityFields:getCitiesFileds):
    result = GetCityService.GetCity(cityFields)
    return handle_result(result)

@router.get("/get_industries/")
async def get_industries(token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = IndustriesService(db).GetIndustries(token)
    return handle_result(result)

@router.get("/get_industries_primary/")
async def get_industries_primary(token = Depends(get_talent_current_user), db: get_db = Depends()):   
    result = IndustriesService(db).GetPrimaryIndustry(token)
    return handle_result(result)

@router.post("/save_talent_industries_primary/")
async def save_talent_industries_primary(talentIndustriesPri:TalentIndustriesPrimary, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = IndustriesService(db).SavePrimaryIndustry(talentIndustriesPri,token)
    return handle_result(result)

@router.post("/save_talent_industries/")
async def save_talent_industries(talentIndustries:TalentIndustries,token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = IndustriesService(db).SaveTalentIndustries(talentIndustries,token)
    return handle_result(result)

@router.get("/get_talent_type/")
async def get_talent_type(token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = TalentTypeService(db).GetTalentType(token)
    return handle_result(result)

@router.post("/save_talent_industry_profession/")
async def save_talent_industry_profession(talentIndustriesProfession:TalentIndustryProfession, request: Request,token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = TalentTypeService(db).SaveTalentProfession(talentIndustriesProfession, request,token)
    return handle_result(result)

@router.post("/get_onscreen_talent_type/")
async def get_onscreen_talent_type(onScreenTalentTypeProfession:OnScreenTalentTypeProfession, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = TalentTypeService(db).GetOnscreenTalentType(onScreenTalentTypeProfession,token)
    return handle_result(result)

@router.post("/save_onscreen_talent_type/")
async def save_onscreen_talent_type(onScreenTalentType:OnScreenTalentType, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = TalentTypeService(db).SaveOnscreenTalentType(onScreenTalentType,token)
    return handle_result(result)

@router.get("/language_industries_location/")
async def language_industries_location(token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = LanguageLocationService(db).GetLangIndusLoc(token)
    return handle_result(result)

@router.post("/save_language_industries_location/")
async def save_language_industries_location(getTalentLanguageFileds:GetTalentLanguageFileds, request: Request, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = LanguageLocationService(db).SaveLangIndusLoc(getTalentLanguageFileds, request,token)
    return handle_result(result)

@router.get("/profile_intro/")
async def profile_intro(token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = ProfileIntroService(db).getProfileIntro(token)
    return handle_result(result)

@router.post("/save_profile_intro/")
async def save_profile_intro(profileIntroFileds:ProfileIntroFileds, request: Request, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = ProfileIntroService(db).saveProfileIntro(profileIntroFileds, request, token)
    return handle_result(result)

@router.get("/work_credit/")
async def work_credit(token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = WorkCreditService(db).getWorkCredit(token)
    return handle_result(result)

@router.post("/save_work_credit/")
async def save_work_credit(workCreditsFileds: NewWorkCreditsFileds, request: Request, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = WorkCreditService(db).saveWorkCredit(workCreditsFileds, request, token)
    return handle_result(result)

@router.post("/delete_work_credit/")
async def delete_work_credit(workCreditsFileds: WorkCreditsFileds, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = WorkCreditService(db).deleteWorkCredit(workCreditsFileds, token)
    return handle_result(result)

@router.get("/get_education_and_training/")
async def get_education_and_training(token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = EducationTrainingService(db).getEducationTraining(token)
    return handle_result(result)

@router.post("/education_and_training/")
async def education_and_training(talentEducation: TalentEducation, request: Request, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = EducationTrainingService(db).saveEducationTraining(talentEducation, request, token)
    return handle_result(result)

@router.post("/delete_education_training/")
async def delete_education_training(talentEducation: TalentEducationBase, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = EducationTrainingService(db).deleteEducationTraing(talentEducation, token)
    return handle_result(result)

@router.get("/get_physical_appearance/")
async def get_physical_appearance(token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = PhysicalAppearanceService(db).getPhysicalAppearance(token)
    return handle_result(result)

@router.post("/save_physical_appearance/")
async def save_physical_appearance(physicalAppearances: TalentPhysicalAppearance, request: Request, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = PhysicalAppearanceService(db).savePhysicalAppearance(physicalAppearances, request, token)
    return handle_result(result)

@router.get("/get_skillset_interests/")
async def get_skillset_interests(token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = SkillIntService(db).getSkillInterest(token)
    return handle_result(result)

@router.post("/save_skillset_interests/")
async def save_skillset_interests(talentSkillsetInterest: TalentSkillsetInterest, request: Request, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = SkillIntService(db).saveSkillInterest(talentSkillsetInterest, request, token)
    return handle_result(result)

@router.post("/save_agent_representation/")
async def save_agent_representation(TalentAgentRepresentation: TalentAgentRepresentation, request: Request, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = AgentService(db).saveAgentRepresentation(TalentAgentRepresentation, request, token)
    return handle_result(result)

@router.get("/get_agent_representation/")
async def get_agent_representation(token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = AgentService(db).getAgentRepresentation(token)
    return handle_result(result)
    
@router.get("/get_tk_id/")
async def get_tk_id(token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = TkIdServices(db).getTkId(token)
    return handle_result(result)

@router.post("/verify_slug/")
async def verify_slug(Slug: Slug, token = Depends(get_talent_current_user), db: get_db = Depends()):
    result = TkIdServices(db).updateSlug(Slug,token)
    return handle_result(result)