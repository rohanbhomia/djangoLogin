from fastapi import Request
from starlette.responses import JSONResponse


class AppExceptionCase(Exception):
    def __init__(self, status_code: int, context: dict):
        self.exception_case = self.__class__.__name__
        self.status_code = status_code
        self.context = context

    def __str__(self):
        return (
            f"<AppException {self.exception_case} - "
            + f"status_code={self.status_code} - context={self.context}>"
        )


async def app_exception_handler(request: Request, exc: AppExceptionCase):

    # return JSONResponse(
    #     status_code=exc.status_code,
    #     content={
    #         "app_exception": exc.exception_case,
    #         "context": exc.context,
    #     },
    # )

    #CUSTOME CODE
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "status": exc.status_code,
            "message": exc.context,
        },
    )

    # message={}
    # message.update({'message':""})
    # return JSONResponse(
    #     content={
    #         "status": "402",
    #         "message": message,
    #     },
    # )


class AppException(object):
    
    # class CheckRecordException(AppExceptionCase):
    #     def __init__(self, context: dict = "Record does not exist"):
    #         """
    #         image file creation failed
    #         """
    #         status_code = 409
    #         AppExceptionCase.__init__(self, status_code, context)

    # class FileException(AppExceptionCase):
    #     def __init__(self, context: dict = "Failed"):
    #         """
    #         image file creation failed
    #         """
    #         status_code = 409
    #         AppExceptionCase.__init__(self, status_code, context)


    class CreateValidation(AppExceptionCase):
        def __init__(self, context: dict = "Failed"):
            """
            Item creation failed
            """
            status_code = 409
            AppExceptionCase.__init__(self, status_code, context)

    class GetValidation(AppExceptionCase):
        def __init__(self, context: dict = None):
            """
            Item not found
            """
            status_code = 404
            AppExceptionCase.__init__(self, status_code, context)

    class RequiresAuthValidation(AppExceptionCase):
        def __init__(self, context: dict = None):
            """
            Item is not public and requires auth
            """
            status_code = 401
            AppExceptionCase.__init__(self, status_code, context)

    class DuplicateValidation(AppExceptionCase):
        def __init__(self, context: dict = "Record already exist"):
            """
            Item is not public and requires auth
            """
            status_code = 401
            AppExceptionCase.__init__(self, status_code, context)

