from ..schemas.talent_portfolio import *
from ..models.talent_portfolio import *
from ..models.talent_login import Talent_register
from ..utils.app_exceptions import AppException
from ..services.main import AppService, AppCRUD
from ..utils.service_result import ServiceResult
from ..config.dependencies import dateTime_at, os, FOLDER_NAME
from fastapi import Depends,BackgroundTasks
from mimetypes import guess_extension, guess_type
import base64
import random

statusCodeSuccess = int(os.getenv('STATUS_200'))
statusMessageSuccess = os.getenv('MESSAGE_200')
statusCodeFailure = int(os.getenv('STATUS_409'))
statusMessageFailed = os.getenv('MESSAGE_409')

from ..media_packages import media_portfolio_temp
from ..media_packages import media_upload
from ..config.database import mysqlConnection, mydb
import json

#SWATI only for temp_upoload_portfolio
from ..services.talent_profile import get_talent_current_user
from ..config.database import get_db
import shutil
from fastapi import UploadFile,File,Form,Request
from datetime import datetime
from typing import Optional
#SWATI

#FOR QR CODE
import pyqrcode
import png
from pyqrcode import QRCode
from ..models.talent_profile import Talent_personal_info
from urllib.parse import urlparse   ### NEW ADDED BY KAMLESH

#KAMLESH BASE64 encoded image uploading
# async def temp_upoload_portfolio(talentImages:TalentImages,background_tasks: BackgroundTasks,token,db):
# 	talent_id = token.id
# 	media_type = talentImages.media_type
# 	for media in talentImages.portfolio:
# 		if media is not None:
# 			imageName = media_portfolio_temp.upload_media(talent_id, media)
			
# 			talent_images = Talent_temp_portfolios(
# 				talent_id = talent_id,
# 				media_type = media_type,
# 				local_file = imageName,
# 				exception_message = '',
# 				uploaded_on_server = 0,
# 				created_at = dateTime_at
# 			)
# 			db.add(talent_images)
# 			db.commit()
# 			db.refresh(talent_images)
	
# 	response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
# 	background_tasks.add_task(uploadTempPortfolio, talent_id, db)
# 	if not response:
# 		return ServiceResult(AppException.CreateValidation())
# 	return ServiceResult(response)
#KAMLESH

#SWATI using FORM data image upload
async def temp_upoload_portfolio(files: List[UploadFile] =File(...), media_type: str = Form(...), background_tasks: BackgroundTasks = BackgroundTasks(), token = Depends(get_talent_current_user), db: get_db = Depends()):
	talent_id = token.id
	for media in files:
		if media is not None:
			imageName = media_portfolio_temp.upload_media_form_data(talent_id, media.filename, media.file)
			extTuple = os.path.splitext(media.filename)
			talent_images = Talent_temp_portfolios(
				talent_id = talent_id,
				media_type = media_type,
				local_file = imageName,
				name = extTuple[0],
				exception_message = '',
				uploaded_on_server = 0,
				created_at = dateTime_at
			)
			db.add(talent_images)
			db.commit()
			db.refresh(talent_images)
			
	response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
	background_tasks.add_task(uploadTempPortfolio, talent_id, db)
	if not response:
		return ServiceResult(AppException.CreateValidation())
	return ServiceResult(response)
#SWATI using FORM data image upload

async def uploadTempPortfolio(id : int, db):		###		CONVERT BY CONDITION
	getTempFiles = db.query(Talent_temp_portfolios).filter(Talent_temp_portfolios.talent_id == id).filter(Talent_temp_portfolios.uploaded_on_server == 0).all()
	talent_register = db.query(Talent_register).filter((Talent_register.id == id)).first()
	talent_portfolio = db.query(Talent_portfolio).filter((Talent_portfolio.talent_id == id)).first()
	
	portfolio_list = []
	if not talent_portfolio:												##		CREATE TALENT_PORTFOLIO LIST IF NOT EXIST
		talent_portfolio = Talent_portfolio(
			talent_id=id,
			created_at = dateTime_at
		)
		db.add(talent_portfolio)
		db.commit()
		db.refresh(talent_portfolio)
	else:
		getTempRow1 = db.query(Talent_temp_portfolios).filter(Talent_temp_portfolios.talent_id == id).filter(Talent_temp_portfolios.uploaded_on_server == 0).first()
		media_type1 = getTempRow1.media_type
		if media_type1 =='photos':
			if talent_portfolio.photos is not None:
				portfolio_list = json.dumps(eval(talent_portfolio.photos))		##		STRING IN TABLE
				portfolio_list = json.loads(portfolio_list)						##		STRING TO LIST CONVERSION
		elif media_type1 =='audios':
			if talent_portfolio.audios is not None:
				portfolio_list = json.dumps(eval(talent_portfolio.audios))		##		STRING IN TABLE
				portfolio_list = json.loads(portfolio_list)
		elif media_type1 =='videos':
			if talent_portfolio.videos is not None:
				portfolio_list = json.dumps(eval(talent_portfolio.videos))		##		STRING IN TABLE
				portfolio_list = json.loads(portfolio_list)						##		STRING TO LIST CONVERSION
		elif media_type1 =='awards':
			if talent_portfolio.awards is not None:
				portfolio_list = json.dumps(eval(talent_portfolio.awards))		##		STRING IN TABLE
				portfolio_list = json.loads(portfolio_list)						##		STRING TO LIST CONVERSION

	
	user_bucket = talent_register.s3_bucket
	new_portfolio_list = []
	if getTempFiles is not None:
		for tempFiles in getTempFiles:
			getTempRow = db.query(Talent_temp_portfolios).filter(Talent_temp_portfolios.id == tempFiles.id).first()
			media_type = getTempRow.media_type
			return_s3_url = media_upload.upload_portfolio(id, tempFiles.local_file, user_bucket)
			if return_s3_url:
				randomId = random.randint(100000, 999999)
				year = datetime.strptime(dateTime_at, '%Y-%m-%d %H:%M:%S').year
				update_json = {"id":randomId, "media_path":return_s3_url,"name":getTempRow.name,"year":year,"created_at":dateTime_at}
				if getTempRow.media_type == 'photos':
					update_json['photographer'] = ""
				elif getTempRow.media_type == 'audios':
					update_json['singer'] = ""
				elif getTempRow.media_type == 'rewards':
					update_json['issuing_authority'] = ""
				else:
					update_json['description'] = ""

				new_portfolio_list.append(update_json)
				
				db.query(Talent_temp_portfolios).filter(Talent_temp_portfolios.id == tempFiles.id).delete()
				db.commit()
			else:
				getTempRow.exception_message = "Invalid file format"
				getTempRow.modified_at = dateTime_at
				db.add(getTempRow)
				db.commit()
				db.refresh(getTempRow)

		portfolio_list = portfolio_list + new_portfolio_list
		portfolio_list = json.dumps(portfolio_list)
		mysqlConnection.execute(f"UPDATE talent_portfolio SET {getTempRow.media_type} = '{portfolio_list}' WHERE talent_id = '{id}'")
		mydb.commit()

class PortfolioService(AppService):
	def getPortfolio(self, mediaTypeSchema:MediaType, token) -> ServiceResult:
		get_talent_portfolio = PortfolioCRUD(self.db).get_talent_portfolio(mediaTypeSchema,token)
		if not get_talent_portfolio:
			return ServiceResult(AppException.GetValidation("Record not exists"))
		return ServiceResult(get_talent_portfolio)

	def updatePortfolio(self, talentPortfolioSave:TalentPortfolioSave, token) -> ServiceResult:
		get_talent_portfolio = PortfolioCRUD(self.db).update_talent_portfolio(talentPortfolioSave,token)
		if not get_talent_portfolio:
			return ServiceResult(AppException.GetValidation("Record not exists"))
		return ServiceResult(get_talent_portfolio)

	def deletePortfolio(self, talentPortfolio:TalentPortfolio, token) -> ServiceResult:
		get_talent_portfolio = PortfolioCRUD(self.db).delete_talent_portfolio(talentPortfolio,token)
		if not get_talent_portfolio:
			return ServiceResult(AppException.GetValidation("Record not exists"))
		return ServiceResult(get_talent_portfolio)

	def getTalentAlbums(self, mediaTypeSchema:MediaType, token) -> ServiceResult:
		get_talent_portfolio = PortfolioCRUD(self.db).get_talent_albums(mediaTypeSchema,token)
		if not get_talent_portfolio:
			return ServiceResult(AppException.GetValidation("Record not exists"))
		return ServiceResult(get_talent_portfolio)

	def createAlbum(self, albumSchema:TalentAlbum, token) -> ServiceResult:
		get_talent_portfolio = PortfolioCRUD(self.db).create_talent_album(albumSchema,token)
		if not get_talent_portfolio:
			return ServiceResult(AppException.CreateValidation("Failed"))
		return ServiceResult(get_talent_portfolio)

	def deleteAlbum(self, talentPortfolio:TalentPortfolio, token) -> ServiceResult:
		get_talent_portfolio = PortfolioCRUD(self.db).delete_talent_albums(talentPortfolio,token)
		if not get_talent_portfolio:
			return ServiceResult(AppException.GetValidation("Record not exists"))
		return ServiceResult(get_talent_portfolio)
	
	def addAlbumPhotos(self, addalbumSchema:AddTalentAlbum, token) -> ServiceResult:
		get_talent_portfolio = PortfolioCRUD(self.db).add_album_photos(addalbumSchema,token)
		if not get_talent_portfolio:
			return ServiceResult(AppException.GetValidation("Record not exists"))
		return ServiceResult(get_talent_portfolio)

	def getAlbumPhotos(self, getalbumSchema:TalentPortfolio, token) -> ServiceResult:
		get_talent_portfolio = PortfolioCRUD(self.db).get_album_photos(getalbumSchema,token)
		if not get_talent_portfolio:
			return ServiceResult(AppException.GetValidation("Data not found"))
		return ServiceResult(get_talent_portfolio)

	def getSinglePortfolio(self, talentPortfolio:TalentPortfolio, token) -> ServiceResult:
		get_talent_portfolio = PortfolioCRUD(self.db).get_single_portfolio(talentPortfolio,token)
		if not get_talent_portfolio:
			return ServiceResult(AppException.GetValidation("Data not found"))
		return ServiceResult(get_talent_portfolio)

	def getSingleAlbumPortfolio(self, talentAlbumPortfolio:TalentAlbumPortfolio, token) -> ServiceResult:
		get_talent_portfolio = PortfolioCRUD(self.db).get_single_album_portfolio(talentAlbumPortfolio,token)
		if not get_talent_portfolio:
			return ServiceResult(AppException.GetValidation("Data not found"))
		return ServiceResult(get_talent_portfolio)

	def generateQrCode(self, Request:Request, token) -> ServiceResult:
		get_talent_portfolio = PortfolioCRUD(self.db).generate_qr_code(Request,token)
		if not get_talent_portfolio:
			return ServiceResult(AppException.GetValidation("Data not found"))
		return ServiceResult(get_talent_portfolio)

	def viewProfile(self, talent_id:str) -> ServiceResult:
		get_talent_portfolio = PortfolioCRUD(self.db).view_profile(talent_id)
		if not get_talent_portfolio:
			return ServiceResult(AppException.GetValidation("Data not found"))
		return ServiceResult(get_talent_portfolio)

class PortfolioCRUD(AppCRUD):
	def get_talent_portfolio(self, mediaTypeSchema:MediaType, token):		###		CONVERT BY CONDITION
		talent_id = token.id
		media=[]
		talent_portfolio_data = self.db.query(Talent_portfolio).filter((Talent_portfolio.talent_id == talent_id)).first()
		if talent_portfolio_data:
			if mediaTypeSchema.media_type=='photos':
				if talent_portfolio_data.photos:
					portfolio_list = json.dumps(eval(talent_portfolio_data.photos))		###		STRING IN TABLE
					media = json.loads(portfolio_list)	
			elif mediaTypeSchema.media_type=='videos':
				if talent_portfolio_data.videos:
					portfolio_list = json.dumps(eval(talent_portfolio_data.videos))		###		STRING IN TABLE
					media = json.loads(portfolio_list)	
			elif mediaTypeSchema.media_type=='audios':
				if talent_portfolio_data.audios:
					portfolio_list = json.dumps(eval(talent_portfolio_data.audios))		###		STRING IN TABLE
					media = json.loads(portfolio_list)	
			elif mediaTypeSchema.media_type=='awards':
				if talent_portfolio_data.awards:
					portfolio_list = json.dumps(eval(talent_portfolio_data.awards))		###		STRING IN TABLE
					media = json.loads(portfolio_list)

			data={"talent_portfolio":media}
			response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : data}
			return response
		else:
			return None

	def get_talent_albums(self, mediaTypeSchema:MediaType, token):		###		CONVERT BY CONDITION
		talent_id = token.id
		media=[]
		talent_portfolio_data = self.db.query(Talent_portfolio).filter((Talent_portfolio.talent_id == talent_id)).first()
		if talent_portfolio_data:
			if mediaTypeSchema.media_type=='photo_albums':
				if talent_portfolio_data.photo_albums:
					portfolio_list = json.dumps(eval(talent_portfolio_data.photo_albums))		###	STRING IN TABLE
					media = json.loads(portfolio_list)
					# for mediaRow in media_data:
					# 	update_json = {"id":mediaRow['id'], "album_name":mediaRow['album_name']}
					# 	media.append(update_json)
			elif mediaTypeSchema.media_type=='videos_albums':
				if talent_portfolio_data.videos_albums:
					portfolio_list = json.dumps(eval(talent_portfolio_data.videos_albums))		###	STRING IN TABLE
					media = json.loads(portfolio_list)	
			elif mediaTypeSchema.media_type=='audios_albums':
				if talent_portfolio_data.audios_albums:
					portfolio_list = json.dumps(eval(talent_portfolio_data.audios_albums))		###	STRING IN TABLE
					media = json.loads(portfolio_list)

			data={"talent_albums":media}
			response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : data}
			return response
		else:
			return None

	def create_talent_album(self, albumSchema:TalentAlbum, token): 		###		CONVERT BY CONDITION
		talent_id = token.id
		talent_portfolio = self.db.query(Talent_portfolio).filter((Talent_portfolio.talent_id == talent_id)).first()
		album_list = []
		if not talent_portfolio:											##	CREATE TALENT_PORTFOLIO LIST IF NOT EXIST
			talent_portfolio = Talent_portfolio(
				talent_id=talent_id,
				created_at = dateTime_at
			)
			self.db.add(talent_portfolio)
			self.db.commit()
			self.db.refresh(talent_portfolio)
		else:
			if albumSchema.media_type =='photo_albums':
				if talent_portfolio.photo_albums is not None:
					album_list = json.dumps(eval(talent_portfolio.photo_albums))
					album_list = json.loads(album_list)	
			elif albumSchema.media_type =='videos_albums':
				if talent_portfolio.videos_albums is not None:
					album_list = json.dumps(eval(talent_portfolio.videos_albums))	
					album_list = json.loads(album_list)	
			elif albumSchema.media_type =='audios_albums':
				if talent_portfolio.audios_albums is not None:
					album_list = json.dumps(eval(talent_portfolio.audios_albums))		
					album_list = json.loads(album_list)									

		randomId = random.randint(100000, 999999)
		year = datetime.strptime(dateTime_at, '%Y-%m-%d %H:%M:%S').year
		new_album_dict = {"id":randomId, "album_name":albumSchema.album_name,"year": year, "created_at": dateTime_at,"modified_at": dateTime_at}
		album_list.append(new_album_dict)											##		ADD DICT INTO LAST OF LIST
		album_list = json.dumps(album_list)											##		CONVERT LIST TO STRING TO STORE INTO TABLE
		mysqlConnection.execute(f"UPDATE talent_portfolio SET {albumSchema.media_type} = '{album_list}' WHERE talent_id = '{talent_id}'")
		mydb.commit()
		response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
		return response

	def add_album_photos(self, addalbumSchema:AddTalentAlbum, token):
		talent_id = token.id
		talent_portfolio_data = self.db.query(Talent_portfolio).filter((Talent_portfolio.talent_id == talent_id)).first()

		if talent_portfolio_data:
			if addalbumSchema.media_type=='photo_albums':
				if talent_portfolio_data.photo_albums is not None: 
					portfolio_albums = json.dumps(eval(talent_portfolio_data.photo_albums))	
					portfolio_albums = json.loads(portfolio_albums)
					dict_index = next((index for (index, d) in enumerate(portfolio_albums) if d["id"] == addalbumSchema.album_id), None)
					if dict_index is not None:
						newMedia = addalbumSchema.medias
						if newMedia:
							cover_image_id=newMedia[0]['id']
							cover_image_url=newMedia[0]['imgurl']
						else:
							cover_image_id=""
							cover_image_url=""

						portfolio_albums[dict_index].update({"medias":newMedia,"cover_image_id":cover_image_id,"cover_image_url":cover_image_url})
					new_photo_albums = json.dumps(portfolio_albums)	
					mysqlConnection.execute(f"UPDATE talent_portfolio SET {addalbumSchema.media_type} = '{new_photo_albums}' WHERE talent_id = '{talent_id}'")
					mydb.commit()
					response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
					return response
				else:
					return None

			if addalbumSchema.media_type=='audios_albums':
				if talent_portfolio_data.audios_albums is not None: 
					portfolio_albums = json.dumps(eval(talent_portfolio_data.audios_albums))	
					portfolio_albums = json.loads(portfolio_albums)
					dict_index = next((index for (index, d) in enumerate(portfolio_albums) if d["id"] == addalbumSchema.album_id), None)
					if dict_index is not None:
						portfolio_albums[dict_index].update({"medias":addalbumSchema.medias})
					new_photo_albums = json.dumps(portfolio_albums)
					mysqlConnection.execute(f"UPDATE talent_portfolio SET {addalbumSchema.media_type} = '{new_photo_albums}' WHERE talent_id = '{talent_id}'")
					mydb.commit()
					response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
					return response
				else:
					return None

			if addalbumSchema.media_type=='videos_albums':
				if talent_portfolio_data.videos_albums is not None: 
					portfolio_albums = json.dumps(eval(talent_portfolio_data.videos_albums))	
					portfolio_albums = json.loads(portfolio_albums)
					dict_index = next((index for (index, d) in enumerate(portfolio_albums) if d["id"] == addalbumSchema.album_id), None)
					dict_index = next((index for (index, d) in enumerate(portfolio_albums) if d["id"] == addalbumSchema.album_id), None)
					if dict_index is not None:
						portfolio_albums[dict_index].update({"medias":addalbumSchema.medias})
					new_photo_albums = json.dumps(portfolio_albums)	
					mysqlConnection.execute(f"UPDATE talent_portfolio SET {addalbumSchema.media_type} = '{new_photo_albums}' WHERE talent_id = '{talent_id}'")
					mydb.commit()
					response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
					return response
				else:
					return None

		else:
			return None

	def get_album_photos(self, getalbumSchema:TalentPortfolio, token):      ######	 CONVERT BY CONDITION
		talent_id = token.id
		#talent_portfolio_data = self.db.query(Talent_portfolio).filter((Talent_portfolio.talent_id == talent_id)).first()
		if getalbumSchema.media_type=='photo_albums':
			field='photos'
		elif getalbumSchema.media_type=='videos_albums':
			field='videos'
		elif getalbumSchema.media_type=='audios_albums':
			field='audios'

		mysqlConnection.execute(f"SELECT {getalbumSchema.media_type},{field} FROM talent_portfolio where talent_id='{talent_id}'")
		talent_portfolio_data = mysqlConnection.fetchone()
		talent_portfolio_data
		mydb.commit()
		
		if talent_portfolio_data:
			talent_album = {}
			talent_album_medias = None
			if talent_portfolio_data[0] is not None:
				portfolio_photo_albums = json.dumps(eval(talent_portfolio_data[0]))	
				portfolio_photo_albums = json.loads(portfolio_photo_albums)
				dict_index = next((index for (index, d) in enumerate(portfolio_photo_albums) if d["id"] == getalbumSchema.id), None)
				if dict_index is not None:
					talent_album = portfolio_photo_albums[dict_index]
					#talent_album['year'] = datetime.strptime(portfolio_photo_albums[dict_index]['modified_at'], '%Y-%m-%d %H:%M:%S').year
					if 'medias' in talent_album.keys():
						talent_album_medias = talent_album['medias']

			talent_portfolio = []
			if talent_portfolio_data[1] is not None:
				portfolio_list = json.dumps(eval(talent_portfolio_data[1]))		###		STRING IN TABLE
				talent_portfolio = json.loads(portfolio_list)
				if talent_album_medias is not None:
					filter_list = [int(d['id']) for d in talent_album_medias]
					talent_portfolio = [d for d in talent_portfolio if d['id'] not in filter_list]

			data = {"talent_portfolio": talent_portfolio, "album_photos": talent_album}	
			response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response": data}
			return response
		else:
			return None

	def get_single_portfolio(self, talentPortfolio:TalentPortfolio, token):			###		CONVERT BY CONDITION
		talent_id = token.id
		media={}
		talent_portfolio_data = self.db.query(Talent_portfolio).filter((Talent_portfolio.talent_id == talent_id)).first()
		if talent_portfolio_data:
			if talentPortfolio.media_type=='photos':
				if talent_portfolio_data.photos:
					portfolio_list = json.dumps(eval(talent_portfolio_data.photos))		###		STRING IN TABLE
					media = json.loads(portfolio_list)
			
			elif talentPortfolio.media_type=='videos':
				if talent_portfolio_data.videos:
					portfolio_list = json.dumps(eval(talent_portfolio_data.videos))		###		STRING IN TABLE
					media = json.loads(portfolio_list)
			
			elif talentPortfolio.media_type=='audios':
				if talent_portfolio_data.audios:
					portfolio_list = json.dumps(eval(talent_portfolio_data.audios))		###		STRING IN TABLE
					media = json.loads(portfolio_list)

			elif talentPortfolio.media_type=='awards':
				if talent_portfolio_data.awards:
					portfolio_list = json.dumps(eval(talent_portfolio_data.awards))		###		STRING IN TABLE
					media = json.loads(portfolio_list)	

			if media is not None:
				dict_index = next((index for (index, d) in enumerate(media) if d["id"] == talentPortfolio.id), None)
				if dict_index is not None:
					media = media[dict_index]
				else:
					media={}

			data={"talent_portfolio":media}
			response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : data}
			return response
		else:
			return None

	def get_single_album_portfolio(self, talentAlbumPortfolio:TalentAlbumPortfolio, token):			#####	CONVERT BY CONDITION
		talent_id = token.id
		albums={}
		talent_portfolio_data = self.db.query(Talent_portfolio).filter((Talent_portfolio.talent_id == talent_id)).first()
		if talent_portfolio_data:
			if talentAlbumPortfolio.media_type=='photo_albums':
				if talent_portfolio_data.photo_albums:
					portfolio_list = json.dumps(eval(talent_portfolio_data.photo_albums))		###		STRING IN TABLE
					albums = json.loads(portfolio_list)
		
			elif talentAlbumPortfolio.media_type=='video_albums':
				if talent_portfolio_data.video_albums:
					portfolio_list = json.dumps(eval(talent_portfolio_data.video_albums))		###		STRING IN TABLE
					albums = json.loads(portfolio_list)

			elif talentAlbumPortfolio.media_type=='audio_albums':
				if talent_portfolio_data.audio_albums:
					portfolio_list = json.dumps(eval(talent_portfolio_data.audio_albums))		###		STRING IN TABLE
					albums = json.loads(portfolio_list)

			if albums is not None:
				dict_index = next((index for (index, d) in enumerate(albums) if d["id"] == talentAlbumPortfolio.album_id), None)
				if dict_index is not None:
					album = albums[dict_index]
					dict_index = next((index for (index, d) in enumerate(album) if d["id"] == talentAlbumPortfolio.id), None)
					media = album[dict_index]
				else:
					media={}

			data={"talent_portfolio":media}
			response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess, "response" : data}
			return response
		else:
			return None

	def update_talent_portfolio(self, talentPortfolioSave:TalentPortfolioSave, token):			#####   CONVERT BY CONDITION
		talent_id = token.id
		talent_portfolio_data = self.db.query(Talent_portfolio).filter((Talent_portfolio.talent_id == talent_id)).first()
		if talent_portfolio_data:
			if talentPortfolioSave.media_type=='photos':
				if talent_portfolio_data.photos is not None: 
					portfolio = json.dumps(eval(talent_portfolio_data.photos))	
					portfolio = json.loads(portfolio)
					dict_index = next((index for (index, d) in enumerate(portfolio) if d["id"] == talentPortfolioSave.id), None)
					if dict_index is not None:
						portfolio[dict_index].update({"name":talentPortfolioSave.name,"photographer":talentPortfolioSave.other,"year":talentPortfolioSave.year})
						new_dictionary = json.dumps(portfolio)	
						mysqlConnection.execute(f"UPDATE talent_portfolio SET photos = '{new_dictionary}' WHERE talent_id = '{talent_id}'")
						mydb.commit()
						response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
						return response
					else:
						return None

			elif talentPortfolioSave.media_type=='audios':
				if talent_portfolio_data.audios is not None: 
					portfolio = json.dumps(eval(talent_portfolio_data.audios))	
					portfolio = json.loads(portfolio)
					dict_index = next((index for (index, d) in enumerate(portfolio) if d["id"] == talentPortfolioSave.id), None)
					if dict_index is not None:
						portfolio[dict_index].update({"name":talentPortfolioSave.name,"singer":talentPortfolioSave.other,"year":talentPortfolioSave.year})
						new_dictionary = json.dumps(portfolio)	
						mysqlConnection.execute(f"UPDATE talent_portfolio SET audios = '{new_dictionary}' WHERE talent_id = '{talent_id}'")
						mydb.commit()
						response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
						return response
					else:
						return None

			elif talentPortfolioSave.media_type=='videos':
				if talent_portfolio_data.videos is not None: 
					portfolio = json.dumps(eval(talent_portfolio_data.videos))	
					portfolio = json.loads(portfolio)
					dict_index = next((index for (index, d) in enumerate(portfolio) if d["id"] == talentPortfolioSave.id), None)
					if dict_index is not None:
						portfolio[dict_index].update({"name":talentPortfolioSave.name,"description":talentPortfolioSave.other,"year":talentPortfolioSave.year})
						new_dictionary = json.dumps(portfolio)	
						mysqlConnection.execute(f"UPDATE talent_portfolio SET videos = '{new_dictionary}' WHERE talent_id = '{talent_id}'")
						mydb.commit()
						response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
						return response
					else:
						return None

			elif talentPortfolioSave.media_type=='awards':
				if talent_portfolio_data.awards is not None: 
					portfolio = json.dumps(eval(talent_portfolio_data.awards))	
					portfolio = json.loads(portfolio)
					dict_index = next((index for (index, d) in enumerate(portfolio) if d["id"] == talentPortfolioSave.id), None)
					if dict_index is not None:
						portfolio[dict_index].update({"name":talentPortfolioSave.name,"issuing_authority":talentPortfolioSave.other,"year":talentPortfolioSave.year})
						new_dictionary = json.dumps(portfolio)	
						mysqlConnection.execute(f"UPDATE talent_portfolio SET awards = '{new_dictionary}' WHERE talent_id = '{talent_id}'")
						mydb.commit()
						response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
						return response
					else:
						return None
		else:
			return None

	def delete_talent_portfolio(self, talentPortfolio:TalentPortfolio, token):			#######	  CONVERT BY CONDITION
		talent_id = token.id
		talent_portfolio_data = self.db.query(Talent_portfolio).filter((Talent_portfolio.talent_id == talent_id)).first()
		if talent_portfolio_data:
			if talentPortfolio.media_type=='photos':
				if talent_portfolio_data.photos is not None: 
					portfolio = json.dumps(eval(talent_portfolio_data.photos))	
					portfolio = json.loads(portfolio)
					dict_index = next((index for (index, d) in enumerate(portfolio) if d["id"] == talentPortfolio.id), None)
					if dict_index is not None:
						if talent_portfolio_data.photo_albums is not None: 
							portfolio_albums = json.dumps(eval(talent_portfolio_data.photo_albums))	
							portfolio_albums = json.loads(portfolio_albums)
							for albumRow in portfolio_albums:
								if 'medias' in albumRow.keys():
									dict_index_medias = next((index for (index, d) in enumerate(albumRow['medias']) if d["id"] == talentPortfolio.id), None)
									if dict_index_medias is not None:
										del albumRow['medias'][dict_index_medias]
										new_list = json.dumps(albumRow)	
										mysqlConnection.execute(f"UPDATE talent_portfolio SET photo_albums = '{new_list}' WHERE talent_id = '{talent_id}'")
										mydb.commit()
						del portfolio[dict_index]
						new_list = json.dumps(portfolio)	
						mysqlConnection.execute(f"UPDATE talent_portfolio SET {talentPortfolio.media_type} = '{new_list}' WHERE talent_id = '{talent_id}'")
						mydb.commit()
						response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
						return response
					else:
						return None

			elif talentPortfolio.media_type=='audios':
				if talent_portfolio_data.audios is not None: 
					portfolio = json.dumps(eval(talent_portfolio_data.audios))	
					portfolio = json.loads(portfolio)
					dict_index = next((index for (index, d) in enumerate(portfolio) if d["id"] == talentPortfolio.id), None)
					if dict_index is not None:
						if talent_portfolio_data.audios_albums is not None: 
							portfolio_albums = json.dumps(eval(talent_portfolio_data.audios_albums))	
							portfolio_albums = json.loads(portfolio_albums)
							for albumRow in portfolio_albums:
								if 'medias' in albumRow.keys():
									dict_index_medias = next((index for (index, d) in enumerate(albumRow['medias']) if d["id"] == talentPortfolio.id), None)
									if dict_index_medias is not None:
										del albumRow['medias'][dict_index_medias]
										new_list = json.dumps(albumRow)	
										mysqlConnection.execute(f"UPDATE talent_portfolio SET audios_albums = '{new_list}' WHERE talent_id = '{talent_id}'")
										mydb.commit()
							del portfolio[dict_index]
							new_list = json.dumps(portfolio)	
							mysqlConnection.execute(f"UPDATE talent_portfolio SET {talentPortfolio.media_type} = '{new_list}' WHERE talent_id = '{talent_id}'")
							mydb.commit()
							response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
							return response
					else:
						return None

			elif talentPortfolio.media_type=='videos':
				if talent_portfolio_data.videos is not None: 
					portfolio = json.dumps(eval(talent_portfolio_data.videos))	
					portfolio = json.loads(portfolio)
					dict_index = next((index for (index, d) in enumerate(portfolio) if d["id"] == talentPortfolio.id), None)
					if dict_index is not None:
						if talent_portfolio_data.videos_albums is not None: 
							portfolio_albums = json.dumps(eval(talent_portfolio_data.videos_albums))	
							portfolio_albums = json.loads(portfolio_albums)
							for albumRow in portfolio_albums:
								if 'medias' in albumRow.keys():
									dict_index_medias = next((index for (index, d) in enumerate(albumRow['medias']) if d["id"] == talentPortfolio.id), None)
									if dict_index_medias is not None:
										del albumRow['medias'][dict_index_medias]
										new_list = json.dumps(albumRow)	
										mysqlConnection.execute(f"UPDATE talent_portfolio SET videos_albums = '{new_list}' WHERE talent_id = '{talent_id}'")
										mydb.commit()
							del portfolio[dict_index]
							new_list = json.dumps(portfolio)	
							mysqlConnection.execute(f"UPDATE talent_portfolio SET {talentPortfolio.media_type} = '{new_list}' WHERE talent_id = '{talent_id}'")
							mydb.commit()
							response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
							return response
					else:
						return None

			elif talentPortfolio.media_type=='awards':
				if talent_portfolio_data.awards is not None: 
					portfolio = json.dumps(eval(talent_portfolio_data.awards))	
					portfolio = json.loads(portfolio)
					dict_index = next((index for (index, d) in enumerate(portfolio) if d["id"] == talentPortfolio.id), None)
					if dict_index is not None:
						del portfolio[dict_index]
						new_list = json.dumps(portfolio)	
						mysqlConnection.execute(f"UPDATE talent_portfolio SET {talentPortfolio.media_type} = '{new_list}' WHERE talent_id = '{talent_id}'")
						mydb.commit()
						response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
						return response
					else:
						return None
		else:
			return None

	def delete_talent_albums(self, talentPortfolio:TalentPortfolio, token):	   #######	  CONVERT BY CONDITION
		talent_id = token.id
		talent_portfolio_data = self.db.query(Talent_portfolio).filter((Talent_portfolio.talent_id == talent_id)).first()
		if talent_portfolio_data:
			if talentPortfolio.media_type=='photo_albums':
				if talent_portfolio_data.photo_albums is not None: 
					albums = json.dumps(eval(talent_portfolio_data.photo_albums))	
					albums = json.loads(albums)
					dict_index = next((index for (index, d) in enumerate(albums) if d["id"] == talentPortfolio.id), None)
					if dict_index is not None:
						del albums[dict_index]
						new_list = json.dumps(albums)	
						mysqlConnection.execute(f"UPDATE talent_portfolio SET {talentPortfolio.media_type} = '{new_list}' WHERE talent_id = '{talent_id}'")
						mydb.commit()
						response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
						return response
					else:
						return None

			elif talentPortfolio.media_type=='videos_albums':
				if talent_portfolio_data.videos_albums is not None: 
					albums = json.dumps(eval(talent_portfolio_data.videos_albums))	
					albums = json.loads(albums)
					dict_index = next((index for (index, d) in enumerate(albums) if d["id"] == talentPortfolio.id), None)
					if dict_index is not None:
						del albums[dict_index]
						new_list = json.dumps(albums)	
						mysqlConnection.execute(f"UPDATE talent_portfolio SET {talentPortfolio.media_type} = '{new_list}' WHERE talent_id = '{talent_id}'")
						mydb.commit()
						response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
						return response
					else:
						return None

			elif talentPortfolio.media_type=='audios_albums':
				if talent_portfolio_data.audios_albums is not None: 
					albums = json.dumps(eval(talent_portfolio_data.audios_albums))	
					albums = json.loads(albums)
					dict_index = next((index for (index, d) in enumerate(albums) if d["id"] == talentPortfolio.id), None)
					if dict_index is not None:
						del albums[dict_index]
						new_list = json.dumps(albums)	
						mysqlConnection.execute(f"UPDATE talent_portfolio SET {talentPortfolio.media_type} = '{new_list}' WHERE talent_id = '{talent_id}'")
						mydb.commit()
						response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
						return response
					else:
						return None
		else:
			return None

	def generate_qr_code(self, Request:Request, token):	   		###############	  CONVERT BY CONDITION
		talent_id = token.id
		talent_personal_info =  self.db.query(Talent_personal_info).filter(Talent_personal_info.talent_id == talent_id).first()
		url = Request.url
		parsed_url = urlparse(str(url))
		captured_value = str(parsed_url.path).split('/')
		api_name = captured_value[1]+'/'+captured_value[2]
		if talent_personal_info.qr_code is None:

			enc_id = base64.b64encode(str(talent_id).encode("ascii"))
			non_byte_str = enc_id.decode("utf-8")
			
			url = parsed_url.scheme+"://"+parsed_url.netloc+'/'+api_name+'/view_profile/'+str(non_byte_str)
			
			qr_code = pyqrcode.create(url)
			imageName = str(talent_id)+'_'+str(random.randint(1000, 9999))+'_qr_code.png'
			qr_code.png(str(FOLDER_NAME)+imageName, scale=8) 

			talent_register =  self.db.query(Talent_register).filter((Talent_register.id == talent_id)).first()
			user_bucket = talent_register.s3_bucket
			return_s3_url = media_upload.upload_portfolio(talent_id, imageName, user_bucket)
			if return_s3_url:
				talent_personal_info.qr_code = return_s3_url
				self.db.add(talent_personal_info)
				self.db.commit()
				self.db.refresh(talent_personal_info)

			response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
			return response
		else:
			return None
		
	def view_profile(self, enc_id):			#####################	CONVERT BY CONDITION
		base64_bytes = bytes(enc_id, encoding="raw_unicode_escape")
		talent_id = base64.b64decode(base64_bytes).decode("ascii")
		print('============>>>>>>>>>>>>>>>>>>>>>>>>>',talent_id)
		response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
		return response

async def save_awards(files: List[UploadFile] =File(...), name: str = Form(...), year: str = Form(...), other: str = Form(...), token = Depends(get_talent_current_user), db: get_db = Depends()):
	talent_id = token.id
	for media in files:
		if media is not None:
			imageName = media_portfolio_temp.upload_media_form_data(talent_id, media.filename, media.file)

			talent_register = db.query(Talent_register).filter((Talent_register.id == talent_id)).first()
			talent_portfolio = db.query(Talent_portfolio).filter((Talent_portfolio.talent_id == talent_id)).first()
			
			portfolio_list = []
			if not talent_portfolio:												##		CREATE TALENT_PORTFOLIO LIST IF NOT EXIST
				talent_portfolio = Talent_portfolio(
					talent_id=talent_id,
					created_at = dateTime_at
				)
				db.add(talent_portfolio)
				db.commit()
				db.refresh(talent_portfolio)
			else:
				if talent_portfolio.awards is not None:
					portfolio_list = json.dumps(eval(talent_portfolio.awards))		##		STRING IN TABLE
					portfolio_list = json.loads(portfolio_list)						##		STRING TO LIST CONVERSION

			new_portfolio_list = []
			user_bucket = talent_register.s3_bucket
			return_s3_url = media_upload.upload_portfolio(id, imageName, user_bucket)
			if return_s3_url:
				randomId = random.randint(100000, 999999)
				year = year
				update_json = {"id":randomId, "media_path":return_s3_url,"name":name,"year":year,"issuing_authority":other,"created_at":dateTime_at}
				
				new_portfolio_list.append(update_json)
				
			else:
				getTempRow.exception_message = "Invalid file format"
				getTempRow.modified_at = dateTime_at
				db.add(getTempRow)
				db.commit()
				db.refresh(getTempRow)

			portfolio_list = portfolio_list + new_portfolio_list
			portfolio_list = json.dumps(portfolio_list)
			mysqlConnection.execute(f"UPDATE talent_portfolio SET awards = '{portfolio_list}' WHERE talent_id = '{talent_id}'")
			mydb.commit()
			
	response = {"status" : statusCodeSuccess, "message" : statusMessageSuccess}
	if not response:
		return ServiceResult(AppException.CreateValidation())
	return ServiceResult(response)


	
					